from __future__ import annotations

import itertools
import time
from dataclasses import dataclass

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix

from .quad2quad import embed_station_candidates


METHOD_REGISTRY = {
    "SEQ": dict(execution_mode="single_station_sequential", shared_state=False, selection_rule="first_candidate", global_coordinator=False, rolling_horizon=False, runtime_estimate="actual_at_completion", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "IND": dict(execution_mode="parallel_independent", shared_state=False, selection_rule="first_candidate", global_coordinator=False, rolling_horizon=False, runtime_estimate="actual_at_completion", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "FCFS": dict(execution_mode="parallel_shared_state", shared_state=True, selection_rule="first_candidate", global_coordinator=False, rolling_horizon=False, runtime_estimate="actual_at_completion", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "GREEDY": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="sequential_greedy_weighted", global_coordinator=True, rolling_horizon=False, runtime_estimate="actual_at_completion", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "GC-M": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="exact_weighted", global_coordinator=True, rolling_horizon=False, runtime_estimate="actual_at_completion", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "GC-P50": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="exact_weighted", global_coordinator=True, rolling_horizon=True, runtime_estimate="P50", robust_prediction=False, quad2quad=False, perfect_future_information=False),
    "GC-P90": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="exact_weighted", global_coordinator=True, rolling_horizon=True, runtime_estimate="conformal_P90", robust_prediction=True, quad2quad=False, perfect_future_information=False),
    "Q2Q-P90": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="exact_quad2quad", global_coordinator=True, rolling_horizon=True, runtime_estimate="conformal_P90", robust_prediction=True, quad2quad=True, perfect_future_information=False),
    "ORACLE": dict(execution_mode="parallel_coordinated", shared_state=True, selection_rule="exact_weighted", global_coordinator=True, rolling_horizon=True, runtime_estimate="actual_runtime", robust_prediction=False, quad2quad=False, perfect_future_information=True),
}


def candidates_conflict(a: dict, b: dict) -> bool:
    if a.get("fallback") or b.get("fallback"):
        return False
    overlap = set(a.get("resources", [])) & set(b.get("resources", []))
    for resource_id in overlap:
        window_a = a.get("resource_windows", {}).get(
            str(resource_id), [a["interval_start"], a["interval_end"]]
        )
        window_b = b.get("resource_windows", {}).get(
            str(resource_id), [b["interval_start"], b["interval_end"]]
        )
        if window_a[0] < window_b[1] and window_b[0] < window_a[1]:
            return True
    return False


def conflict_pairs(groups: list[list[dict]]) -> list[tuple[tuple[int, int], tuple[int, int]]]:
    pairs = []
    for s1, s2 in itertools.combinations(range(len(groups)), 2):
        for i, a in enumerate(groups[s1]):
            for j, b in enumerate(groups[s2]):
                if candidates_conflict(a, b):
                    pairs.append(((s1, i), (s2, j)))
    return pairs


def _score(candidate: dict, selector: str) -> float:
    if selector == "q2q":
        return candidate["quad_distance"]
    if selector == "asf":
        u, v = candidate["normalized_retrievals"], candidate["normalized_completion"]
        return max(u, v) + 0.05 * (u + v)
    if selector == "weighted":
        return 0.5 * candidate["normalized_retrievals"] + 0.5 * candidate["normalized_completion"]
    return candidate["predicted_retrievals"] * 1000 + candidate["predicted_completion"]


def score_candidate(candidate: dict, selector: str) -> float:
    """Public, auditable selector score used in decision-level reporting."""
    selector = "q2q" if str(selector).startswith("q2q") else selector
    selector = "weighted" if str(selector).startswith("weighted") else selector
    return float(_score(candidate, selector))


def _embedded(groups):
    n = len(groups)
    return [embed_station_candidates(group, i, n) for i, group in enumerate(groups)]


def select_greedy(groups: list[list[dict]], selector="weighted") -> list[dict]:
    groups = _embedded(groups)
    chosen = []
    for group in groups:
        feasible = [c for c in sorted(group, key=lambda x: _score(x, selector)) if all(not candidates_conflict(c, x) for x in chosen)]
        chosen.append(feasible[0] if feasible else next(c for c in group if c.get("fallback")))
    return chosen


def select_exact(groups: list[list[dict]], selector="weighted") -> tuple[list[dict], dict]:
    groups = _embedded(groups)
    flat = [(s, k, c) for s, group in enumerate(groups) for k, c in enumerate(group)]
    index = {(s, k): i for i, (s, k, _) in enumerate(flat)}
    conflicts = conflict_pairs(groups)
    rows = len(groups) + len(conflicts)
    matrix = lil_matrix((rows, len(flat)), dtype=float)
    lower = np.full(rows, -np.inf); upper = np.ones(rows)
    for s, group in enumerate(groups):
        for k in range(len(group)):
            matrix[s, index[(s, k)]] = 1
        lower[s] = upper[s] = 1
    for row, (left, right) in enumerate(conflicts, len(groups)):
        matrix[row, index[left]] = 1; matrix[row, index[right]] = 1
    objective = np.array([_score(c, selector) for _, _, c in flat], float)
    started = time.perf_counter()
    result = milp(objective, integrality=np.ones(len(flat)), bounds=Bounds(0, 1),
                  constraints=LinearConstraint(matrix.tocsr(), lower, upper),
                  options={"time_limit": 30.0, "mip_rel_gap": 0.0})
    runtime = time.perf_counter() - started
    if not result.success:
        chosen = select_greedy(groups, selector)
        return chosen, {"solver_success": False, "solver_message": result.message, "runtime_seconds": runtime,
                        "variables": len(flat), "constraints": rows, "conflicts": len(conflicts)}
    chosen = [flat[i][2] for i, value in enumerate(result.x) if value > 0.5]
    chosen.sort(key=lambda c: c["station"])
    return chosen, {"solver_success": True, "solver_message": result.message, "runtime_seconds": runtime,
                    "variables": len(flat), "constraints": rows, "conflicts": len(conflicts),
                    "objective": float(result.fun)}


def select_candidates(groups: list[list[dict]], method: str) -> tuple[list[dict], dict]:
    started = time.perf_counter()
    if method in {"IND", "FCFS", "SEQ"}:
        chosen = [group[0] for group in groups]
        meta = {"selector": method.lower(), "solver_success": True}
    elif method == "GREEDY":
        chosen = select_greedy(groups, "weighted"); meta = {"selector": "greedy", "solver_success": True}
    elif method == "Q2Q-P90":
        chosen, meta = select_exact(groups, "q2q"); meta["selector"] = "q2q_exact_feasibility"
    else:
        chosen, meta = select_exact(groups, "weighted"); meta["selector"] = "weighted_exact"
    meta["coordination_runtime_seconds"] = time.perf_counter() - started
    meta["raw_conflicts"] = len(conflict_pairs(groups))
    proposal_conflicts = sum(candidates_conflict(a, b) for a, b in itertools.combinations(chosen, 2))
    meta["proposal_conflicts"] = proposal_conflicts
    meta["committed_conflicts"] = 0 if method in {"IND", "FCFS", "SEQ"} else proposal_conflicts
    if meta["committed_conflicts"]:
        raise AssertionError("Coordinator committed a shared-resource collision")
    return chosen, meta


def enumerate_pareto_front(groups: list[list[dict]], maximum_combinations=200_000) -> list[dict]:
    total = int(np.prod([len(g) for g in groups]))
    if total > maximum_combinations:
        return []
    points = []
    for combination in itertools.product(*groups):
        if any(candidates_conflict(a, b) for a, b in itertools.combinations(combination, 2)):
            continue
        points.append({"retrievals": sum(c["predicted_retrievals"] for c in combination),
                       "makespan": max(c["predicted_completion"] for c in combination),
                       "candidate_ids": "|".join(c["candidate_id"] for c in combination)})
    nondominated = []
    for p in points:
        if not any((q["retrievals"] <= p["retrievals"] and q["makespan"] <= p["makespan"] and
                    (q["retrievals"] < p["retrievals"] or q["makespan"] < p["makespan"])) for q in points):
            nondominated.append(p)
    return nondominated
