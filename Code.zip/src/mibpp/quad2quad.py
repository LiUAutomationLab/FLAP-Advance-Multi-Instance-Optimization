from __future__ import annotations

import math

import numpy as np


def bilinear_map(u: float, v: float, quad: np.ndarray) -> np.ndarray:
    a, b, c, d = np.asarray(quad, dtype=float)
    return (1-u)*(1-v)*a + u*(1-v)*b + u*v*c + (1-u)*v*d


def build_equal_quads(n: int, center=(0.0, 0.0), scale=1.0, angle0=0.0) -> list[np.ndarray]:
    """Congruent rotated unit quads whose minimization ideal (0,0) is the common center."""
    if n < 1:
        raise ValueError("n must be positive")
    origin = np.asarray(center, float)
    quads = []
    for i in range(n):
        angle = angle0 + i * 2 * math.pi / n
        e1 = scale * np.array([math.cos(angle), math.sin(angle)])
        e2 = scale * np.array([-math.sin(angle), math.cos(angle)])
        quads.append(np.vstack([origin, origin + e1, origin + e1 + e2, origin + e2]))
    return quads


def normalize(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, float)
    lo, hi = np.nanmin(values), np.nanmax(values)
    return np.zeros_like(values) if hi <= lo else (values - lo) / (hi - lo)


def embed_station_candidates(candidates: list[dict], station_index: int, station_count: int) -> list[dict]:
    real = [c for c in candidates if not c.get("fallback")]
    real_recalls = normalize(np.array([c["predicted_retrievals"] for c in real], float))
    real_completion = normalize(np.array([c["predicted_completion"] for c in real], float))
    normalized = {
        id(candidate): (float(u), float(v))
        for candidate, u, v in zip(real, real_recalls, real_completion)
    }
    quad = build_equal_quads(station_count)[station_index]
    output = []
    for candidate in candidates:
        # Deferral is a feasibility action, not an attractive zero-retrieval plan.
        u, v = normalized.get(id(candidate), (2.0, 2.0))
        point = bilinear_map(float(u), float(v), quad)
        output.append({**candidate, "normalized_retrievals": float(u), "normalized_completion": float(v),
                       "quad_x": float(point[0]), "quad_y": float(point[1]),
                       "quad_distance": float(np.linalg.norm(point))})
    return output


def jacobian_determinant(quad: np.ndarray, u: float, v: float) -> float:
    a, b, c, d = np.asarray(quad, float)
    du = -(1-v)*a + (1-v)*b + v*c - v*d
    dv = -(1-u)*a - u*b + u*c + (1-u)*d
    return float(np.linalg.det(np.column_stack([du, dv])))
