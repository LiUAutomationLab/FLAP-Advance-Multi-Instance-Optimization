from __future__ import annotations

import math

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.model_selection import KFold

from .dataio import read_table, result_dirs, write_table


PRE_FEATURES = [
    "box_count", "product_count", "shannon_entropy", "normalized_entropy", "max_product_share",
    "quantity_cv", "mean_item_volume_mm3", "item_volume_cv", "length_cv", "width_cv", "height_cv",
    "mean_weight_kg", "weight_cv",
]


def _smape(y, p):
    den = np.abs(y) + np.abs(p)
    return float(np.mean(np.where(den > 0, 2 * np.abs(p - y) / den, 0)))


def _pinball(y, p, q):
    e = y - p
    return float(np.mean(np.maximum(q * e, (q - 1) * e)))


def fit_runtime_models(config: dict, empirical: pd.DataFrame | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    dirs = result_dirs(config)
    if empirical is None:
        empirical = read_table(dirs["raw"] / "empirical_orders")
    y = empirical.actual_runtime.to_numpy(float)
    logy = np.log1p(y)
    seed = int(config["seed"])
    folds = min(int(config["runtime_prediction"]["folds"]), len(empirical))
    cv = KFold(n_splits=folds, shuffle=True, random_state=seed)
    model_specs = {
        "P0_constant": ([], None),
        "P1_size": (["box_count"], RandomForestRegressor(n_estimators=120, min_samples_leaf=4, random_state=seed, n_jobs=-1)),
        "P2_entropy": (["shannon_entropy"], RandomForestRegressor(n_estimators=120, min_samples_leaf=4, random_state=seed, n_jobs=-1)),
        "P3_entropy_size": (["box_count", "product_count", "shannon_entropy"], ExtraTreesRegressor(n_estimators=150, min_samples_leaf=3, random_state=seed, n_jobs=-1)),
        "P4_full": (PRE_FEATURES, ExtraTreesRegressor(n_estimators=180, min_samples_leaf=3, random_state=seed, n_jobs=-1)),
    }
    long_rows = []
    primary = pd.DataFrame({"order_id": empirical.order_id, "actual_runtime": y})
    p50_all = np.zeros(len(y)); p90_all = np.zeros(len(y)); p95_all = np.zeros(len(y)); fold_all = np.zeros(len(y), int)
    for fold, (train, test) in enumerate(cv.split(empirical), 1):
        fold_all[test] = fold
        for name, (cols, estimator) in model_specs.items():
            if estimator is None:
                pred = np.repeat(np.median(logy[train]), len(test))
            else:
                model = clone(estimator).fit(empirical.iloc[train][cols], logy[train])
                pred = model.predict(empirical.iloc[test][cols])
            seconds = np.maximum(0, np.expm1(pred))
            for idx, value in zip(test, seconds):
                long_rows.append({"order_id": int(empirical.iloc[idx].order_id), "fold": fold, "model": name,
                                  "actual_runtime": y[idx], "prediction": float(value), "quantile": 0.5})
            if name == "P4_full":
                p50_all[test] = seconds
        # Quantile models use only pre-optimization features.
        for quantile, target in [(0.90, p90_all), (0.95, p95_all)]:
            qmodel = GradientBoostingRegressor(loss="quantile", alpha=quantile, n_estimators=120,
                                               min_samples_leaf=5, random_state=seed + fold)
            qmodel.fit(empirical.iloc[train][PRE_FEATURES], logy[train])
            pred = np.maximum(0, np.expm1(qmodel.predict(empirical.iloc[test][PRE_FEATURES])))
            target[test] = pred
            for idx, value in zip(test, pred):
                long_rows.append({"order_id": int(empirical.iloc[idx].order_id), "fold": fold,
                                  "model": f"P5_quantile_{int(quantile*100)}", "actual_runtime": y[idx],
                                  "prediction": float(value), "quantile": quantile})
    # Cross-fitted conformal correction on the P90 residual distribution.
    alpha = float(config["runtime_prediction"].get("conformal_alpha", 0.10))
    residuals = np.maximum(y - p90_all, 0)
    conformal = np.empty_like(p90_all)
    for held_out_fold in np.unique(fold_all):
        calibration = residuals[fold_all != held_out_fold]
        correction = float(np.quantile(calibration, 1 - alpha, method="higher"))
        conformal[fold_all == held_out_fold] = p90_all[fold_all == held_out_fold] + correction
    for idx, value in enumerate(conformal):
        long_rows.append({"order_id": int(empirical.iloc[idx].order_id), "fold": int(fold_all[idx]),
                          "model": "P5_conformal_upper", "actual_runtime": y[idx],
                          "prediction": float(value), "quantile": 1 - alpha})
    primary["predicted_p50"] = p50_all
    # All robust P90 methods consume the calibrated upper bound, not the
    # under-covering raw quantile-regression output.
    primary["predicted_p90"] = np.maximum.reduce([conformal, p90_all, p50_all])
    primary["predicted_p95"] = np.maximum.reduce([p95_all, primary.predicted_p90.to_numpy()])
    primary["prediction_error"] = primary.actual_runtime - primary.predicted_p50
    primary["underprediction"] = primary.prediction_error.clip(lower=0)
    primary["fold"] = fold_all
    long = pd.DataFrame(long_rows)
    metrics = []
    for model, g in long.groupby("model"):
        actual, pred = g.actual_runtime.to_numpy(), g.prediction.to_numpy()
        q = float(g["quantile"].iloc[0])
        metrics.append({
            "model": model, "n": len(g), "MAE_seconds": float(np.mean(np.abs(actual-pred))),
            "RMSE_seconds": float(np.sqrt(np.mean((actual-pred)**2))),
            "R2_log1p": float(1 - np.sum((np.log1p(actual)-np.log1p(pred))**2) / np.sum((np.log1p(actual)-np.log1p(actual).mean())**2)),
            "Spearman_rho": float(spearmanr(actual, pred).statistic), "sMAPE": _smape(actual, pred),
            "underprediction_rate": float(np.mean(actual > pred)),
            "mean_underprediction_seconds": float(np.mean(np.maximum(actual-pred, 0))),
            "p90_underprediction_seconds": float(np.quantile(np.maximum(actual-pred, 0), .90)),
            "p95_underprediction_seconds": float(np.quantile(np.maximum(actual-pred, 0), .95)),
            "coverage": float(np.mean(actual <= pred)), "pinball_loss": _pinball(actual, pred, q),
        })
    metrics_df = pd.DataFrame(metrics)
    write_table(primary, dirs["raw"] / "prediction_oof")
    write_table(long, dirs["raw"] / "prediction_oof_long")
    write_table(metrics_df, dirs["statistics"] / "runtime_metrics")
    return primary, metrics_df
