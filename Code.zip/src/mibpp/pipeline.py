from __future__ import annotations

import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn

from .benchmarks import run_selector_benchmarks
from .candidates import build_candidate_pool
from .config import config_hash, dump_resolved_config
from .dataio import result_dirs, sha256, write_json
from .features import prepare_features, validate_data
from .reporting import make_figures, make_scalability_figure, make_tables
from .runtime import fit_runtime_models
from .simulation import run_prediction_robustness, run_simulations
from .statistics import compute_statistics, packing_equivalence


def _git_commit(root):
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True, stderr=subprocess.DEVNULL
        ).strip()
    except Exception:
        return None


def write_manifest(config):
    dirs = result_dirs(config)
    manifest = {
        "run_name": config["run_name"],
        "run_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "config_sha256": config_hash(config),
        "dataset_sha256": sha256(config["paths"]["dataset"]),
        "legacy_results_sha256": sha256(config["paths"]["legacy_results"]),
        "git_commit": _git_commit(config["_project_root"]),
        "python": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
        "root_seed": config["seed"],
        "workers": 1,
        "dependencies": {
            "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
        },
        "evidence_layers": {
            "empirical": [
                "orders", "products", "quantities", "dimensions", "weights", "optimizer runtimes",
                "original packing metrics", "blocks", "residuals",
            ],
            "scenario": [
                "arrivals", "AMRs", "buffer capacity", "retrieval/transport time",
                "robot execution time", "resource scarcity", "execution disturbances",
            ],
        },
    }
    write_json(manifest, dirs["root"] / "manifest.json")
    dump_resolved_config(config, dirs["root"] / "resolved_config.yaml")
    return manifest


def run_raw_experiments(config, include_selector_benchmarks=True):
    write_manifest(config)
    validate_data(config)
    empirical = prepare_features(config)
    predictions, _ = fit_runtime_models(config, empirical)
    pool = build_candidate_pool(config, empirical)
    frames = run_simulations(config, empirical, predictions, pool)
    run_prediction_robustness(config, empirical, predictions, pool)
    if include_selector_benchmarks:
        run_selector_benchmarks(config, empirical, pool)
    return frames


def run_scalability_only(config, station_counts=None):
    if station_counts is not None:
        config["scalability"]["station_counts"] = list(map(int, station_counts))
    empirical = prepare_features(config)
    try:
        from .dataio import read_table
        pool = read_table(Path(config["paths"]["results_dir"]) / "raw" / "packing_candidates")
    except FileNotFoundError:
        max_stations = min(max(config["scalability"]["station_counts"]), int(config["experiment"]["num_orders"]))
        local = dict(config)
        local["experiment"] = dict(config["experiment"], num_orders=max_stations)
        pool = build_candidate_pool(local, empirical)
    benchmarks = run_selector_benchmarks(config, empirical, pool)
    make_scalability_figure(config, benchmarks)
    return benchmarks


def run_reporting(config, output_dir=None):
    episodes = read_raw(config, "episodes")
    orders = read_raw(config, "orders")
    pool = read_raw(config, "packing_candidates")
    compute_statistics(config, episodes)
    packing_equivalence(config, orders, pool)
    make_figures(config, output_dir)
    make_tables(config, output_dir)


def read_raw(config, name):
    from .dataio import read_table
    return read_table(Path(config["paths"]["results_dir"]) / "raw" / name)
