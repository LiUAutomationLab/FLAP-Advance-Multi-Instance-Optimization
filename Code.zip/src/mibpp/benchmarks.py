from __future__ import annotations

import json
# import resource
import time

import numpy as np
import pandas as pd

from .coordination import enumerate_pareto_front, score_candidate, select_exact, select_greedy
from .dataio import read_table, result_dirs, write_table


def _make_groups(config, empirical, pool, stations, candidates, overlap, seed):
    """Generate controlled scenario-layer alternatives with nested conflict density.

    Packing evidence remains empirical elsewhere. This benchmark deliberately
    stresses only the coordinator and creates real retrieval/completion trade-offs.
    """
    rng = np.random.default_rng(seed)
    density = {"low": 0.10, "medium": 0.40, "high": 0.80}[str(overlap)]
    shared_resources = [f"SHARED-{i}" for i in range(max(3, stations))]
    groups = []
    for station in range(stations):
        expanded = []
        for k in range(candidates):
            draws = rng.random(len(shared_resources))
            resources = [r for r, draw in zip(shared_resources, draws) if draw < density]
            if not resources:
                resources = [f"PRIVATE-{station}-{k % 3}"]
            start = float(rng.uniform(0, 80))
            duration = float(rng.uniform(50, 180))
            # Purposeful Pareto tension: fewer retrievals generally cost completion time.
            retrievals = 1 + ((candidates - 1 - k) % max(2, min(8, candidates)))
            completion = start + duration + 18.0 * (candidates - retrievals)
            slot = duration / len(resources)
            windows = {str(r): [start + i * slot, start + (i + 1) * slot]
                       for i, r in enumerate(resources)}
            expanded.append({
                "order_id": station, "station": station,
                "candidate_id": f"S{station}-C{k:03d}",
                "predicted_retrievals": retrievals,
                "predicted_completion": completion,
                "interval_start": start, "interval_end": start + duration,
                "resources": resources, "resource_sequence": resources,
                "resource_windows": windows, "fallback": False,
                "compactness": float(rng.uniform(.3, .9)),
                "homogeneity": float(rng.uniform(.3, .9)),
                "pallet_volume_utilization_pct": float(rng.uniform(35, 85)),
            })
        fallback = {
            "order_id": station, "station": station, "candidate_id": f"S{station}-DEFER",
            "predicted_retrievals": 0, "predicted_completion": 1e6,
            "interval_start": 1e6, "interval_end": 1e6 + 1,
            "resources": [], "resource_sequence": [], "resource_windows": {},
            "fallback": True, "fallback_reason": "no_conflict_free_simultaneous_candidate",
        }
        groups.append(expanded + [fallback])
    return groups


def run_selector_benchmarks(config: dict, empirical=None, pool=None) -> pd.DataFrame:
    dirs = result_dirs(config)
    empirical = empirical if empirical is not None else read_table(dirs["raw"] / "empirical_orders")
    pool = pool if pool is not None else read_table(dirs["raw"] / "packing_candidates")
    rows = []
    selectors = ["greedy", "weighted", "asf", "q2q", "exact"]
    for stations in config["scalability"]["station_counts"]:
        if stations > len(pool.order_id.unique()):
            continue
        for candidates in config["scalability"]["candidate_counts"]:
            for overlap in config["scalability"]["overlap_levels"]:
                for repetition in range(int(config["scalability"]["repetitions"])):
                    seed = int(config["seed"]) + stations * 10000 + candidates * 100 + repetition
                    groups = _make_groups(config, empirical, pool, int(stations), int(candidates), overlap, seed)
                    exact_choice, exact_meta = select_exact(groups, "weighted")
                    exact_value = sum(score_candidate(c, "weighted") for c in exact_choice)
                    exact_ids = "|".join(c["candidate_id"] for c in exact_choice)
                    pareto = enumerate_pareto_front(groups) if stations <= 4 and candidates <= 10 else []
                    for selector in selectors:
                        started = time.perf_counter()
                        if selector == "greedy":
                            choice = select_greedy(groups, "raw"); meta = {"solver_success": True}
                        elif selector == "weighted":
                            choice = select_greedy(groups, "weighted"); meta = {"solver_success": True}
                        elif selector == "exact":
                            choice, meta = exact_choice, exact_meta
                        else:
                            choice, meta = select_exact(groups, selector)
                        runtime = (
                            float(exact_meta["runtime_seconds"])
                            if selector == "exact" else time.perf_counter() - started
                        )
                        value = sum(score_candidate(c, "weighted") for c in choice)
                        ids = "|".join(c["candidate_id"] for c in choice)
                        obj = {"retrievals": sum(c["predicted_retrievals"] for c in choice),
                               "makespan": max(c["predicted_completion"] for c in choice)}
                        on_pareto = any(p["retrievals"] == obj["retrievals"] and np.isclose(p["makespan"], obj["makespan"])
                                        for p in pareto) if pareto else np.nan
                        rows.append({
                            "stations": stations, "candidate_count": candidates, "overlap": overlap,
                            "repetition": repetition, "selector": selector, "runtime_seconds": runtime,
                            "retrievals": obj["retrievals"], "makespan": obj["makespan"],
                            "objective_value": value,
                            "objective_gap_vs_exact": max(0.0, (value - exact_value) / max(abs(exact_value), 1e-12)),
                            "selection_agreement_exact": ids == exact_ids, "on_exact_pareto_front": on_pareto,
                            "conflicts": meta.get("conflicts", exact_meta.get("conflicts", 0)),
                            "binary_variables": meta.get("variables", exact_meta.get("variables", 0)),
                            "constraints": meta.get("constraints", exact_meta.get("constraints", 0)),
                            "fallback_frequency": np.mean([c.get("fallback", False) for c in choice]),
                            "deferral_rate": np.mean([c.get("fallback", False) for c in choice]),
                            "fallback_definition": "station deferred because no conflict-free simultaneous candidate was selected",
                            "deadline_met": runtime <= config["simulation"]["coordination_deadline_seconds"],
                            # "memory_peak_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
                            "system_alternative_note": "controlled scenario-layer coordinator stress test",
                        })
    frame = pd.DataFrame(rows)
    write_table(frame, dirs["raw"] / "selector_benchmarks")
    return frame
