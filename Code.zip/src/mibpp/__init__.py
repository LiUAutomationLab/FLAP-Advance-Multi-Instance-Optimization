"""Multi-instance 3D bin-packing experiment package."""

__version__ = "1.0.0"
