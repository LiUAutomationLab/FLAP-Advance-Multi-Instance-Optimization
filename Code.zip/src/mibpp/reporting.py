from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

from .coordination import METHOD_REGISTRY
from .dataio import read_table, result_dirs
from .quad2quad import build_equal_quads


COLORS = {
    "navy": "#17324D", "blue": "#247BA0", "teal": "#2A9D8F", "orange": "#F4A261",
    "red": "#E76F51", "gold": "#E9C46A", "gray": "#6B7280", "light": "#F4F7FA",
}


def _report_dirs(config, output_dir=None):
    base = Path(output_dir).resolve() if output_dir else Path(config["paths"]["results_dir"])
    dirs = {
        "figures": base / "figures", "tables": base / "tables",
        "figure_data": base / "figure_data" if output_dir else base / "derived" / "figure_data",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    return dirs


def _save(fig, dirs, name, data=None, dpi=300):
    target = dirs["figures"] / f"{name}.png"

    print(f"Saving: {target}")
    print(f"Path length: {len(str(target))}")
    print(f"Parent exists: {target.parent.exists()}")

    test_file = target.parent / "_write_test.tmp"
    with test_file.open("wb") as file:
        file.write(b"test")
    test_file.unlink()

    fig.savefig(target, dpi=dpi, bbox_inches="tight")

    # fig.savefig(dirs["figures"] / f"{name}.pdf", bbox_inches="tight")
    # fig.savefig(dirs["figures"] / f"{name}.svg", bbox_inches="tight")
    # fig.savefig(dirs["figures"] / f"{name}.png", dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    if data is not None:
        data.to_csv(dirs["figure_data"] / f"{name}.csv", index=False)


def _base_style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 11,
        "axes.labelsize": 9, "axes.spines.top": False, "axes.spines.right": False,
        "figure.facecolor": "white", "axes.facecolor": "white",
    })


def figure_a_architecture(dirs, dpi):
    labels = ["Local packing", "Candidate plans", "Global coordination", "Reservation", "Execution", "Feedback"]
    x = [0.08, 0.38, 0.68, 0.68, 0.38, 0.08]
    y = [0.68, 0.68, 0.68, 0.22, 0.22, 0.22]
    fig, ax = plt.subplots(figsize=(9, 3.2))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    for i, (label, xx, yy) in enumerate(zip(labels, x, y)):
        color = COLORS["teal"] if i in {2, 5} else COLORS["navy"]
        box = FancyBboxPatch((xx, yy), 0.22, 0.16, boxstyle="round,pad=0.02,rounding_size=0.02",
                             facecolor=color, edgecolor="none")
        ax.add_patch(box); ax.text(xx + 0.11, yy + 0.08, label, color="white", ha="center", va="center", weight="bold")
        if i < len(labels) - 1:
            start = (xx + 0.22, yy + 0.08) if i not in {2, 4} else ((xx + 0.11, yy) if i == 2 else (xx, yy + 0.08))
            nx, ny = x[i + 1], y[i + 1]
            end = (nx, ny + 0.08) if i not in {2, 4} else ((nx + 0.11, ny + 0.16) if i == 2 else (nx + 0.22, ny + 0.08))
            ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=12, color=COLORS["gray"], lw=1.6))
    ax.set_title("Hierarchical decision architecture", loc="left", weight="bold", color=COLORS["navy"])
    data = pd.DataFrame({"sequence": range(1, 7), "stage": labels})
    _save(fig, dirs, "Figure_A_hierarchical_architecture", data, dpi)


def figure_b_sequence(dirs, dpi):
    actors = ["Order manager", "Station agents", "Coordinator", "Asset manager", "Execution"]
    messages = [("STATE_UPDATE", 0, 1), ("PROPOSAL", 1, 2), ("CONFLICT_CHECK", 2, 3),
                ("PREPARE + COMMIT", 2, 1), ("EXECUTE", 1, 4), ("FEEDBACK / REPLAN", 4, 2)]
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.set_xlim(-0.4, 4.4); ax.set_ylim(0, 7); ax.axis("off")
    for i, actor in enumerate(actors):
        ax.text(i, 6.65, actor, ha="center", va="center", weight="bold", color=COLORS["navy"])
        ax.plot([i, i], [0.35, 6.35], color="#C7D2DE", lw=1, ls="--")
    rows = []
    for rank, (message, source, target) in enumerate(messages):
        yy = 5.8 - rank * 0.88
        ax.annotate("", xy=(target, yy), xytext=(source, yy),
                    arrowprops=dict(arrowstyle="-|>", color=COLORS["teal"] if target > source else COLORS["orange"], lw=1.8))
        ax.text((source + target) / 2, yy + 0.14, message, ha="center", fontsize=8)
        rows.append({"sequence": rank + 1, "message": message, "source": actors[source], "target": actors[target]})
    ax.set_title("Coordination protocol", loc="left", weight="bold", color=COLORS["navy"])
    _save(fig, dirs, "Figure_B_coordination_sequence", pd.DataFrame(rows), dpi)


def figure_c_timeline_dep(events, dirs, dpi):
    subset = events[(events.method == "Q2Q-P90") & (events.replicate == events.replicate.min())].copy()
    scenario = subset.scenario.iloc[0]
    subset = subset[subset.scenario == scenario]
    keep = ["OPTIMIZATION_START", "OPTIMIZATION_PREDICTED_FINISH", "OPTIMIZATION_COMPLETE",
            "PREDICTION_OVERRUN", "REPLAN", "EXECUTION_START", "EXECUTION_COMPLETE"]
    subset = subset[subset.event_type.isin(keep)].sort_values("timestamp").head(80)
    fig, ax = plt.subplots(figsize=(9, 4.2))
    marker = {"OPTIMIZATION_START": "o", "OPTIMIZATION_PREDICTED_FINISH": "|", "OPTIMIZATION_COMPLETE": "s",
              "PREDICTION_OVERRUN": "X", "REPLAN": "D", "EXECUTION_START": "^", "EXECUTION_COMPLETE": "v"}
    color = {"OPTIMIZATION_START": COLORS["blue"], "OPTIMIZATION_PREDICTED_FINISH": COLORS["gold"],
             "OPTIMIZATION_COMPLETE": COLORS["teal"], "PREDICTION_OVERRUN": COLORS["red"],
             "REPLAN": COLORS["orange"], "EXECUTION_START": COLORS["navy"], "EXECUTION_COMPLETE": COLORS["gray"]}
    for event_type, group in subset.groupby("event_type"):
        ax.scatter(group.timestamp, group.station_id, marker=marker[event_type], color=color[event_type],
                   s=50, label=event_type.replace("_", " ").title(), zorder=3)
    ax.set_xlabel("Simulation time (s)"); ax.set_ylabel("Station")
    ax.set_yticks(sorted(subset.station_id.unique())); ax.grid(axis="x", alpha=.18)
    ax.legend(ncol=3, fontsize=7, frameon=False, loc="upper center", bbox_to_anchor=(.5, -0.18))
    ax.set_title(f"Robust event-driven rolling horizon - {scenario}", loc="left", weight="bold")
    _save(fig, dirs, "Figure_C_rolling_horizon_trace", subset, dpi)


def _pair_timeline_events(
    events: pd.DataFrame,
    start_event: str,
    end_event: str,
) -> pd.DataFrame:
    """Pair start and completion events into time intervals."""

    # Use an explicit job/order identifier when the event table provides one.
    identifier = next(
        (
            column
            for column in (
                "order_id",
                "job_id",
                "task_id",
                "optimization_id",
                "request_id",
            )
            if column in events.columns
        ),
        None,
    )

    pairing_columns = ["station_id"]

    if identifier is not None:
        pairing_columns.append(identifier)

    def numbered_events(event_type: str, timestamp_name: str) -> pd.DataFrame:
        frame = (
            events.loc[
                events["event_type"] == event_type,
                pairing_columns + ["timestamp"],
            ]
            .sort_values(pairing_columns + ["timestamp"])
            .copy()
        )

        # Supports repeated optimization/execution attempts for the same order.
        frame["_occurrence"] = frame.groupby(
            pairing_columns,
            dropna=False,
        ).cumcount()

        return frame.rename(columns={"timestamp": timestamp_name})

    starts = numbered_events(start_event, "start_time")
    completions = numbered_events(end_event, "end_time")

    intervals = starts.merge(
        completions,
        on=pairing_columns + ["_occurrence"],
        how="inner",
        validate="one_to_one",
    )

    intervals = intervals[
        intervals["end_time"] >= intervals["start_time"]
    ].copy()

    intervals["duration"] = (
        intervals["end_time"] - intervals["start_time"]
    )

    return intervals.sort_values(
        ["station_id", "start_time", "end_time"]
    ).reset_index(drop=True)

def figure_c_timeline(
    events: pd.DataFrame,
    dirs: dict,
    dpi: int,
    start_time: float = 0.0,
    end_time: float | None = None,
) -> None:
    """
    Plot optimization and execution intervals for a Q2Q-P90 episode.

    Parameters
    ----------
    events:
        Event-level simulation results.

    dirs:
        Reporting output directories.

    dpi:
        Resolution of the PNG output.

    start_time:
        First simulation second displayed. Defaults to zero.

    end_time:
        Last simulation second displayed. If None, the complete episode
        is shown through its final relevant event.
    """

    required_columns = {
        "method",
        "replicate",
        "scenario",
        "event_type",
        "timestamp",
        "station_id",
    }
    missing_columns = required_columns.difference(events.columns)

    if missing_columns:
        raise ValueError(
            "Figure C is missing required event columns: "
            f"{sorted(missing_columns)}"
        )

    # First select the method, then determine its minimum replicate.
    method_events = events.loc[events["method"] == "Q2Q-P90"].copy()

    if method_events.empty:
        raise ValueError(
            "Figure C cannot be created because no Q2Q-P90 events were found."
        )

    selected_replicate = method_events["replicate"].min()

    replicate_events = method_events.loc[
        method_events["replicate"] == selected_replicate
    ].copy()

    if replicate_events.empty:
        raise ValueError(
            f"No Q2Q-P90 events were found for replicate {selected_replicate}."
        )

    selected_scenario = replicate_events["scenario"].iloc[0]

    subset = replicate_events.loc[
        replicate_events["scenario"] == selected_scenario
    ].copy()

    relevant_event_types = {
        "OPTIMIZATION_START",
        "OPTIMIZATION_PREDICTED_FINISH",
        "OPTIMIZATION_COMPLETE",
        "PREDICTION_OVERRUN",
        "REPLAN",
        "EXECUTION_START",
        "EXECUTION_COMPLETE",
    }

    subset = (
        subset.loc[subset["event_type"].isin(relevant_event_types)]
        .sort_values("timestamp")
        .copy()
    )

    if subset.empty:
        raise ValueError(
            "Figure C cannot be created because the selected episode "
            "contains no relevant timeline events."
        )

    # Default: show the entire selected episode from zero to its last event.
    window_start = float(start_time)

    if end_time is None:
        window_end = float(subset["timestamp"].max())
    else:
        window_end = float(end_time)

    if window_end <= window_start:
        raise ValueError(
            "end_time must be greater than start_time. "
            f"Received start_time={window_start} and end_time={window_end}."
        )

    optimization = _pair_timeline_events(
        subset,
        start_event="OPTIMIZATION_START",
        end_event="OPTIMIZATION_COMPLETE",
    )

    execution = _pair_timeline_events(
        subset,
        start_event="EXECUTION_START",
        end_event="EXECUTION_COMPLETE",
    )

    # Match each predicted finish to its corresponding optimization start.
    predicted = subset.loc[
        subset["event_type"] == "OPTIMIZATION_PREDICTED_FINISH"
    ].copy()

    identifier = next(
        (
            column
            for column in (
                "order_id",
                "job_id",
                "task_id",
                "optimization_id",
                "request_id",
            )
            if column in subset.columns
        ),
        None,
    )

    prediction_keys = ["station_id"]

    if identifier is not None:
        prediction_keys.append(identifier)

    if not predicted.empty and not optimization.empty:
        predicted = (
            predicted[prediction_keys + ["timestamp"]]
            .sort_values(prediction_keys + ["timestamp"])
            .copy()
        )

        predicted["_occurrence"] = predicted.groupby(
            prediction_keys,
            dropna=False,
        ).cumcount()

        predicted = predicted.rename(
            columns={"timestamp": "predicted_end_time"}
        )

        optimization = optimization.merge(
            predicted,
            on=prediction_keys + ["_occurrence"],
            how="left",
        )
    else:
        optimization["predicted_end_time"] = np.nan

    # Map original IDs such as 0–9 to display numbers 1–10.
    original_station_ids = sorted(
        subset["station_id"].dropna().unique()
    )
    station_number = {
        station_id: index + 1
        for index, station_id in enumerate(original_station_ids)
    }

    optimization["station_number"] = optimization["station_id"].map(
        station_number
    )
    execution["station_number"] = execution["station_id"].map(
        station_number
    )

    number_of_stations = len(original_station_ids)

    if number_of_stations == 0:
        raise ValueError("No valid station IDs were found for Figure C.")

    # Colors sampled from the reference figure.
    optimization_blue = "#1E9DC4"
    execution_peach = "#F1AA80"
    forecast_magenta = "#D94FC7"
    overrun_red = "#D62728"
    replan_orange = "#F26B38"
    border_color = "#202020"

    figure_height = max(5.2, 0.75 * number_of_stations + 2.2)
    fig, ax = plt.subplots(figsize=(12.0, figure_height))

    station_spacing = 2.0
    bar_height = 0.54
    forecast_height = 0.20

    lane_positions: dict[int, dict[str, float]] = {}

    for displayed_station in range(1, number_of_stations + 1):
        # Station 1 appears at the top of the figure.
        base_y = (
            number_of_stations - displayed_station
        ) * station_spacing

        execution_y = base_y + 0.22
        optimization_y = base_y + 1.05
        forecast_y = optimization_y + bar_height + 0.08

        lane_positions[displayed_station] = {
            "execution": execution_y,
            "optimization": optimization_y,
            "forecast": forecast_y,
        }

        if displayed_station < number_of_stations:
            ax.axhline(
                base_y - 0.20,
                color="#D8D8D8",
                linewidth=0.7,
                zorder=0,
            )

    def draw_interval(
        interval_start: float,
        interval_end: float,
        y_position: float,
        height: float,
        facecolor: str,
        edgecolor: str = border_color,
        hatch: str | None = None,
        linewidth: float = 0.8,
        zorder: int = 2,
    ) -> None:
        """Draw an interval clipped to the selected display window."""

        clipped_start = max(float(interval_start), window_start)
        clipped_end = min(float(interval_end), window_end)

        if clipped_end <= clipped_start:
            return

        ax.broken_barh(
            [(clipped_start, clipped_end - clipped_start)],
            (y_position, height),
            facecolors=facecolor,
            edgecolors=edgecolor,
            hatch=hatch,
            linewidth=linewidth,
            zorder=zorder,
        )

    # Draw predicted optimization windows first so actual bars remain visible.
    for row in optimization.itertuples(index=False):
        if pd.isna(row.predicted_end_time):
            continue

        station = int(row.station_number)

        draw_interval(
            interval_start=row.start_time,
            interval_end=row.predicted_end_time,
            y_position=lane_positions[station]["forecast"],
            height=forecast_height,
            facecolor="white",
            edgecolor=forecast_magenta,
            hatch="++",
            linewidth=0.9,
            zorder=1,
        )

    # Actual optimization intervals.
    for row in optimization.itertuples(index=False):
        station = int(row.station_number)

        draw_interval(
            interval_start=row.start_time,
            interval_end=row.end_time,
            y_position=lane_positions[station]["optimization"],
            height=bar_height,
            facecolor=optimization_blue,
        )

        # Highlight only the part exceeding the predicted completion time.
        if (
            not pd.isna(row.predicted_end_time)
            and row.end_time > row.predicted_end_time
        ):
            draw_interval(
                interval_start=row.predicted_end_time,
                interval_end=row.end_time,
                y_position=lane_positions[station]["optimization"],
                height=bar_height,
                facecolor="none",
                edgecolor=overrun_red,
                hatch="////",
                linewidth=1.0,
                zorder=3,
            )

    # Actual execution/palletization intervals.
    for row in execution.itertuples(index=False):
        station = int(row.station_number)

        draw_interval(
            interval_start=row.start_time,
            interval_end=row.end_time,
            y_position=lane_positions[station]["execution"],
            height=bar_height,
            facecolor=execution_peach,
        )

    # Retain explicit overrun and replan events without returning to the
    # original overlapping-marker design.
    marker_events = subset.loc[
        subset["event_type"].isin({"PREDICTION_OVERRUN", "REPLAN"})
        & subset["timestamp"].between(window_start, window_end)
        & subset["station_id"].isin(original_station_ids)
    ].copy()

    marker_events["station_number"] = marker_events["station_id"].map(
        station_number
    )

    for row in marker_events.itertuples(index=False):
        station = int(row.station_number)
        y_center = (
            lane_positions[station]["optimization"] + bar_height / 2
        )

        if row.event_type == "PREDICTION_OVERRUN":
            ax.scatter(
                row.timestamp,
                y_center,
                marker="X",
                s=42,
                color=overrun_red,
                edgecolor="white",
                linewidth=0.5,
                zorder=5,
            )
        else:
            ax.scatter(
                row.timestamp,
                y_center,
                marker="D",
                s=36,
                color=replan_orange,
                edgecolor="white",
                linewidth=0.5,
                zorder=5,
            )

    # Two explicit y-axis lanes for every station.
    y_ticks: list[float] = []
    y_labels: list[str] = []

    for displayed_station in range(1, number_of_stations + 1):
        positions = lane_positions[displayed_station]

        y_ticks.extend(
            [
                positions["optimization"] + bar_height / 2,
                positions["execution"] + bar_height / 2,
            ]
        )
        y_labels.extend(
            [
                f"Station {displayed_station} — Optimization",
                f"Station {displayed_station} — Execution",
            ]
        )

    ax.set_yticks(y_ticks)
    ax.set_yticklabels(y_labels)
    ax.set_xlim(window_start, window_end)
    ax.set_ylim(
        0,
        number_of_stations * station_spacing + 0.05,
    )

    ax.set_xlabel("Simulation time (s)")
    ax.set_ylabel("")
    ax.grid(
        axis="x",
        color="#B8B8B8",
        linewidth=0.6,
        alpha=0.35,
        zorder=0,
    )

    ax.set_title(
        "Robust event-driven rolling horizon\n"
        f"{selected_scenario} · replicate {selected_replicate}",
        loc="left",
        weight="bold",
    )

    legend_handles = [
        Patch(
            facecolor=optimization_blue,
            edgecolor=border_color,
            label="Optimization duration",
        ),
        Patch(
            facecolor="white",
            edgecolor=forecast_magenta,
            hatch="++",
            label="Optimization compute-time forecast",
        ),
        Patch(
            facecolor=execution_peach,
            edgecolor=border_color,
            label="Execution duration",
        ),
        Patch(
            facecolor="none",
            edgecolor=overrun_red,
            hatch="////",
            label="Prediction overrun",
        ),
        Line2D(
            [0],
            [0],
            marker="D",
            linestyle="none",
            markerfacecolor=replan_orange,
            markeredgecolor="white",
            markersize=7,
            label="Replan",
        ),
    ]

    ax.legend(
        handles=legend_handles,
        ncol=3,
        fontsize=8,
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.08),
    )

    # Export the intervals used to construct the figure.
    optimization_output = optimization.copy()
    optimization_output["activity"] = "Optimization"

    execution_output = execution.copy()
    execution_output["activity"] = "Execution"
    execution_output["predicted_end_time"] = np.nan

    figure_data = pd.concat(
        [optimization_output, execution_output],
        ignore_index=True,
        sort=False,
    )

    figure_data["display_window_start"] = window_start
    figure_data["display_window_end"] = window_end
    figure_data["scenario"] = selected_scenario
    figure_data["replicate"] = selected_replicate

    figure_data = figure_data.sort_values(
        ["station_number", "start_time", "activity"]
    ).reset_index(drop=True)

    fig.subplots_adjust(left=0.23, bottom=0.18)

    _save(
        fig,
        dirs,
        "Figure_C_rolling_horizon_trace",
        figure_data,
        dpi,
    )


def figure_d_two_station(decisions, dirs, dpi):
    q2q = decisions[(decisions.method == "Q2Q-P90") & (decisions.replicate == decisions.replicate.min())]
    scenario = q2q.scenario.iloc[0]
    q2q = q2q[q2q.scenario == scenario]
    q2q = q2q.copy()
    q2q["_conflict_count"] = q2q.conflict_set.map(lambda value: len(json.loads(value)))
    timestamp = q2q.groupby("timestamp")._conflict_count.sum().idxmax()
    sample = q2q[(q2q.timestamp == timestamp) & (q2q.station.isin([0, 1]))].copy()
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    for station, quad in enumerate(build_equal_quads(2)):
        ax.add_patch(Polygon(quad, closed=True, fill=False, lw=2, edgecolor=[COLORS["blue"], COLORS["orange"]][station]))
    for station, group in sample.groupby("station"):
        ax.scatter(group.quad_x, group.quad_y, s=np.where(group.chosen, 130, 45),
                   marker=["o", "s"][int(station)], facecolor=np.where(group.chosen, COLORS["red"], "white"),
                   edgecolor=[COLORS["blue"], COLORS["orange"]][int(station)], linewidth=1.5,
                   label=f"Station {int(station)+1}")
        for row in group[group.chosen].itertuples():
            ax.annotate("selected", (row.quad_x, row.quad_y), xytext=(5, 7), textcoords="offset points", fontsize=8)
        exact = group[group.exact_reference]
        if len(exact):
            ax.scatter(exact.quad_x, exact.quad_y, s=175, marker="D", facecolor="none",
                       edgecolor=COLORS["gold"], linewidth=2.0, label="Exact weighted reference" if station == 0 else None)
    coordinates = sample.set_index("candidate_id")[["quad_x", "quad_y"]].to_dict("index")
    drawn = set()
    for row in sample.itertuples():
        for other in json.loads(row.conflict_set):
            key = tuple(sorted([row.candidate_id, other]))
            if key in drawn or other not in coordinates:
                continue
            drawn.add(key)
            a, b = coordinates[row.candidate_id], coordinates[other]
            ax.add_patch(FancyArrowPatch(
                (a["quad_x"], a["quad_y"]), (b["quad_x"], b["quad_y"]),
                arrowstyle="-", connectionstyle="arc3,rad=0.16",
                color=COLORS["red"], linestyle="--", linewidth=1.5, alpha=.75,
            ))
    ax.scatter([0], [0], marker="*", s=180, color=COLORS["gold"], edgecolor=COLORS["navy"], label="Common ideal")
    ax.axhline(0, color="#CBD5E1", lw=.8); ax.axvline(0, color="#CBD5E1", lw=.8)
    ax.set_aspect("equal"); ax.set_xlabel("Shared Quad2Quad x"); ax.set_ylabel("Shared Quad2Quad y")
    handles, labels = ax.get_legend_handles_labels()
    if drawn:
        handles.append(Line2D([], [], color=COLORS["red"], ls="--", lw=1.5))
        labels.append("Resource conflict")
    ax.legend(handles, labels, frameon=False)
    ax.set_title("Two-station numerical conflict example", loc="left", weight="bold")
    _save(fig, dirs, "Figure_D_quad2quad_conflict_2station", sample, dpi)


def figure_e_predictor(predictions, dirs, dpi):
    data = predictions.copy()
    fig, ax = plt.subplots(figsize=(6.6, 5.3))
    limit = max(data.actual_runtime.max(), data.predicted_p95.max(), 1)
    ax.scatter(data.actual_runtime + 1, data.predicted_p50 + 1, alpha=.5, s=18, color=COLORS["blue"], label="P50")
    ax.scatter(data.actual_runtime + 1, data.predicted_p90 + 1, alpha=.35, s=18, color=COLORS["orange"], label="P90")
    ax.plot([1, limit + 1], [1, limit + 1], color=COLORS["gray"], ls="--", label="Perfect prediction")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("Actual optimizer runtime + 1 (s)")
    ax.set_ylabel("Out-of-fold prediction + 1 (s)"); ax.legend(frameon=False)
    ax.set_title("Optimizer runtime prediction", loc="left", weight="bold")
    _save(fig, dirs, "Figure_E_runtime_prediction", data, dpi)


def figure_f_ablation(paired, dirs, dpi):
    data = paired[paired.metric == "total_retrievals"].copy()
    if len(data) == 0:
        return
    data = data.groupby("method")[["mean_difference", "ci_low", "ci_high"]].mean().reset_index()
    data = data.sort_values("mean_difference")
    y = np.arange(len(data))
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.errorbar(data.mean_difference, y,
                xerr=[data.mean_difference - data.ci_low, data.ci_high - data.mean_difference],
                fmt="o", color=COLORS["teal"], ecolor=COLORS["navy"], capsize=3)
    ax.axvline(0, color=COLORS["gray"], ls="--"); ax.set_yticks(y, data.method)
    ax.set_xlabel("Paired retrieval difference versus IND (95% CI; lower is better)")
    ax.set_title("Paired system-method comparison", loc="left", weight="bold")
    _save(fig, dirs, "Figure_F_component_ablation", data, dpi)


def figure_g_robustness(robustness, dirs, dpi):
    data = robustness.groupby("prediction_bias")[["total_retrievals", "makespan", "replans"]].mean().reset_index()
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.4))
    for ax, metric, label, color in zip(axes, ["total_retrievals", "makespan", "replans"],
                                        ["Retrievals", "Makespan (s)", "Replans"], [COLORS["blue"], COLORS["orange"], COLORS["red"]]):
        ax.plot(100 * data.prediction_bias, data[metric], marker="o", color=color)
        ax.axvline(0, color=COLORS["gray"], ls="--", lw=1); ax.set_xlabel("Prediction bias (%)"); ax.set_ylabel(label)
    fig.suptitle("Runtime-prediction robustness", x=.06, ha="left", weight="bold")
    _save(fig, dirs, "Figure_G_prediction_robustness", data, dpi)


def figure_h_scalability(benchmarks, dirs, dpi):
    data = benchmarks.groupby(["stations", "candidate_count", "selector"]).runtime_seconds.median().reset_index()
    selectors = sorted(data.selector.unique())
    fig, axes = plt.subplots(2, 3, figsize=(10, 6), sharex=True, sharey=True)
    colors = plt.cm.viridis(np.linspace(.15, .9, data.stations.nunique()))
    for ax, selector in zip(axes.flat, selectors):
        group = data[data.selector == selector]
        for color, (stations, part) in zip(colors, group.groupby("stations")):
            ax.plot(part.candidate_count, part.runtime_seconds, marker="o", color=color,
                    label=f"M={stations}")
        ax.set_yscale("log"); ax.axhline(1.0, color=COLORS["red"], ls="--", lw=1)
        ax.set_title(selector.upper()); ax.grid(alpha=.15)
    for ax in axes.flat[len(selectors):]:
        ax.axis("off")
    axes[0, 0].legend(frameon=False, fontsize=7)
    fig.supxlabel("Candidates per station"); fig.supylabel("Median selector runtime (s, log scale)")
    fig.suptitle("Selector scalability", x=.06, ha="left", weight="bold")
    _save(fig, dirs, "Figure_H_selector_scalability", data, dpi)


def figure_i_paired(episodes, dirs, dpi):
    keys = ["scenario", "replicate", "seed"]
    x = episodes[episodes.method == "IND"][keys + ["total_retrievals"]]
    y = episodes[episodes.method == "Q2Q-P90"][keys + ["total_retrievals"]]
    data = x.merge(y, on=keys, suffixes=("_IND", "_Q2Q"))
    fig, ax = plt.subplots(figsize=(5.7, 5.2))
    ax.scatter(data.total_retrievals_IND, data.total_retrievals_Q2Q, color=COLORS["teal"], alpha=.65)
    limit = max(data.total_retrievals_IND.max(), data.total_retrievals_Q2Q.max(), 1)
    ax.plot([0, limit], [0, limit], color=COLORS["gray"], ls="--")
    ax.set_xlabel("IND retrievals"); ax.set_ylabel("Q2Q-P90 retrievals")
    ax.set_title("Paired system-performance comparison", loc="left", weight="bold")
    _save(fig, dirs, "Figure_I_paired_performance", data, dpi)


def revised_empirical_figures(empirical, dirs, dpi):
    data = empirical[["order_id", "box_count", "product_count", "shannon_entropy", "actual_runtime"]].copy()
    fig, ax = plt.subplots(figsize=(6.8, 5.1))
    scatter = ax.scatter(data.box_count, data.product_count, c=np.log1p(data.actual_runtime),
                         cmap="viridis", s=18, alpha=.7)
    fig.colorbar(scatter, ax=ax, label="log(1 + runtime)")
    ax.set_xlabel("Boxes"); ax.set_ylabel("Product variety")
    ax.set_title("Empirical order complexity", loc="left", weight="bold")
    _save(fig, dirs, "Revised_Figure_2_order_complexity", data, dpi)

    box = empirical[["order_id", "recomputed_entropy_quintile", "actual_runtime"]].copy()
    order = sorted(box.recomputed_entropy_quintile.unique(), key=lambda x: int(str(x).split()[-1]))
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.boxplot([box.loc[box.recomputed_entropy_quintile == label, "actual_runtime"] for label in order],
               labels=order, showfliers=False)
    ax.set_yscale("symlog", linthresh=1); ax.set_ylabel("Measured optimizer runtime (s)")
    ax.tick_params(axis="x", rotation=25)
    ax.set_title("Runtime by recomputed entropy interval", loc="left", weight="bold")
    _save(fig, dirs, "Revised_Figure_13_runtime_by_entropy", box, dpi)


def make_figures(config: dict, output_dir=None):
    _base_style()
    raw = result_dirs(config)
    dirs = _report_dirs(config, output_dir)
    dpi = int(config["reporting"]["figure_dpi"])
    episodes = read_table(raw["raw"] / "episodes")
    events = read_table(raw["raw"] / "events")
    decisions = read_table(raw["raw"] / "decisions")
    predictions = read_table(raw["raw"] / "prediction_oof")
    robustness = read_table(raw["raw"] / "prediction_robustness")
    benchmarks = read_table(raw["raw"] / "selector_benchmarks")
    empirical = read_table(raw["raw"] / "empirical_orders")
    paired = read_table(raw["statistics"] / "paired_comparisons")
    # figure_a_architecture(dirs, dpi)
    # figure_b_sequence(dirs, dpi)
    """Rolling Horizon Figure"""
    figure_c_timeline(events, dirs, dpi)
    # figure_c_timeline(events, dirs, dpi, start_time=500, end_time=1500,)
    # figure_d_two_station(decisions, dirs, dpi)
    # figure_e_predictor(predictions, dirs, dpi)
    # figure_f_ablation(paired, dirs, dpi)
    # figure_g_robustness(robustness, dirs, dpi)
    # figure_h_scalability(benchmarks, dirs, dpi)
    # figure_i_paired(episodes, dirs, dpi)
    revised_empirical_figures(empirical, dirs, dpi)
    return dirs


def make_scalability_figure(config: dict, benchmarks=None, output_dir=None):
    """Create the dedicated Figure H without requiring the other experiments."""
    _base_style()
    raw = result_dirs(config)
    dirs = _report_dirs(config, output_dir)
    if benchmarks is None:
        benchmarks = read_table(raw["raw"] / "selector_benchmarks")
    figure_h_scalability(benchmarks, dirs, int(config["reporting"]["figure_dpi"]))
    return dirs


def _flatten_config(value, prefix=""):
    rows = []
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).startswith("_"):
                continue
            rows.extend(_flatten_config(item, f"{prefix}.{key}" if prefix else str(key)))
    else:
        rows.append({"parameter": prefix, "value": json.dumps(value) if isinstance(value, list) else value})
    return rows


def _markdown(frame):
    columns = list(frame.columns)
    lines = ["| " + " | ".join(columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in frame.fillna("").astype(str).itertuples(index=False, name=None):
        lines.append("| " + " | ".join(value.replace("|", "\\|") for value in row) + " |")
    return "\n".join(lines)


def _write_table_formats(frame, dirs, name):
    frame.to_csv(dirs["tables"] / f"{name}.csv", index=False)
    (dirs["tables"] / f"{name}.md").write_text(_markdown(frame), encoding="utf-8")
    def tex(value):
        if isinstance(value, float):
            value = "" if np.isnan(value) else f"{value:.4g}"
        replacements = {
            "\\": "\\textbackslash{}", "&": "\\&", "%": "\\%", "$": "\\$",
            "#": "\\#", "_": "\\_", "{": "\\{", "}": "\\}",
        }
        return "".join(replacements.get(char, char) for char in str(value))
    lines = [
        "\\begin{tabular}{" + "l" * len(frame.columns) + "}",
        "\\toprule",
        " & ".join(tex(c) for c in frame.columns) + " \\\\",
        "\\midrule",
    ]
    lines.extend(" & ".join(tex(v) for v in row) + " \\\\" for row in frame.itertuples(index=False, name=None))
    lines.extend(["\\bottomrule", "\\end{tabular}", ""])
    (dirs["tables"] / f"{name}.tex").write_text("\n".join(lines), encoding="utf-8")


def make_tables(config: dict, output_dir=None):
    raw = result_dirs(config); dirs = _report_dirs(config, output_dir)
    display_config = json.loads(json.dumps({k: v for k, v in config.items() if not k.startswith("_")}))
    project_root = Path(config["_project_root"])
    for key in ["dataset", "legacy_results", "results_dir"]:
        try:
            display_config["paths"][key] = str(Path(display_config["paths"][key]).resolve().relative_to(project_root))
        except ValueError:
            display_config["paths"][key] = Path(display_config["paths"][key]).name
    table_d = pd.DataFrame(_flatten_config(display_config))
    summary_path = raw["logs"] / "candidate_run_summary.json"
    if summary_path.exists():
        run_summary = json.loads(summary_path.read_text(encoding="utf-8"))
        table_d = pd.concat([table_d, pd.DataFrame([
            {"parameter": f"actual_candidate_run.{key}", "value": json.dumps(value) if isinstance(value, (list, dict)) else value}
            for key, value in run_summary.items()
        ])], ignore_index=True)
    table_e = pd.DataFrame([{"method": name, **properties} for name, properties in METHOD_REGISTRY.items()])
    table_f = read_table(raw["statistics"] / "runtime_metrics")
    episode_summary = read_table(raw["statistics"] / "episode_summary")
    paired = read_table(raw["statistics"] / "paired_comparisons")
    outcome_columns = [c for c in [
        "scenario", "method", "total_retrievals_mean", "makespan_mean",
        "repeated_retrievals_mean", "throughput_orders_per_hour_mean",
        "conflicts_detected_mean", "conflicts_committed_mean", "fallbacks_mean",
        "replans_mean", "prediction_overruns_mean", "coordination_deadline_met_mean",
    ] if c in episode_summary]
    table_g = paired.merge(
        episode_summary[outcome_columns],
        on=["scenario", "method"], how="left"
    )
    table_h = read_table(raw["statistics"] / "packing_equivalence")
    benchmarks = read_table(raw["raw"] / "selector_benchmarks")
    table_i = benchmarks.groupby(["stations", "candidate_count", "overlap", "selector"]).agg(
        conflicts=("conflicts", "mean"), deferral_rate=("deferral_rate", "mean"),
        coordinator_runtime_median_seconds=("runtime_seconds", "median"),
        coordinator_runtime_p90_seconds=("runtime_seconds", lambda x: np.quantile(x, .90)),
        coordinator_runtime_p95_seconds=("runtime_seconds", lambda x: np.quantile(x, .95)),
        coordinator_runtime_max_seconds=("runtime_seconds", "max"),
        exact_objective_gap_mean=("objective_gap_vs_exact", "mean"),
        exact_objective_gap_max=("objective_gap_vs_exact", "max"),
        exact_selection_agreement_pct=("selection_agreement_exact", lambda x: 100 * np.mean(x)),
        deadline_success_pct=("deadline_met", lambda x: 100 * np.mean(x)),
    ).reset_index()
    table_i["deferral_definition"] = "station deferred: no conflict-free simultaneous candidate selected"
    for name, frame in [
        ("Table_D_experimental_settings", table_d), ("Table_E_baselines_ablations", table_e),
        ("Table_F_runtime_prediction", table_f), ("Table_G_main_results", table_g),
        ("Table_H_packing_equivalence", table_h), ("Table_I_conflict_scalability", table_i),
        ("Revised_Table_4_system_performance", table_g), ("Revised_Table_5_packing_quality", table_h),
        ("Revised_Table_6_scalability", table_i),
    ]:
        _write_table_formats(frame, dirs, name)
    return dirs
