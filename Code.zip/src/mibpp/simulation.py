from __future__ import annotations

import itertools
import json
import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .candidates import expand_candidates_for_simulation, select_orders
from .coordination import candidates_conflict, score_candidate, select_candidates, select_exact
from .dataio import read_table, result_dirs, write_table
from .quad2quad import embed_station_candidates


@dataclass(order=True)
class Event:
    timestamp: float
    event_type: str = field(compare=False)
    station_id: int = field(compare=False)
    order_id: int = field(compare=False)
    candidate_id: str = field(default="", compare=False)
    resource_id: str = field(default="", compare=False)
    metadata: str = field(default="{}", compare=False)


def _event(events, timestamp, event_type, station, order_id, candidate_id="", resource_id="", **metadata):
    events.append(Event(float(timestamp), event_type, int(station), int(order_id), str(candidate_id),
                        str(resource_id), json.dumps(metadata, sort_keys=True)))


def _prediction(row, method, bias):
    if method == "ORACLE":
        value = row.actual_runtime
    elif method in {"GC-P90", "Q2Q-P90"}:
        value = row.predicted_p90
    elif method == "GC-P50":
        value = row.predicted_p50
    else:
        value = row.actual_runtime  # no look-ahead; decision is triggered only when optimization finishes
    return max(0.0, float(value) * (1.0 + float(bias)))


def _arrivals(count, model, mean_seconds, rng):
    if model == "synchronous":
        return np.zeros(count)
    return np.cumsum(rng.exponential(mean_seconds, size=count))


def run_episode(config: dict, empirical: pd.DataFrame, predictions: pd.DataFrame, pool: pd.DataFrame,
                order_ids: list[int], station_count: int, method: str, scenario: str, replicate: int,
                seed: int, load_level="medium", scarcity_level="high",
                prediction_bias=0.0, order_set_id=0,
                timing_replication=0) -> tuple[dict, list[dict], list[dict], list[Event], list[dict]]:
    sim = config["simulation"]
    rng = np.random.default_rng(seed)
    station_count = 1 if method == "SEQ" else int(station_count)
    arrivals = _arrivals(len(order_ids), sim["arrival_model"], sim["mean_interarrival_seconds"][load_level], rng)
    empirical_map = empirical.set_index("order_id")
    pred_map = predictions.set_index("order_id")
    station_available = np.zeros(station_count)
    asset_available: dict[int, float] = {}
    asset_location: dict[int, int] = {}
    high_bay = np.zeros(int(sim["high_bay_servers"]))
    amrs = np.zeros(int(sim["amrs"]))
    events: list[Event] = []
    order_rows, decision_rows, conflict_rows = [], [], []
    total_coordination = total_idle = 0.0
    total_retrievals = repeated_retrievals = replans = overruns = fallbacks = 0
    max_buffer = 0
    total_conflicts_detected = 0
    asset_intervals: dict[object, list[tuple[float, float, int, int]]] = {}
    equivalent_pallets = (
        int(sim["low_scarcity_equivalent_pallets_per_product"])
        if scarcity_level == "low" else int(sim["equivalent_pallets_per_product"])
    )

    for wave_start in range(0, len(order_ids), station_count):
        wave_ids = order_ids[wave_start: wave_start + station_count]
        groups, contexts = [], []
        for local_station, order_id in enumerate(wave_ids):
            position = wave_start + local_station
            row = empirical_map.loc[int(order_id)]
            pred = pred_map.loc[int(order_id)]
            arrival = float(arrivals[position])
            actual_runtime = float(pred.actual_runtime)
            predicted_runtime = _prediction(pred, method, prediction_bias)
            optimization_start = arrival
            actual_optimization_finish = optimization_start + actual_runtime
            predicted_finish = optimization_start + predicted_runtime
            planning_ready = max(predicted_finish, station_available[local_station])
            actual_ready = max(actual_optimization_finish, station_available[local_station])
            execution_seconds = float(row.box_count) * float(sim["robot_seconds_per_item"])
            execution_seconds *= max(0.1, float(rng.normal(1.0, sim["execution_noise_cv"])))
            visible_assets = asset_available if method not in {"IND", "SEQ"} else {}
            candidates = expand_candidates_for_simulation(
                pool, int(order_id), local_station, planning_ready, execution_seconds,
                visible_assets, predicted_runtime, equivalent_pallets,
                float(sim.get("block_handling_seconds", 0.0)),
            )
            groups.append(candidates)
            contexts.append(dict(order_id=int(order_id), row=row, arrival=arrival,
                                 optimization_start=optimization_start, actual_runtime=actual_runtime,
                                 predicted_runtime=predicted_runtime, predicted_finish=predicted_finish,
                                 actual_finish=actual_optimization_finish, actual_ready=actual_ready,
                                 execution_seconds=execution_seconds))
            _event(events, arrival, "ORDER_ARRIVAL", local_station, order_id)
            _event(events, optimization_start, "OPTIMIZATION_START", local_station, order_id)
            _event(events, predicted_finish, "OPTIMIZATION_PREDICTED_FINISH", local_station, order_id)
            _event(events, actual_optimization_finish, "OPTIMIZATION_COMPLETE", local_station, order_id)
            if actual_optimization_finish > predicted_finish + 1e-9:
                overruns += 1; replans += 1
                _event(events, predicted_finish, "PREDICTION_OVERRUN", local_station, order_id,
                       actual_finish=actual_optimization_finish)
                _event(events, actual_optimization_finish, "REPLAN", local_station, order_id, reason="optimizer_overrun")

        coordination_time = min(c["predicted_finish"] for c in contexts)
        for station, context in enumerate(contexts):
            _event(events, coordination_time, "COORDINATION_TRIGGER", station, context["order_id"])
        chosen, meta = select_candidates(groups, method)
        total_coordination += float(meta["coordination_runtime_seconds"])
        total_conflicts_detected += int(meta.get("raw_conflicts", 0))
        if method == "Q2Q-P90":
            exact_reference, _ = select_exact(groups, "weighted")
            exact_reference_ids = {c["candidate_id"] for c in exact_reference}
        else:
            exact_reference_ids = set()

        embedded = [embed_station_candidates(group, i, len(groups)) for i, group in enumerate(groups)]
        chosen_ids = {c["candidate_id"] for c in chosen}
        conflict_sets = {}
        for group in groups:
            for candidate in group:
                conflict_sets[candidate["candidate_id"]] = sorted({
                    other["candidate_id"]
                    for other_group in groups
                    for other in other_group
                    if other["station"] != candidate["station"] and candidates_conflict(candidate, other)
                })
        for station, group in enumerate(embedded):
            for candidate in group:
                decision_rows.append({
                    "scenario": scenario, "method": method, "replicate": replicate, "seed": seed,
                    "order_set_id": order_set_id, "timing_replication": timing_replication,
                    "timestamp": coordination_time, "decision_time": coordination_time,
                    "station": station, "order_id": int(candidate["order_id"]),
                    "candidate_id": candidate["candidate_id"], "predicted_retrievals": candidate["predicted_retrievals"],
                    "predicted_completion": candidate["predicted_completion"],
                    "normalized_retrievals": candidate["normalized_retrievals"],
                    "normalized_completion": candidate["normalized_completion"], "quad_x": candidate["quad_x"],
                    "quad_y": candidate["quad_y"], "quad_distance": candidate["quad_distance"],
                    "chosen": candidate["candidate_id"] in chosen_ids, "fallback": candidate.get("fallback", False),
                    "fallback_reason": candidate.get("fallback_reason", ""),
                    "selector": meta.get("selector"), "global_objective": meta.get("objective", np.nan),
                    "objective_value": score_candidate(candidate, meta.get("selector", "weighted")),
                    "required_resources": json.dumps(candidate.get("resources", [])),
                    "exact_reference": candidate["candidate_id"] in exact_reference_ids,
                    "conflict_set": json.dumps(conflict_sets[candidate["candidate_id"]]),
                })
        for (s1, g1), (s2, g2) in itertools.combinations(enumerate(groups), 2):
            for a in g1:
                for b in g2:
                    if candidates_conflict(a, b):
                        conflict_rows.append({"scenario": scenario, "method": method, "replicate": replicate,
                                              "station_a": s1, "station_b": s2, "candidate_a": a["candidate_id"],
                                              "candidate_b": b["candidate_id"], "committed": False})

        for station, (candidate, context) in enumerate(zip(chosen, contexts)):
            coordinator_candidate_id = candidate["candidate_id"]
            fallback_selected = bool(candidate.get("fallback"))
            fallback_reason = candidate.get("fallback_reason", "")
            if candidate.get("fallback"):
                fallbacks += 1
                candidate = next(c for c in groups[station] if not c.get("fallback"))
            order_id = context["order_id"]
            resources = list(candidate["resources"])
            start = max(context["actual_ready"], station_available[station])
            recalls = 0; reuse = 0
            for product in candidate["resource_sequence"]:
                _event(events, start, "RESOURCE_REQUEST", station, order_id, candidate["candidate_id"], product)
                visible_reuse = method not in {"IND", "SEQ"} and product in asset_available
                if visible_reuse:
                    reuse += 1
                    start = max(start, asset_available[product])
                    if asset_location.get(product) != station:
                        start += float(sim["station_transfer_seconds"])
                else:
                    recalls += 1
                    if product in asset_available:
                        repeated_retrievals += 1
                        start = max(start, asset_available[product])
                    server = int(np.argmin(high_bay)); retrieval_start = max(start, high_bay[server])
                    retrieval_end = retrieval_start + float(sim["high_bay_retrieval_seconds"])
                    high_bay[server] = retrieval_end
                    amr = int(np.argmin(amrs)); transport_start = max(retrieval_end, amrs[amr])
                    transport_end = transport_start + float(sim["amr_transport_seconds"])
                    amrs[amr] = transport_end; start = max(start, transport_end)
                    _event(events, retrieval_start, "HIGH_BAY_RETRIEVAL_START", station, order_id,
                           candidate["candidate_id"], product, server=server)
                    _event(events, retrieval_end, "HIGH_BAY_RETRIEVAL_COMPLETE", station, order_id,
                           candidate["candidate_id"], product, server=server)
                    _event(events, transport_start, "AMR_TRANSPORT_START", station, order_id,
                           candidate["candidate_id"], product, amr=amr)
                    _event(events, transport_end, "AMR_TRANSPORT_COMPLETE", station, order_id,
                           candidate["candidate_id"], product, amr=amr)
                occupancy = min(len(resources), int(sim["buffer_capacity"]))
                max_buffer = max(max_buffer, occupancy)
                _event(events, start, "BUFFER_ENTER", station, order_id, candidate["candidate_id"], product,
                       occupancy=occupancy, capacity=int(sim["buffer_capacity"]))
                _event(events, start, "RESOURCE_RESERVED", station, order_id, candidate["candidate_id"], product)
            execution_start = start
            execution_duration = float(candidate.get(
                "candidate_execution_seconds", context["execution_seconds"]
            ))
            completion = execution_start + execution_duration
            idle = max(0.0, execution_start - station_available[station])
            total_idle += idle
            _event(events, execution_start, "EXECUTION_START", station, order_id, candidate["candidate_id"])
            actual_sequence = list(candidate.get("resource_sequence", resources)) or resources
            slot = execution_duration / max(len(actual_sequence), 1)
            for sequence_index, product in enumerate(actual_sequence):
                reservation_start = execution_start + sequence_index * slot
                reservation_end = execution_start + (sequence_index + 1) * slot
                for previous_start, previous_end, previous_station, previous_order in asset_intervals.get(product, []):
                    if previous_start < reservation_end and reservation_start < previous_end:
                        raise AssertionError(
                            f"Asset {product} overlaps between order {previous_order} at station "
                            f"{previous_station} and order {order_id} at station {station}"
                        )
                asset_intervals.setdefault(product, []).append((reservation_start, reservation_end, station, order_id))
                asset_available[product] = reservation_end
                asset_location[product] = station
                _event(events, reservation_end, "PRODUCT_PALLET_RELEASE", station, order_id,
                       candidate["candidate_id"], product)
            _event(events, completion, "EXECUTION_COMPLETE", station, order_id, candidate["candidate_id"])
            station_available[station] = completion
            total_retrievals += recalls
            order_rows.append({
                "scenario": scenario, "load_level": load_level, "method": method, "replicate": replicate,
                "seed": seed, "order_set_id": order_set_id, "timing_replication": timing_replication,
                "order_id": order_id, "station": station, "arrival": context["arrival"],
                "optimization_start": context["optimization_start"], "actual_runtime": context["actual_runtime"],
                "predicted_runtime": context["predicted_runtime"], "execution_start": execution_start,
                "completion": completion, "waiting": execution_start - context["arrival"], "retrievals": recalls,
                "resource_reuse": reuse, "selected_candidate": candidate["candidate_id"],
                "coordinator_selected_candidate": coordinator_candidate_id,
                "fallback_selected": fallback_selected, "fallback_reason": fallback_reason,
                "compactness": candidate.get("compactness", np.nan), "homogeneity": candidate.get("homogeneity", np.nan),
                "pallet_volume_utilization_pct": candidate.get("pallet_volume_utilization_pct", np.nan),
                "prediction_bias": prediction_bias,
            })
    makespan = float(max(station_available) if len(station_available) else 0)
    episode = {
        "scenario": scenario, "load_level": load_level, "scarcity_level": scarcity_level,
        "method": method, "replicate": replicate, "seed": seed,
        "order_set_id": order_set_id, "timing_replication": timing_replication,
        "order_count": len(order_ids), "station_count": station_count, "total_retrievals": total_retrievals,
        "repeated_retrievals": repeated_retrievals, "completion_time": float(sum(r["completion"] for r in order_rows)),
        "makespan": makespan, "throughput_orders_per_hour": len(order_ids) * 3600 / makespan if makespan else 0,
        "idle_time": total_idle, "conflicts_detected": total_conflicts_detected,
        "conflicts_committed": 0, "fallbacks": fallbacks, "replans": replans,
        "prediction_overruns": overruns, "coordination_runtime": total_coordination,
        "coordination_deadline_met": bool(total_coordination <= float(sim["coordination_deadline_seconds"])),
        "max_buffer_occupancy": max_buffer, "prediction_bias": prediction_bias,
    }
    return episode, order_rows, decision_rows, sorted(events), conflict_rows


def run_simulations(config: dict, empirical=None, predictions=None, pool=None) -> dict[str, pd.DataFrame]:
    dirs = result_dirs(config)
    empirical = empirical if empirical is not None else read_table(dirs["raw"] / "empirical_orders")
    predictions = predictions if predictions is not None else read_table(dirs["raw"] / "prediction_oof")
    pool = pool if pool is not None else read_table(dirs["raw"] / "packing_candidates")
    available = empirical[empirical.order_id.isin(pool.order_id.unique())].copy()
    outputs = {key: [] for key in ["episodes", "orders", "decisions", "events", "conflicts"]}
    methods = config["experiment"]["methods"]
    order_set_count = int(config["experiment"].get("order_set_replicates", 1))
    for overlap_index, overlap in enumerate(config["experiment"].get("overlap_levels", ["high"])):
        for load in config["experiment"].get("load_levels", ["medium"]):
            for scarcity in config["experiment"].get("resource_scarcity_levels", ["high"]):
                scenario = f"{load}_load_{overlap}_overlap_{scarcity}_scarcity"
                for replicate in range(int(config["experiment"]["replicates"])):
                    order_set_id = replicate % order_set_count
                    timing_replication = replicate // order_set_count
                    order_seed = int(config["seed"]) + overlap_index * 7919 + order_set_id * 15485863
                    ids = select_orders(
                        available, int(config["experiment"]["num_orders"]), overlap, order_seed
                    )
                    seed = int(config["seed"]) + replicate * 1009 + sum(map(ord, scenario))
                    for method in methods:
                        episode, orders, decisions, events, conflicts = run_episode(
                            config, empirical, predictions, pool, ids, int(config["experiment"]["num_stations"]),
                            method, scenario, replicate, seed, load, scarcity,
                            order_set_id=order_set_id, timing_replication=timing_replication,
                        )
                        outputs["episodes"].append(episode); outputs["orders"].extend(orders)
                        outputs["decisions"].extend(decisions); outputs["conflicts"].extend(conflicts)
                        outputs["events"].extend([e.__dict__ | {"scenario": scenario, "method": method,
                                                                "replicate": replicate, "seed": seed,
                                                                "order_set_id": order_set_id,
                                                                "timing_replication": timing_replication} for e in events])
    frames = {key: pd.DataFrame(value) for key, value in outputs.items()}
    for key, frame in frames.items():
        write_table(frame, dirs["raw"] / key)
    if len(frames["decisions"]):
        selected = frames["decisions"][frames["decisions"].chosen].copy()
        selected = selected[[
            "scenario", "replicate", "order_set_id", "timing_replication", "decision_time",
            "station", "method", "candidate_id", "objective_value", "required_resources",
            "fallback", "fallback_reason",
        ]].rename(columns={"candidate_id": "selected_candidate_id"})
        write_table(selected, dirs["raw"] / "selected_decisions")
    return frames


def run_prediction_robustness(config: dict, empirical=None, predictions=None, pool=None) -> pd.DataFrame:
    dirs = result_dirs(config)
    empirical = empirical if empirical is not None else read_table(dirs["raw"] / "empirical_orders")
    predictions = predictions if predictions is not None else read_table(dirs["raw"] / "prediction_oof")
    pool = pool if pool is not None else read_table(dirs["raw"] / "packing_candidates")
    available = empirical[empirical.order_id.isin(pool.order_id.unique())]
    ids = select_orders(available, int(config["experiment"]["num_orders"]), "high", int(config["seed"]))
    rows = []
    reps = min(10, int(config["experiment"]["replicates"]))
    for bias in config["robustness"]["prediction_biases"]:
        for replicate in range(reps):
            episode, *_ = run_episode(
                config, empirical, predictions, pool, ids, int(config["experiment"]["num_stations"]),
                "Q2Q-P90", f"robustness_bias_{bias:+.2f}", replicate,
                int(config["seed"]) + replicate * 1009, "medium", "high", float(bias),
            )
            rows.append(episode)
    frame = pd.DataFrame(rows)
    write_table(frame, dirs["raw"] / "prediction_robustness")
    return frame
