from __future__ import annotations

import json
import hashlib
import time
from dataclasses import asdict

import numpy as np
import pandas as pd

from .dataio import (
    read_table, result_dirs, sha256, write_json, write_json_atomic, write_table,
    write_table_atomic,
)
from .features import load_and_canonicalize
from .legacy_adapter import (
    OptimizerTimeoutError,
    run_original_optimizer_with_timeout,
)


LAYER_SORT_STRATEGIES = ("fill_first", "weight_first", "group_first")
CANDIDATE_GENERATION_VERSION = 2
OPTIMIZATION_PROGRESS = {
    "total": 0, "attempted": 0, "successful": 0, "failed": 0,
    "timed_out": 0, "skipped": 0, "remaining": 0,
    "current_order_id": None, "current_candidate_index": None,
    "current_strategy": None,
}


def _stable_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _candidate_signature(candidate_config: dict) -> str:
    payload = {
        "version": CANDIDATE_GENERATION_VERSION,
        "strategies": list(candidate_config["layer_sort_strategies"]),
        "pallet_dimensions_mm": candidate_config["pallet_dimensions_mm"],
        "ga": candidate_config["ga"],
        "root_seed": candidate_config["root_seed"],
        "dataset_sha256": candidate_config["dataset_sha256"],
    }
    return hashlib.sha256(_stable_json(payload).encode()).hexdigest()


def _resource_set(row: dict) -> tuple:
    return tuple(sorted(map(int, json.loads(row["required_products_json"]))))


def _resource_sequence(row: dict) -> tuple:
    return tuple(map(int, json.loads(row["execution_sequence_json"])))


def _objective_vector(row: dict) -> tuple:
    return (
        int(row["num_blocks"]), round(float(row["compactness"]), 8),
        round(float(row["heterogeneity"]), 8),
        round(float(row["pallet_volume_utilization_pct"]), 8),
    )


def candidate_diversity_audit(pool: pd.DataFrame, attempts: pd.DataFrame) -> pd.DataFrame:
    rows = []
    order_ids = sorted(set(pool.get("order_id", pd.Series(dtype=int)).dropna().astype(int)) |
                       set(attempts.get("order_id", pd.Series(dtype=int)).dropna().astype(int)))
    for order_id in order_ids:
        candidates = pool[pool.order_id == order_id] if len(pool) else pool
        order_attempts = attempts[attempts.order_id == order_id] if len(attempts) else attempts
        records = candidates.to_dict("records")
        rows.append({
            "order_id": order_id,
            "optimizer_executions": int(len(order_attempts)),
            "successful_executions": int((order_attempts.status == "success").sum()) if len(order_attempts) else 0,
            "unique_packing_fingerprints": len({r["packing_fingerprint"] for r in records}),
            "unique_objective_vectors": len({_objective_vector(r) for r in records}),
            "unique_resource_requirement_sets": len({_resource_set(r) for r in records}),
            "unique_resource_sequences": len({_resource_sequence(r) for r in records}),
            "distinct_alternatives": len({
                (r["packing_fingerprint"], _objective_vector(r), _resource_set(r)) for r in records
            }),
        })
    return pd.DataFrame(rows)


def _save_candidate_checkpoint(dirs, rows, attempts, signature):
    pool = pd.DataFrame(rows)
    attempt_frame = pd.DataFrame(attempts)
    write_table_atomic(pool, dirs["raw"] / "packing_candidates")
    write_table_atomic(attempt_frame, dirs["logs"] / "candidate_attempts")
    audit = candidate_diversity_audit(pool, attempt_frame)
    write_table_atomic(audit, dirs["audit"] / "candidate_diversity")
    write_json_atomic({
        "generation_version": CANDIDATE_GENERATION_VERSION,
        "signature": signature,
        "progress": dict(OPTIMIZATION_PROGRESS),
    }, dirs["logs"] / "candidate_checkpoint.json")


def jaccard_products(a: str, b: str) -> float:
    aa = set(map(int, str(a).split(";"))) if str(a) else set()
    bb = set(map(int, str(b).split(";"))) if str(b) else set()
    return len(aa & bb) / len(aa | bb) if aa | bb else 0.0


def select_orders(empirical: pd.DataFrame, count: int, overlap: str, seed: int, smallest=False) -> list[int]:
    count = min(count, len(empirical))
    if smallest:
        # Keep the smoke test fast while still selecting a genuinely overlapping
        # real-order episode (the eight absolute smallest orders are disjoint).
        empirical = empirical.sort_values(["box_count", "product_count", "order_id"]).head(max(150, count))
    rng = np.random.default_rng(seed)
    pool = empirical.copy()
    start = int(rng.choice(pool.order_id))
    chosen = [start]
    target = {"low": 0.0, "medium": 0.25, "high": 1.0}.get(overlap, 0.5)
    products = pool.set_index("order_id").product_ids.to_dict()
    while len(chosen) < count:
        remaining = [int(x) for x in pool.order_id if int(x) not in chosen]
        scores = []
        for order_id in remaining:
            avg = float(np.mean([jaccard_products(products[order_id], products[c]) for c in chosen]))
            scores.append((abs(avg - target), rng.random(), order_id))
        chosen.append(min(scores)[2])
    return chosen


def build_candidate_pool(config: dict, empirical: pd.DataFrame | None = None,
                         order_ids: list[int] | None = None) -> pd.DataFrame:
    dirs = result_dirs(config)
    if empirical is None:
        empirical = read_table(dirs["raw"] / "empirical_orders")
    candidate_config = config["candidate_pool"]
    requested_orders = int(candidate_config.get(
        "pool_orders_per_overlap", config["experiment"]["num_orders"]
    ))
    replacement_orders = int(candidate_config.get("replacement_orders_per_overlap", 0))
    smallest = bool(candidate_config.get("select_smallest_orders_for_smoke_test", False))
    continue_on_error = bool(candidate_config.get("continue_on_error", True))
    if order_ids is None:
        selection_plans = []
        for offset, overlap in enumerate(config["experiment"].get("overlap_levels", ["high"])):
            plan_size = min(requested_orders + replacement_orders, len(empirical))
            selection_plans.append((
                str(overlap),
                select_orders(
                    empirical, plan_size, str(overlap), int(config["seed"]) + offset * 7919,
                    smallest,
                ),
                requested_orders,
            ))
    else:
        explicit_ids = list(dict.fromkeys(map(int, order_ids)))
        selection_plans = [("explicit", explicit_ids, len(explicit_ids))]

    orders, _ = load_and_canonicalize(config)
    candidates_per_order = int(candidate_config["candidates_per_order"])
    strategies = tuple(candidate_config.get("layer_sort_strategies", LAYER_SORT_STRATEGIES))
    if candidates_per_order != 3 or strategies != LAYER_SORT_STRATEGIES:
        raise ValueError(
            "Candidate generation requires exactly three ordered strategies: "
            f"{LAYER_SORT_STRATEGIES}."
        )
    signature = _candidate_signature({
        **candidate_config, "layer_sort_strategies": strategies,
        "root_seed": int(config["seed"]),
        "dataset_sha256": sha256(config["paths"]["dataset"]),
    })
    per_attempt_limit = float(candidate_config.get("max_optimizer_runtime_minutes", 30.0)) * 60.0
    total_budget_minutes = candidate_config.get("max_total_optimizer_runtime_minutes")
    total_budget = None if total_budget_minutes is None else float(total_budget_minutes) * 60.0
    pool_started = time.monotonic()

    base_order_slots = sum(target for _, _, target in selection_plans)
    print(
        "Candidate-pool plan: "
        f"{base_order_slots} order slots across {len(selection_plans)} overlap plan(s), "
        f"{candidates_per_order} candidate(s) per order, "
        f"up to {base_order_slots * candidates_per_order} base optimizer attempts. "
        "Duplicate orders across overlap plans reduce this count."
    )
    print(
        f"Optimizer limits: {per_attempt_limit / 60:.2f} minutes per attempt; "
        f"{total_budget_minutes if total_budget_minutes is not None else 'unlimited'} "
        "minutes for candidate generation."
    )

    rows: list[dict] = []
    attempts: list[dict] = []
    checkpoint_path = dirs["logs"] / "candidate_checkpoint.json"
    if checkpoint_path.exists():
        checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
        if checkpoint.get("signature") == signature:
            try:
                rows = read_table(dirs["raw"] / "packing_candidates").to_dict("records")
                attempts = read_table(dirs["logs"] / "candidate_attempts").to_dict("records")
                print(f"Resuming candidate generation with {len(rows)} saved candidates.")
            except FileNotFoundError:
                rows, attempts = [], []
        else:
            print("Existing candidate checkpoint uses a different generation configuration; starting a new pool.")
    successful: dict[int, list[dict]] = {}
    existing = pd.DataFrame(rows)
    if len(existing):
        for existing_order, group in existing.groupby("order_id"):
            if (len(group) == candidates_per_order and
                    set(group.layer_sort_strategy) == set(strategies)):
                successful[int(existing_order)] = group.to_dict("records")
    failed_orders: set[int] = set()
    selected_by_overlap: list[dict] = []
    optimizer_order_position = 0
    budget_exhausted = False
    OPTIMIZATION_PROGRESS.update({
        "total": max(base_order_slots * candidates_per_order, len(attempts)),
        "attempted": len(attempts),
        "successful": sum(a.get("status") == "success" for a in attempts),
        "failed": sum(a.get("status") == "failed" for a in attempts),
        "timed_out": sum(a.get("status") == "timeout" for a in attempts),
        "skipped": sum(a.get("status") == "skipped_after_order_failure" for a in attempts),
        "remaining": max(0, base_order_slots * candidates_per_order - len(attempts)),
        "current_order_id": None,
        "current_candidate_index": None, "current_strategy": None,
    })
    scheduled_order_count = len({int(a["order_id"]) for a in attempts if "order_id" in a})

    for overlap, planned_ids, target_count in selection_plans:
        selected_for_overlap: list[int] = []
        for order_id in planned_ids:
            if len(selected_for_overlap) >= target_count:
                break
            order_id = int(order_id)
            if order_id in successful:
                selected_for_overlap.append(order_id)
                selected_by_overlap.append({
                    "overlap": overlap, "order_id": order_id,
                    "selection_position": len(selected_for_overlap) - 1,
                })
                continue
            if order_id in failed_orders:
                continue

            elapsed_total = time.monotonic() - pool_started
            if total_budget is not None and elapsed_total >= total_budget:
                budget_exhausted = True
                break

            group = orders[orders.Order == order_id]
            order_rows: list[dict] = []
            order_failed = False
            if scheduled_order_count >= base_order_slots:
                OPTIMIZATION_PROGRESS["total"] += candidates_per_order
                OPTIMIZATION_PROGRESS["remaining"] += candidates_per_order
            scheduled_order_count += 1
            for candidate_index, strategy in enumerate(strategies):
                seed = int(config["seed"]) + optimizer_order_position * 10007 + candidate_index * 97
                remaining_budget = None if total_budget is None else total_budget - (time.monotonic() - pool_started)
                if remaining_budget is not None and remaining_budget <= 0:
                    budget_exhausted = True
                    order_failed = True
                    attempts.append({
                        "overlap": overlap, "order_id": order_id,
                        "candidate_index": candidate_index, "layer_sort_strategy": strategy, "seed": seed,
                        "status": "total_budget_exhausted", "elapsed_seconds": 0.0,
                        "error": "The configured total optimizer budget was exhausted.",
                    })
                    break
                timeout_seconds = per_attempt_limit
                if remaining_budget is not None:
                    timeout_seconds = min(timeout_seconds, remaining_budget)

                OPTIMIZATION_PROGRESS.update({
                    "current_order_id": order_id, "current_candidate_index": candidate_index,
                    "current_strategy": strategy,
                })
                print(f"[{OPTIMIZATION_PROGRESS['attempted'] + 1}/{OPTIMIZATION_PROGRESS['total']}] "
                      f"Started order {order_id}, candidate {candidate_index + 1}/3, "
                      f"strategy={strategy}, seed={seed}")
                attempt_started = time.monotonic()
                try:
                    candidate = run_original_optimizer_with_timeout(
                        order_id,
                        group,
                        candidate_index,
                        seed,
                        candidate_config["pallet_dimensions_mm"],
                        candidate_config["ga"],
                        timeout_seconds=timeout_seconds,
                        layer_sort_strategy=strategy,
                    )
                    elapsed = time.monotonic() - attempt_started
                    row = asdict(candidate)
                    row["packing_fingerprint"] = "|".join([
                        str(row["num_blocks"]), f'{row["compactness"]:.8f}',
                        f'{row["heterogeneity"]:.8f}', row["block_sequence_json"],
                    ])
                    previous = next((r for r in order_rows
                                     if r["packing_fingerprint"] == row["packing_fingerprint"]), None)
                    row["duplicate_of_candidate"] = (
                        previous["candidate_id"] if previous is not None else ""
                    )
                    row["is_unique_within_order"] = previous is None
                    order_rows.append(row)
                    attempts.append({
                        "overlap": overlap, "order_id": order_id,
                        "candidate_index": candidate_index, "layer_sort_strategy": strategy, "seed": seed,
                        "status": "success", "elapsed_seconds": elapsed, "error": "",
                    })
                    print(
                        f"Finished optimization of order {order_id}, candidate "
                        f"{candidate_index + 1}/{candidates_per_order} in {elapsed / 60:.2f} minutes"
                    )
                    OPTIMIZATION_PROGRESS["successful"] += 1
                except Exception as exc:
                    elapsed = time.monotonic() - attempt_started
                    status = "timeout" if isinstance(exc, OptimizerTimeoutError) else "failed"
                    attempts.append({
                        "overlap": overlap, "order_id": order_id,
                        "candidate_index": candidate_index, "layer_sort_strategy": strategy, "seed": seed,
                        "status": status, "elapsed_seconds": elapsed,
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                    print(
                        f"Skipped order {order_id}: candidate {candidate_index + 1}/"
                        f"{candidates_per_order} {status} after {elapsed / 60:.2f} minutes."
                    )
                    OPTIMIZATION_PROGRESS[status if status == "failed" else "timed_out"] += 1
                    order_failed = True
                finally:
                    OPTIMIZATION_PROGRESS["attempted"] += 1
                    OPTIMIZATION_PROGRESS["remaining"] -= 1
                    _save_candidate_checkpoint(dirs, rows, attempts, signature)
                if order_failed:
                    for skipped_index in range(candidate_index + 1, candidates_per_order):
                        attempts.append({
                            "overlap": overlap, "order_id": order_id,
                            "candidate_index": skipped_index,
                            "layer_sort_strategy": strategies[skipped_index],
                            "seed": int(config["seed"]) + optimizer_order_position * 10007 + skipped_index * 97,
                            "status": "skipped_after_order_failure", "elapsed_seconds": 0.0,
                            "error": "Order discarded because an earlier candidate failed.",
                        })
                        OPTIMIZATION_PROGRESS["skipped"] += 1
                        OPTIMIZATION_PROGRESS["remaining"] -= 1
                    _save_candidate_checkpoint(dirs, rows, attempts, signature)
                    if not continue_on_error:
                        raise RuntimeError(
                            f"Optimizer failed for order {order_id}; see candidate_attempts.csv."
                        )
                    break

            optimizer_order_position += 1
            if order_failed:
                failed_orders.add(order_id)
                _save_candidate_checkpoint(dirs, rows, attempts, signature)
                if budget_exhausted:
                    break
                continue

            successful[order_id] = order_rows
            rows.extend(order_rows)
            selected_for_overlap.append(order_id)
            selected_by_overlap.append({
                "overlap": overlap, "order_id": order_id,
                "selection_position": len(selected_for_overlap) - 1,
            })

            # Preserve completed work after every successful order during long paper runs.
            _save_candidate_checkpoint(dirs, rows, attempts, signature)
            audit_row = candidate_diversity_audit(pd.DataFrame(rows), pd.DataFrame(attempts))
            audit_row = audit_row[audit_row.order_id == order_id].iloc[0]
            print(
                f"Order {order_id} checkpointed: 3 successful executions, "
                f"{int(audit_row.unique_packing_fingerprints)} unique packing fingerprints, "
                f"{int(audit_row.unique_objective_vectors)} unique objective vectors, "
                f"{int(audit_row.unique_resource_sequences)} unique resource sequences; "
                f"remaining={OPTIMIZATION_PROGRESS['remaining']}."
            )

        if len(selected_for_overlap) < target_count:
            print(
                f"Warning: overlap '{overlap}' obtained {len(selected_for_overlap)} successful "
                f"orders out of {target_count} requested."
            )
        if budget_exhausted:
            print("The total optimizer time budget was exhausted; candidate generation has stopped.")
            break

    pool = pd.DataFrame(rows)
    if pool.empty:
        pd.DataFrame(attempts).to_csv(dirs["logs"] / "candidate_attempts.csv", index=False)
        raise RuntimeError(
            "No order produced a complete candidate set. See logs/candidate_attempts.csv."
        )
    write_table_atomic(pool, dirs["raw"] / "packing_candidates")
    attempt_frame = pd.DataFrame(attempts)
    attempt_frame.to_csv(dirs["logs"] / "candidate_attempts.csv", index=False)
    attempt_frame[attempt_frame.status != "success"].to_csv(
        dirs["logs"] / "candidate_errors.csv", index=False
    )
    optimized_ids = list(dict.fromkeys(row["order_id"] for row in rows))
    pd.DataFrame({"order_id": optimized_ids}).to_csv(
        dirs["raw"] / "selected_order_ids.csv", index=False
    )
    pd.DataFrame(selected_by_overlap).to_csv(
        dirs["raw"] / "selected_order_ids_by_overlap.csv", index=False
    )
    elapsed_minutes = (time.monotonic() - pool_started) / 60.0
    OPTIMIZATION_PROGRESS.update({
        "current_order_id": None, "current_candidate_index": None, "current_strategy": None,
    })
    _save_candidate_checkpoint(dirs, rows, attempts, signature)
    write_json({
        "requested_orders_per_overlap": requested_orders,
        "candidates_per_order": candidates_per_order,
        "successful_unique_orders": len(optimized_ids),
        "failed_unique_orders": len(failed_orders),
        "optimizer_attempts": len(attempt_frame),
        "successful_attempts": int((attempt_frame.status == "success").sum()),
        "timed_out_attempts": int((attempt_frame.status == "timeout").sum()),
        "failed_attempts": int((attempt_frame.status == "failed").sum()),
        "budget_exhausted": budget_exhausted,
        "elapsed_minutes": elapsed_minutes,
        "per_attempt_limit_minutes": per_attempt_limit / 60.0,
        "total_optimizer_budget_minutes": total_budget_minutes,
        "layer_sort_strategies": list(strategies),
        "distinct_candidate_alternatives": int(candidate_diversity_audit(pool, attempt_frame)["distinct_alternatives"].sum()),
        "progress": dict(OPTIMIZATION_PROGRESS),
    }, dirs["logs"] / "candidate_run_summary.json")
    return pool


def expand_candidates_for_simulation(pool: pd.DataFrame, order_id: int, station: int, ready_time: float,
                                     execution_seconds: float, resource_available: dict[int, float],
                                     prediction_seconds: float, equivalent_pallets: int = 1,
                                     block_handling_seconds: float = 0.0) -> list[dict]:
    rows = []
    subset = pool[pool.order_id == int(order_id)].copy()
    distinct_columns = [c for c in ["packing_fingerprint"] if c in subset]
    if distinct_columns:
        subset = subset.drop_duplicates(distinct_columns, keep="first")
    for _, row in subset.iterrows():
        products = list(map(int, json.loads(row.required_products_json)))
        sequence = list(map(int, json.loads(row.execution_sequence_json)))
        unique_sequence = list(dict.fromkeys(sequence)) or products
        tokens = [p if equivalent_pallets <= 1 else f"{p}#{station % equivalent_pallets}" for p in products]
        sequence_tokens = [p if equivalent_pallets <= 1 else f"{p}#{station % equivalent_pallets}" for p in unique_sequence]
        recalls = sum(resource_available.get(p, 0.0) > ready_time or p not in resource_available for p in tokens)
        availability = max([resource_available.get(p, 0.0) for p in tokens] + [ready_time])
        start = max(ready_time, availability)
        candidate_execution = (
            float(execution_seconds)
            + float(block_handling_seconds) * int(row.get("num_blocks", 1))
        )
        slot = candidate_execution / max(len(sequence_tokens), 1)
        resource_windows = {
            str(resource): [float(start + index * slot), float(start + (index + 1) * slot)]
            for index, resource in enumerate(sequence_tokens)
        }
        rows.append({
            **row.to_dict(), "station": int(station), "predicted_retrievals": int(recalls),
            "predicted_completion": float(start + candidate_execution), "interval_start": float(start),
            "interval_end": float(start + candidate_execution), "resources": tokens,
            "resource_sequence": sequence_tokens, "prediction_seconds": float(prediction_seconds),
            "resource_windows": resource_windows, "candidate_execution_seconds": candidate_execution,
            "fallback": False, "fallback_reason": "",
        })
    rows.append({
        "order_id": int(order_id), "candidate_id": f"O{order_id}-DEFER", "station": int(station),
        "predicted_retrievals": 0, "predicted_completion": float(ready_time + execution_seconds + 1e6),
        "interval_start": float(ready_time + 1e6), "interval_end": float(ready_time + 1e6 + execution_seconds),
        "resources": [], "resource_sequence": [], "prediction_seconds": float(prediction_seconds),
        "resource_windows": {}, "candidate_execution_seconds": float(execution_seconds),
        "fallback": True, "fallback_reason": "no_conflict_free_simultaneous_candidate",
        "compactness": np.nan, "homogeneity": np.nan,
        "pallet_volume_utilization_pct": np.nan,
    })
    return rows
