from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any

import pandas as pd


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv_auto(path: str | Path, **kwargs) -> pd.DataFrame:
    path = Path(path)
    first = path.read_text(encoding="utf-8", errors="replace").splitlines()[0]
    sep = ";" if first.count(";") > first.count(",") else ","
    return pd.read_csv(path, sep=sep, **kwargs)


def write_table(frame: pd.DataFrame, base: str | Path) -> Path:
    """Write Parquet when available and always write an auditable CSV companion."""
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    csv_path = base.with_suffix(".csv")
    frame.to_csv(csv_path, index=False)
    try:
        parquet_path = base.with_suffix(".parquet")
        frame.to_parquet(parquet_path, index=False)
        return parquet_path
    except (ImportError, ModuleNotFoundError, ValueError):
        return csv_path


def write_table_atomic(frame: pd.DataFrame, base: str | Path) -> Path:
    """Atomically checkpoint a table and its optional Parquet companion."""
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    csv_path = base.with_suffix(".csv")
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=base.parent,
        prefix=f".{base.name}-", suffix=".csv.tmp", delete=False,
    ) as handle:
        temporary_csv = Path(handle.name)
        frame.to_csv(handle, index=False)
    os.replace(temporary_csv, csv_path)
    try:
        parquet_path = base.with_suffix(".parquet")
        with tempfile.NamedTemporaryFile(
            dir=base.parent, prefix=f".{base.name}-", suffix=".parquet.tmp", delete=False
        ) as handle:
            temporary_parquet = Path(handle.name)
        frame.to_parquet(temporary_parquet, index=False)
        os.replace(temporary_parquet, parquet_path)
        return parquet_path
    except (ImportError, ModuleNotFoundError, ValueError):
        if "temporary_parquet" in locals():
            temporary_parquet.unlink(missing_ok=True)
        return csv_path


def read_table(base: str | Path) -> pd.DataFrame:
    base = Path(base)
    parquet = base if base.suffix == ".parquet" else base.with_suffix(".parquet")
    csv = base if base.suffix == ".csv" else base.with_suffix(".csv")
    if parquet.exists():
        try:
            return pd.read_parquet(parquet)
        except (ImportError, ModuleNotFoundError):
            pass
    if csv.exists():
        return pd.read_csv(csv)
    raise FileNotFoundError(f"Neither {parquet} nor {csv} exists")


def write_json(value: Any, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")
    return path


def write_json_atomic(value: Any, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent,
        prefix=f".{path.name}-", suffix=".tmp", delete=False,
    ) as handle:
        temporary = Path(handle.name)
        json.dump(value, handle, indent=2, default=str)
    os.replace(temporary, path)
    return path


def result_dirs(config: dict) -> dict[str, Path]:
    root = Path(config["paths"]["results_dir"])
    dirs = {
        "root": root,
        "audit": root / "audit",
        "raw": root / "raw",
        "derived": root / "derived",
        "statistics": root / "derived" / "statistics",
        "figure_data": root / "derived" / "figure_data",
        "figures": root / "figures",
        "tables": root / "tables",
        "logs": root / "logs",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    return dirs
