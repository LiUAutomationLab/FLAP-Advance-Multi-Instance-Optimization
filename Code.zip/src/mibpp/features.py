from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd

from .dataio import read_csv_auto, result_dirs, sha256, write_json, write_table


DATA_COLUMNS = ["Order", "Product", "Quantity", "Length", "Width", "Height", "Weight"]
RESULT_COLUMNS = [
    "OrderNumber", "TotalNumberOfBoxes", "TotalProductVariety", "TotalResidualBoxes",
    "TotalResidualVariety", "TotalTime", "NumOfBlocks", "Heterogeneity", "Compactness",
    "EnvelopeVolumeUtilization", "PalletVolumeUtilization", "NumOfGA", "Entropy", "Size",
]


def load_and_canonicalize(config: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    orders = read_csv_auto(config["paths"]["dataset"])
    results = read_csv_auto(config["paths"]["legacy_results"])
    missing_data = sorted(set(DATA_COLUMNS) - set(orders.columns))
    missing_results = sorted(set(RESULT_COLUMNS) - set(results.columns))
    if missing_data or missing_results:
        raise ValueError(f"Missing columns. dataset={missing_data}; results={missing_results}")
    for col in ["Order", "Product", "Quantity", "Length", "Width", "Height"]:
        orders[col] = pd.to_numeric(orders[col], errors="raise").astype("int64")
    orders["Weight"] = pd.to_numeric(orders["Weight"], errors="raise")
    # Aggregate repeated order-product rows while refusing inconsistent geometry.
    inconsistent = orders.groupby(["Order", "Product"])[["Length", "Width", "Height", "Weight"]].nunique().max(axis=1)
    if (inconsistent > 1).any():
        bad = inconsistent[inconsistent > 1].index.tolist()[:10]
        raise ValueError(f"Conflicting dimensions/weights for duplicate order-product rows: {bad}")
    canonical = orders.groupby(["Order", "Product"], as_index=False).agg(
        Quantity=("Quantity", "sum"), Length=("Length", "first"), Width=("Width", "first"),
        Height=("Height", "first"), Weight=("Weight", "first"),
    )
    results["OrderNumber"] = pd.to_numeric(results["OrderNumber"], errors="raise").astype("int64")
    return canonical, results


def validate_data(config: dict) -> dict:
    raw_orders = read_csv_auto(config["paths"]["dataset"])
    orders, results = load_and_canonicalize(config)
    data_ids, result_ids = set(orders.Order), set(results.OrderNumber)
    q = orders.groupby("Order").Quantity.sum()
    p = orders.groupby("Order").Product.nunique()
    joined = results.set_index("OrderNumber")
    matched = sorted(data_ids & result_ids)
    report = {
        "dataset_sha256": sha256(config["paths"]["dataset"]),
        "legacy_results_sha256": sha256(config["paths"]["legacy_results"]),
        "raw_rows": int(len(raw_orders)),
        "canonical_rows": int(len(orders)),
        "duplicate_order_product_rows_aggregated": int(raw_orders.duplicated(["Order", "Product"]).sum()),
        "dataset_orders": int(len(data_ids)),
        "result_orders": int(len(result_ids)),
        "matched_orders": int(len(matched)),
        "dataset_only_orders": sorted(map(int, data_ids - result_ids)),
        "results_only_orders": sorted(map(int, result_ids - data_ids)),
        "missing_values_dataset": {k: int(v) for k, v in orders.isna().sum().items()},
        "missing_values_results": {k: int(v) for k, v in results.isna().sum().items()},
        "nonpositive_quantity_rows": int((orders.Quantity <= 0).sum()),
        "nonpositive_dimension_rows": int((orders[["Length", "Width", "Height"]] <= 0).any(axis=1).sum()),
        "negative_runtime_rows": int((results.TotalTime < 0).sum()),
        "zero_runtime_rows": int((results.TotalTime == 0).sum()),
        "utilization_outside_0_100": {
            col: int(((results[col] < 0) | (results[col] > 100)).sum())
            for col in ["EnvelopeVolumeUtilization", "PalletVolumeUtilization"]
        },
        "box_count_mismatches": int(sum(int(q[o]) != int(joined.loc[o, "TotalNumberOfBoxes"]) for o in matched)),
        "product_variety_mismatches": int(sum(int(p[o]) != int(joined.loc[o, "TotalProductVariety"]) for o in matched)),
    }
    dirs = result_dirs(config)
    write_json(report, dirs["audit"] / "data_quality_report.json")
    matching = pd.DataFrame({
        "order_id": sorted(data_ids | result_ids),
    })
    matching["in_dataset"] = matching.order_id.isin(data_ids)
    matching["in_results"] = matching.order_id.isin(result_ids)
    matching["matched"] = matching.in_dataset & matching.in_results
    matching.to_csv(dirs["audit"] / "order_matching.csv", index=False)
    lines = ["# Data quality report", "", "Generated directly from the two immutable input CSV files.", ""]
    lines += [f"- **{key.replace('_', ' ').title()}**: {value}" for key, value in report.items()]
    (dirs["audit"] / "data_quality_report.md").write_text("\n".join(lines), encoding="utf-8")
    return report


def _cv(values: np.ndarray) -> float:
    mean = float(np.mean(values))
    return float(np.std(values, ddof=0) / mean) if mean else 0.0


def prepare_features(config: dict) -> pd.DataFrame:
    orders, results = load_and_canonicalize(config)
    records = []
    for order_id, group in orders.groupby("Order", sort=True):
        quantities = group.Quantity.to_numpy(float)
        shares = quantities / quantities.sum()
        entropy = float(-np.sum(shares * np.log(shares)))
        products = len(group)
        normalized_entropy = entropy / math.log(products) if products > 1 else 0.0
        volumes = (group.Length * group.Width * group.Height).to_numpy(float)
        repeated_volumes = np.repeat(volumes, group.Quantity.to_numpy(int))
        records.append({
            "order_id": int(order_id), "box_count": int(quantities.sum()), "product_count": int(products),
            "max_product_share": float(shares.max()), "mean_product_share": float(shares.mean()),
            "quantity_cv": _cv(quantities), "shannon_entropy": entropy,
            "normalized_entropy": normalized_entropy, "gini_simpson": float(1 - np.sum(shares**2)),
            "effective_products": float(np.exp(entropy)), "mean_item_volume_mm3": float(repeated_volumes.mean()),
            "item_volume_cv": _cv(repeated_volumes), "length_cv": _cv(np.repeat(group.Length, group.Quantity)),
            "width_cv": _cv(np.repeat(group.Width, group.Quantity)), "height_cv": _cv(np.repeat(group.Height, group.Quantity)),
            "mean_weight_kg": float(np.average(group.Weight, weights=group.Quantity)),
            "weight_cv": _cv(np.repeat(group.Weight.to_numpy(float), group.Quantity.to_numpy(int))),
            "product_ids": ";".join(map(str, group.Product.astype(int))),
            "product_quantities": ";".join(f"{int(p)}:{int(q)}" for p, q in zip(group.Product, group.Quantity)),
        })
    features = pd.DataFrame(records)
    result_map = {
        "OrderNumber": "order_id", "TotalTime": "actual_runtime", "NumOfBlocks": "legacy_blocks",
        "TotalResidualBoxes": "legacy_residual_boxes", "TotalResidualVariety": "legacy_residual_variety",
        "NumOfGA": "legacy_ga_runs", "Compactness": "legacy_compactness",
        "Heterogeneity": "legacy_heterogeneity", "EnvelopeVolumeUtilization": "legacy_envelope_utilization_pct",
        "PalletVolumeUtilization": "legacy_pallet_utilization_pct", "Entropy": "legacy_entropy_class",
        "Size": "legacy_size_class",
    }
    empirical = features.merge(results[list(result_map)].rename(columns=result_map), on="order_id", how="inner")
    empirical["recomputed_entropy_quintile"] = pd.qcut(
        empirical.shannon_entropy.rank(method="first"), 5, labels=[f"Entropy Interval {i}" for i in range(1, 6)]
    ).astype(str)
    empirical["recomputed_size_class"] = pd.qcut(
        empirical.box_count.rank(method="first"), 3, labels=["Small", "Medium", "Large"]
    ).astype(str)
    write_table(empirical, result_dirs(config)["raw"] / "empirical_orders")
    return empirical
