import numpy as np


def is_contained_in_area(point, face):
    face_x_min, face_x_max = (min(face[:, 0]), max(face[:, 0]))
    face_y_min, face_y_max = (min(face[:, 1]), max(face[:, 1]))
    face_z = face[0][2]

    return face_x_max > point[0] > face_x_min and face_y_max > point[1] > face_y_min and point[2] == face_z


def compute_overlapping_area_xy_plane(box_bottom_face, box_top_face):
    box_bottom_x_min, box_bottom_x_max = (min(box_bottom_face[:, 0]), max(box_bottom_face[:, 0]))
    box_bottom_y_min, box_bottom_y_max = (min(box_bottom_face[:, 1]), max(box_bottom_face[:, 1]))

    box_top_x_min, box_top_x_max = (min(box_top_face[:, 0]), max(box_top_face[:, 0]))
    box_top_y_min, box_top_y_max = (min(box_top_face[:, 1]), max(box_top_face[:, 1]))

    if box_bottom_face[0][2] != box_top_face[0][2]:
        return 0, 0

    if box_bottom_x_max < box_top_x_min or box_top_x_max < box_bottom_x_min or box_bottom_y_max < box_top_y_min or box_top_y_max < box_bottom_y_min:
        return 0, 0

    x_overlap = min(box_bottom_x_max, box_top_x_max) - max(box_bottom_x_min, box_top_x_min)
    y_overlap = min(box_bottom_y_max, box_top_y_max) - max(box_bottom_y_min, box_top_y_min)

    overlapping_area = x_overlap * y_overlap

    bottom_face_area = (box_bottom_x_max - box_bottom_x_min) * (box_bottom_y_max - box_bottom_y_min)

    overlapping_percentage = overlapping_area / bottom_face_area

    return overlapping_area, overlapping_percentage


def compute_overlapping_area_zy_plane(box_left_face, box_right_face):
    box_left_z_min, box_left_z_max = (min(box_left_face[:, 2]), max(box_left_face[:, 2]))
    box_left_y_min, box_left_y_max = (min(box_left_face[:, 1]), max(box_left_face[:, 1]))

    box_right_z_min, box_right_z_max = (min(box_right_face[:, 2]), max(box_right_face[:, 2]))
    box_right_y_min, box_right_y_max = (min(box_right_face[:, 1]), max(box_right_face[:, 1]))

    if box_left_face[0][0] != box_right_face[0][0]:
        return 0, 0

    if box_left_z_max < box_right_z_min or box_right_z_max < box_left_z_min or box_left_y_max < box_right_y_min or box_right_y_max < box_left_y_min:
        return 0, 0

    z_overlap = abs(min(box_left_z_max, box_right_z_max) - max(box_left_z_min, box_right_z_min))
    y_overlap = abs(min(box_left_y_max, box_right_y_max) - max(box_left_y_min, box_right_y_min))

    overlapping_area = z_overlap * y_overlap

    bottom_face_area = (box_left_z_max - box_left_z_min) * (box_left_y_max - box_left_y_min)

    overlapping_percentage = overlapping_area / bottom_face_area

    return overlapping_area, overlapping_percentage


def compute_overlapping_area_zx_plane(box_front_face, box_back_face):
    box_front_z_min, box_front_z_max = (min(box_front_face[:, 2]), max(box_front_face[:, 2]))
    box_front_x_min, box_front_x_max = (min(box_front_face[:, 0]), max(box_front_face[:, 0]))

    box_back_z_min, box_back_z_max = (min(box_back_face[:, 2]), max(box_back_face[:, 2]))
    box_back_x_min, box_back_x_max = (min(box_back_face[:, 0]), max(box_back_face[:, 0]))

    if box_front_face[0][1] != box_back_face[0][1]:
        return 0, 0

    if box_front_z_max < box_back_z_min or box_back_z_max < box_front_z_min or box_front_x_max < box_back_x_min or box_back_x_max < box_front_x_min:
        return 0, 0

    z_overlap = abs(min(box_front_z_max, box_back_z_max) - max(box_front_z_min, box_back_z_min))
    x_overlap = abs(min(box_front_x_max, box_back_x_max) - max(box_front_x_min, box_back_x_min))

    overlapping_area = z_overlap * x_overlap

    bottom_face_area = (box_front_z_max - box_front_z_min) * (box_front_x_max - box_front_x_min)

    overlapping_percentage = overlapping_area / bottom_face_area

    return overlapping_area, overlapping_percentage


def generate_poses(length, width, height, mask):
    poses = np.zeros((24, 3, 3), dtype=int)

    # pose set 1
    poses[0][1] = (length, width, height)
    poses[0][2] = (int(length / 2), int(width / 2), int(height / 2))

    poses[1][1] = (-length, width, height)
    poses[1][2] = (int(-length / 2), int(width / 2), int(height / 2))

    poses[2][1] = (-length, -width, height)
    poses[2][2] = (int(-length / 2), int(-width / 2), int(height / 2))

    poses[3][1] = (length, -width, height)
    poses[3][2] = (int(length / 2), int(-width / 2), int(height / 2))

    # pose set 2
    poses[4][1] = (width, length, height)
    poses[4][2] = (int(width / 2), int(length / 2), int(height / 2))

    poses[5][1] = (-width, length, height)
    poses[5][2] = (int(-width / 2), int(length / 2), int(height / 2))

    poses[6][1] = (-width, -length, height)
    poses[6][2] = (int(-width / 2), int(-length / 2), int(height / 2))

    poses[7][1] = (width, -length, height)
    poses[7][2] = (int(width / 2), int(-length / 2), int(height / 2))

    # pose set 3
    poses[8][1] = (length, height, width)
    poses[8][2] = (int(length / 2), int(height / 2), int(width / 2))

    poses[9][1] = (-length, height, width)
    poses[9][2] = (int(-length / 2), int(height / 2), int(width / 2))

    poses[10][1] = (-length, -height, width)
    poses[10][2] = (int(-length / 2), int(-height / 2), int(width / 2))

    poses[11][1] = (length, -height, width)
    poses[11][2] = (int(length / 2), int(-height / 2), int(width / 2))

    # pose set 4
    poses[12][1] = (height, length, width)
    poses[12][2] = (int(height / 2), int(length / 2), int(width / 2))

    poses[13][1] = (-height, length, width)
    poses[13][2] = (int(-height / 2), int(length / 2), int(width / 2))

    poses[14][1] = (-height, -length, width)
    poses[14][2] = (int(-height / 2), int(-length / 2), int(width / 2))

    poses[15][1] = (height, -length, width)
    poses[15][2] = (int(height / 2), int(-length / 2), int(width / 2))

    # pose set 5
    poses[16][1] = (width, height, length)
    poses[16][2] = (int(width / 2), int(height / 2), int(length / 2))

    poses[17][1] = (-width, height, length)
    poses[17][2] = (int(-width / 2), int(height / 2), int(length / 2))

    poses[18][1] = (-width, -height, length)
    poses[18][2] = (int(-width / 2), int(-height / 2), int(length / 2))

    poses[19][1] = (width, -height, length)
    poses[19][2] = (int(width / 2), int(-height / 2), int(length / 2))

    # pose set 6
    poses[20][1] = (height, width, length)
    poses[20][2] = (int(height / 2), int(width / 2), int(length / 2))

    poses[21][1] = (-height, width, length)
    poses[21][2] = (int(-height / 2), int(width / 2), int(length / 2))

    poses[22][1] = (-height, -width, length)
    poses[22][2] = (int(-height / 2), int(-width / 2), int(length / 2))

    poses[23][1] = (height, -width, length)
    poses[23][2] = (int(height / 2), int(-width / 2), int(length / 2))

    return poses[mask]


class Box:

    def __init__(self, name, length, width, height, weight, pose_index=0,
                 poses_mask=None):
        if poses_mask is None:
            poses_mask = [True, False, False, False,
                          True, False, False, False,
                          False, False, False, False,
                          False, False, False, False,
                          False, False, False, False,
                          False, False, False, False]

        assert len(poses_mask) == 24, "Len of the poses mask must be 24."

        self.anchor_point = np.zeros((1, 3), dtype=int)
        self.pose_index = pose_index

        self.name = name
        self.length = length
        self.width = width
        self.height = height
        self.weight = weight
        self.side_surf_area = 2 * (self.length * self.height + self.width * self.height)
        self.vol = self.height * self.length * self.width

        self.poses = generate_poses(self.length, self.width, self.height, poses_mask)

        self.__top_face = np.zeros((4, 3), dtype=int)
        self.__top_face[0] = (self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])
        self.__top_face[1] = (self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__top_face[2] = (self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__top_face[3] = (self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])

        self.__bottom_face = np.zeros((4, 3), dtype=int)
        self.__bottom_face[0] = (
            self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])
        self.__bottom_face[1] = (
            self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])
        self.__bottom_face[2] = (
            self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])
        self.__bottom_face[3] = (
            self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])

        self.__left_face = np.zeros((4, 3), dtype=int)
        self.__left_face[0] = (self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])
        self.__left_face[1] = (self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])
        self.__left_face[2] = (self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__left_face[3] = (self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])

        self.__right_face = np.zeros((4, 3), dtype=int)
        self.__right_face[0] = (
            self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])
        self.__right_face[1] = (
            self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])
        self.__right_face[2] = (
            self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__right_face[3] = (
            self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])

        self.__front_face = np.zeros((4, 3), dtype=int)
        self.__front_face[0] = (
            self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])
        self.__front_face[1] = (
            self.poses[pose_index][0][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])
        self.__front_face[2] = (
            self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][1][2])
        self.__front_face[3] = (
            self.poses[pose_index][1][0], self.poses[pose_index][0][1], self.poses[pose_index][0][2])

        self.__back_face = np.zeros((4, 3), dtype=int)
        self.__back_face[0] = (self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])
        self.__back_face[1] = (self.poses[pose_index][0][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__back_face[2] = (self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][1][2])
        self.__back_face[3] = (self.poses[pose_index][1][0], self.poses[pose_index][1][1], self.poses[pose_index][0][2])

        self.__extreme_point_1 = [self.poses[pose_index][0][0], self.poses[pose_index][0][1],
                                  self.poses[pose_index][1][2]]
        self.__extreme_point_2 = [self.poses[pose_index][0][0], self.poses[pose_index][1][1],
                                  self.poses[pose_index][0][2]]
        self.__extreme_point_3 = [self.poses[pose_index][1][0], self.poses[pose_index][0][1],
                                  self.poses[pose_index][0][2]]

    def compute_extreme_points(self):
        list_of_eps = []

        ep1 = self.__extreme_point_1 + self.anchor_point
        ep2 = self.__extreme_point_2 + self.anchor_point
        ep3 = self.__extreme_point_3 + self.anchor_point

        list_of_eps.extend(ep1.tolist())
        list_of_eps.extend(ep2.tolist())
        list_of_eps.extend(ep3.tolist())

        return list_of_eps

    def compute_top_face(self):
        top_face = self.__top_face + self.anchor_point
        return top_face

    def compute_bottom_face(self):
        bottom_face = self.__bottom_face + self.anchor_point
        return bottom_face

    def compute_left_face(self):
        left_face = self.__left_face + self.anchor_point
        return left_face

    def compute_right_face(self):
        right_face = self.__right_face + self.anchor_point
        return right_face

    def compute_front_face(self):
        front_face = self.__front_face + self.anchor_point
        return front_face

    def compute_back_face(self):
        back_face = self.__back_face + self.anchor_point
        return back_face

    def is_contacted_by_box(self, box):
        current_box_left_face = self.compute_left_face()
        current_box_right_face = self.compute_right_face()
        current_box_front_face = self.compute_front_face()
        current_box_back_face = self.compute_back_face()

        contacting_box_left_face = box.compute_left_face()
        contacting_box_right_face = box.compute_right_face()
        contacting_box_front_face = box.compute_front_face()
        contacting_box_back_face = box.compute_back_face()

        contacting_area = 0

        oa1, op1 = compute_overlapping_area_zy_plane(current_box_left_face, contacting_box_right_face)
        oa2, op2 = compute_overlapping_area_zy_plane(current_box_right_face, contacting_box_left_face)
        oa3, op3 = compute_overlapping_area_zx_plane(current_box_front_face, contacting_box_back_face)
        oa4, op4 = compute_overlapping_area_zx_plane(current_box_back_face, contacting_box_front_face)

        contacting_area = oa1 + oa2 + oa3 + oa4

        return contacting_area

    def is_contacted_by_boxes(self, boxes):
        cumulative_area = 0

        for box in boxes:
            contact_area = self.is_contacted_by_box(box)
            cumulative_area += contact_area

        cumulative_area_percent = cumulative_area / self.side_surf_area
        return cumulative_area_percent

    def is_supported_by_box(self, box):
        bottom_face = self.compute_bottom_face()
        top_face = box.compute_top_face()

        contained_points = 0
        bottom_corner_1 = bottom_face[0] + (10, 10, 0)
        bottom_corner_2 = bottom_face[1] + (10, -10, 0)
        bottom_corner_3 = bottom_face[2] + (-10, -10, 0)
        bottom_corner_4 = bottom_face[3] + (-10, 10, 0)

        if is_contained_in_area(bottom_corner_1, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_2, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_3, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_4, top_face):
            contained_points += 1

        supported_area, supported_percent = compute_overlapping_area_xy_plane(bottom_face, top_face)
        return supported_percent, supported_area, contained_points

    def is_supported_by_boxes_variable_criteria(self, boxes, loose_box=False):
        cumulative_support_percent, cumulative_support, contained_points = self.is_supported_by_boxes(boxes)
        if not loose_box:
            if ((cumulative_support_percent >= 0.4 and contained_points >= 4) or
                    (cumulative_support_percent >= 0.5 and contained_points >= 3) or
                    (cumulative_support_percent >= 0.75 and contained_points >= 2)):
                return True, cumulative_support_percent, cumulative_support, contained_points
            else:
                return False, cumulative_support_percent, cumulative_support, contained_points
        else:
            if cumulative_support_percent >= 0.5 and contained_points >= 3:
                return True, cumulative_support_percent, cumulative_support, contained_points
            else:
                return False, cumulative_support_percent, cumulative_support, contained_points

    def is_supported_by_boxes(self, boxes):
        cumulative_support_percent = 0
        cumulative_support = 0
        cumulative_contained_points = 0
        for box in boxes:
            supported_percent, supported_area, contained_points = self.is_supported_by_box(box)
            cumulative_support_percent += supported_percent
            cumulative_support += supported_area
            cumulative_contained_points += contained_points

        return cumulative_support_percent, cumulative_support, cumulative_contained_points

    def is_single_box_supported_by_boxes(self, boxes, min_supported_area_percent=0.5, min_contained_points=3):
        cumulative_support_percent = 0
        cumulative_support = 0
        cumulative_contained_points = 0
        for box in boxes:
            supported_percent, supported_area, contained_points = self.is_supported_by_box(box)
            cumulative_support_percent += supported_percent
            cumulative_support += supported_area
            cumulative_contained_points += contained_points

        if cumulative_support_percent >= min_supported_area_percent and cumulative_contained_points >= min_contained_points:
            return True, cumulative_support_percent, cumulative_support, cumulative_contained_points
        else:
            return False, cumulative_support_percent, cumulative_support, cumulative_contained_points

    def calculate_top_point_distance_from_block_base(self):
        height = self.anchor_point[0][2] + self.height
        return height

    def is_colliding(self, target_box):
        """
        Returns true if the box (self => b1) collides with target_box (b2) (box_object), the function uses axis
        aligned bounding boxes to verify collisions.
        :param target_box: the box with which we are testing the collusion
        :return: True if the two boxes (self and target_box) collide
        """

        current_box_bottom_x = self.anchor_point[0][0]
        current_box_bottom_y = self.anchor_point[0][1]
        current_box_bottom_z = self.anchor_point[0][2]

        current_box_top_anchor = self.anchor_point[0] + self.poses[self.pose_index][1]

        current_box_top_x = current_box_top_anchor[0]
        current_box_top_y = current_box_top_anchor[1]
        current_box_top_z = current_box_top_anchor[2]

        target_box_bottom_x = target_box.anchor_point[0][0]
        target_box_bottom_y = target_box.anchor_point[0][1]
        target_box_bottom_z = target_box.anchor_point[0][2]

        target_box_top_anchor = target_box.anchor_point[0] + target_box.poses[target_box.pose_index][1]

        target_box_top_x = target_box_top_anchor[0]
        target_box_top_y = target_box_top_anchor[1]
        target_box_top_z = target_box_top_anchor[2]

        b1_x_min = min(current_box_bottom_x, current_box_top_x)
        b1_x_max = max(current_box_bottom_x, current_box_top_x)
        b1_y_min = min(current_box_bottom_y, current_box_top_y)
        b1_y_max = max(current_box_bottom_y, current_box_top_y)
        b1_z_min = min(current_box_bottom_z, current_box_top_z)
        b1_z_max = max(current_box_bottom_z, current_box_top_z)

        b2_x_min = min(target_box_bottom_x, target_box_top_x)
        b2_x_max = max(target_box_bottom_x, target_box_top_x)
        b2_y_min = min(target_box_bottom_y, target_box_top_y)
        b2_y_max = max(target_box_bottom_y, target_box_top_y)
        b2_z_min = min(target_box_bottom_z, target_box_top_z)
        b2_z_max = max(target_box_bottom_z, target_box_top_z)

        return b1_x_min < b2_x_max and b1_x_max > b2_x_min and b1_y_min < b2_y_max and b1_y_max > b2_y_min and \
            b1_z_min < b2_z_max and b1_z_max > b2_z_min

    def is_collided_by_boxes(self, boxes):
        collusion = False

        for box in boxes:
            if self.is_colliding(box):
                collusion = True
                break

        if collusion:
            return True
        else:
            return False

    def deprecated_is_supported_by_box(self, box, min_supported_area_percent=0.75):
        bottom_face = self.compute_bottom_face()
        top_face = box.compute_top_face()

        contained_points = 0
        bottom_corner_1 = bottom_face[0] + (10, 10, 0)
        bottom_corner_2 = bottom_face[1] + (10, -10, 0)
        bottom_corner_3 = bottom_face[2] + (-10, -10, 0)
        bottom_corner_4 = bottom_face[3] + (-10, 10, 0)

        if is_contained_in_area(bottom_corner_1, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_2, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_3, top_face):
            contained_points += 1

        if is_contained_in_area(bottom_corner_4, top_face):
            contained_points += 1

        supported_area, supported_percent = compute_overlapping_area_xy_plane(bottom_face, top_face)
        supported = False
        if supported_percent > min_supported_area_percent:
            supported = True
        return supported, supported_percent, supported_area, contained_points
