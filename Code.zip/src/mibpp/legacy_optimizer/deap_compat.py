"""Small, dependency-free subset of :mod:`deap.tools` used by the 2024 optimizer.

The original project depended on DEAP only for Pareto archives, statistics,
logbooks and NSGA-II survivor selection.  Keeping those interfaces here makes
the archived algorithm runnable in a clean Python environment while preserving
its evaluation, crossover, mutation and packing logic.
"""

from __future__ import annotations

import copy
import math
from collections import defaultdict
from types import SimpleNamespace


class ParetoFront(list):
    def update(self, population):
        for candidate in population:
            if not candidate.fitness.valid:
                continue
            dominated = False
            removals = []
            for i, incumbent in enumerate(self):
                if incumbent.fitness.dominates(candidate.fitness):
                    dominated = True
                    break
                if candidate.fitness.dominates(incumbent.fitness):
                    removals.append(i)
                elif candidate.fitness.values == incumbent.fitness.values and list(candidate) == list(incumbent):
                    dominated = True
                    break
            if not dominated:
                for i in reversed(removals):
                    del self[i]
                self.append(copy.deepcopy(candidate))
        self.sort(key=lambda ind: tuple(ind.fitness.values))


class Statistics:
    def __init__(self, key):
        self.key = key
        self.functions = {}

    @property
    def fields(self):
        return list(self.functions)

    def register(self, name, function, *args, **kwargs):
        self.functions[name] = (function, args, kwargs)

    def compile(self, population):
        values = [self.key(ind) for ind in population]
        return {name: fn(values, *args, **kwargs) for name, (fn, args, kwargs) in self.functions.items()}


class Logbook(list):
    header = []

    def record(self, **kwargs):
        self.append(kwargs)

    @property
    def stream(self):
        if not self:
            return ""
        row = self[-1]
        return "\t".join(f"{k}={row.get(k)}" for k in self.header)


def _fronts(population):
    dominates = defaultdict(list)
    count = defaultdict(int)
    first = []
    for p in population:
        for q in population:
            if p is q:
                continue
            if p.fitness.dominates(q.fitness):
                dominates[id(p)].append(q)
            elif q.fitness.dominates(p.fitness):
                count[id(p)] += 1
        if count[id(p)] == 0:
            first.append(p)
    fronts = [first]
    while fronts[-1]:
        nxt = []
        for p in fronts[-1]:
            for q in dominates[id(p)]:
                count[id(q)] -= 1
                if count[id(q)] == 0:
                    nxt.append(q)
        fronts.append(nxt)
    return fronts[:-1]


def _crowding(front):
    if not front:
        return {}
    distance = {id(ind): 0.0 for ind in front}
    n_obj = len(front[0].fitness.values)
    for objective in range(n_obj):
        ordered = sorted(front, key=lambda ind: ind.fitness.values[objective])
        distance[id(ordered[0])] = distance[id(ordered[-1])] = math.inf
        low = ordered[0].fitness.values[objective]
        high = ordered[-1].fitness.values[objective]
        if high == low:
            continue
        for previous, current, following in zip(ordered, ordered[1:], ordered[2:]):
            distance[id(current)] += (
                following.fitness.values[objective] - previous.fitness.values[objective]
            ) / (high - low)
    return distance


def selNSGA2(population, k):
    selected = []
    for front in _fronts(population):
        if len(selected) + len(front) <= k:
            selected.extend(front)
        else:
            distance = _crowding(front)
            selected.extend(sorted(front, key=lambda ind: distance[id(ind)], reverse=True)[: k - len(selected)])
            break
    return selected


tools = SimpleNamespace(
    ParetoFront=ParetoFront,
    Statistics=Statistics,
    Logbook=Logbook,
    selNSGA2=selNSGA2,
)
