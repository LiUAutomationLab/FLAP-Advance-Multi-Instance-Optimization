import pandas as pd
import numpy as np
# from sklearn.metrics.pairwise import cosine_similarity
try:
    import networkx as nx
except ImportError:  # Optional: only used by deprecated dataset-generation helpers.
    nx = None
# import community as community_louvain
import random


class GeneratorLoader:
    """ This class allows loading a dataset a creating a generator that will return one order at the time"""

    #  TODO decide how we would like to collect the product information and fit this into an order

    def __init__(self, dataset_path):
        """
        The constructor for the GeneratorLoader class.

        :param dataset_path: The path for the dataset that will be used as the base for generating data.
        """
        self.df = None
        self.dataset_path = dataset_path
        self.generator = None

    # def setup_loader(self):
    #     """
    #     This method creates a generator for serving orders one at the time upon request. The generated orders
    #     are representative of the original dataset whose path was previously specified in the constructor.
    #     """
    #     self.df = load_dataset(self.dataset_path)
    #     frequency_table = self.df.groupby(['Order', 'Product']).agg({'Quantity': 'sum'}).unstack(fill_value=0)
    #     communities = cosine_similarity_community_clustering(frequency_table, threshold=100)
    #     cluster_distribution = generate_cluster_distribution(communities, len(self.df))
    #
    #     self.generator = sample_generator(frequency_table, communities, cluster_distribution)

    def get_next_order(self):
        """
        This method returns one order at the time. Prior to the usage of the method, the `setup_loader` method
        must have been called to load the base dataset and create the generator function.
        :return: One representative order based on the base dataset. The returned point is a dictionary whose keys
         are strings containing the Product ID and whose values are integers containing the quantity of items
         corresponding to that Product ID. The entire dictionary is the order. Additional details such as teh product's
         dimensions and weight need to be fetched from the original dataset.
        """
        return next(self.generator)


# class DatasetCreator:
#     """ This class allows creating a new dataset based on a base dataset. The new dataset is sampled from the base
#     dataset and will keep similar properties to it in respect to the distribution of product type and their quantities
#     per order."""
#
#     def __init__(self, original_dataset_path):
#         """
#         The constructor for the DatasetCreator class.
#         :param original_dataset_path: The path for the dataset that will be used as the base for generating data.
#         """
#         self.df = None
#         self.original_dataset_path = original_dataset_path
#
#     def create_dataset(self, dataset_size):
#         """
#         This method creates a new dataset with a specified number of orders based on the dataset whose path was
#         specified in the constructor. The generated dataset is similar to the original dataset.
#         :param dataset_size: The number of orders to be included in the generated dataset.
#         """
#         self.df = create_new_dataset(self.original_dataset_path, dataset_size)
#
#     def store_dataset(self, destination_dataset_path):
#         self.df.to_csv(destination_dataset_path, index=False)


def __get_b_dict(a_list, frequency_table):
    b_dict = {}
    for a in a_list:
        b_dict[a] = [(b, frequency_table.loc[a][('Quantity', b)]) for b in frequency_table.columns.levels[1] if
                     frequency_table.loc[a][('Quantity', b)] > 0]
    return b_dict


# def cosine_similarity_community_clustering(frequency_table, threshold=100):
#     """
#     This method performs clustering of a dataset based on the frequency table of product's types and quantities by order.
#     The maximum cluster size can be controlled by the threshold parameter. All the clusters exceeding that value are
#     re-clustered recursively.
#
#     The correct frequency table can be obtained by calling:
#
#     ```
#     frequency_table = self.df.groupby(['Order', 'Product']).agg({'Quantity': 'sum'}).unstack(fill_value=0)
#     ```
#
#     :param frequency_table: the frequency table of product's types and quantities by order.
#     :param threshold: the maximum size of the clusters.
#     :return: a dictionary where the keys are string representing the Cluster ID and the values are lists of string with
#     the Order IDs.
#     """
#     # calculate cosine similarity matrix
#     # cos_sim = cosine_similarity(frequency_table)
#
#     # cos_sim_df = pd.DataFrame(cos_sim, index=frequency_table.index, columns=frequency_table.index)
#     #
#     ## convert the adjacency matrix to a NetworkX graph
#     # np.fill_diagonal(cos_sim_df.values, 0)
#
#     # g = nx.from_pandas_adjacency(cos_sim_df)
#     #
#     # run the Louvain algorithm to detect communities
#     # partition = community_louvain.best_partition(g, resolution=1)
#
#     community_dict = {}
#     for node, community in partition.items():
#         if community in community_dict:
#             community_dict[community].append(node)
#         else:
#             community_dict[community] = [node]
#
#     final_community_dict = {}
#     for community, nodes in community_dict.items():
#         if len(nodes) <= threshold:
#             final_community_dict[community] = nodes
#         else:
#             sub_community_dict = cosine_similarity_community_clustering(frequency_table.loc[nodes], threshold)
#             for sub_community, sub_nodes in sub_community_dict.items():
#                 final_community_dict[f"{community}.{sub_community}"] = sub_nodes
#
#     return final_community_dict


def generate_cluster_distribution(communities, total_data_points):
    """
    This method calculates the distribution of orders per cluster.
    The dictionary of order clusters can be obtained by calling the method `cosine_similarity_community_clustering`.

    The total number of datapoints can be obtained by calling: `len(df)` where df is the dataframe that generated the clusters.

    :param communities: The order clusters in the dataset.
    :param total_data_points: The total number of orders in the dataset
    :return: A dictionary with the distribution of orders per cluster where the keys are the Cluster IDs and the values
    are the percentage of orders that belong in those clusters.
    """
    cluster_distribution = {}
    for cluster_num, cluster_data in communities.items():
        num_points = len(cluster_data)
        percent_points = (num_points / total_data_points) * 100
        cluster_distribution[cluster_num] = percent_points
    return cluster_distribution


def __sample_cluster(cluster_distribution):
    total = sum(cluster_distribution.values())
    rand_val = random.uniform(0, total)
    curr_total = 0
    for cluster, percent in cluster_distribution.items():
        curr_total += percent
        if curr_total >= rand_val:
            return cluster


def __generate_representative_data_point(b_dict):
    b_occurrences = {}
    c_distribution = {}

    for a, b_list in b_dict.items():
        for b, c in b_list:
            if b in b_occurrences:
                b_occurrences[b] += 1
            else:
                b_occurrences[b] = 1

            if b not in c_distribution:
                c_distribution[b] = []

            c_distribution[b].append(c)

    selected_bs = random.choices(list(b_occurrences.keys()), list(b_occurrences.values()),
                                 k=random.randint(1, len(b_occurrences)))

    representative_data_point = {}
    for b in selected_bs:
        c_values = c_distribution[b]
        random_c = random.choice(c_values)
        representative_data_point[b] = random_c

    return representative_data_point


def __generate_random_non_repeating(a, b):
    numbers = list(range(a, b + 1))  # Create a list of numbers from a to b
    random.shuffle(numbers)  # Shuffle the list randomly
    return numbers.pop()  # Remove and return the last number from the shuffled list


def __create_new_dataset(new_df, original_df, values_dict):
    document = __generate_random_non_repeating(100000, 999999)

    for product, src_qty in values_dict.items():
        # Retrieve the matching row from the original_df for the product
        matching_row = original_df.loc[original_df['Product'] == product].iloc[0]

        # Copy the values from the matching row to create a new row
        new_row = {
            'Order': document,
            'Product': product,
            'Quantity': src_qty,
            'Length': matching_row['Length'],
            'Width': matching_row['Width'],
            'Height': matching_row['Height'],
            'Weight': matching_row['Weight']
        }

        new_row_df = pd.DataFrame([new_row])
        new_df = pd.concat([new_df, new_row_df], ignore_index=True)

    return new_df


def load_dataset(input_file_path):
    """
    This method load the dataset whose path was specified in the constructor.
    """
    df = pd.read_csv(input_file_path, sep=',', dtype=str,
                     usecols=['Order', 'Product', 'Quantity', 'Length', 'Width',
                              'Height', 'Weight'])
    df[['Quantity', 'Length', 'Width', 'Height']] = df[
        ['Quantity', 'Length', 'Width', 'Height']].astype(int)
    df[['Weight']] = df[['Weight']].astype(float)

    return df


# def create_new_dataset(input_file_path, num_samples):
#     """
#     This method creates a new dataset with a specified number of orders based on the dataset whose path was
#     specified in the constructor. The generated dataset is similar to the original dataset.
#     :param input_file_path: The file path for the base dataset.
#     :param num_samples:  The number of samples to be included in the created dataset.
#     :return: The created dataset.
#     """
#     print("Loading the dataset...")
#     dataset = load_dataset(input_file_path)
#
#     print("Preparing main frequency table...")
#     frequency_table = dataset.groupby(['Order', 'Product']).agg({'Quantity': 'sum'}).unstack(fill_value=0)
#     print(frequency_table)
#
#     print("Calculating cosine sim for main frequency table...")
#     # communities = cosine_similarity_community_clustering(frequency_table, threshold=100)
#
#     print("Calculating cluster distribution...")
#     cluster_distribution = generate_cluster_distribution(communities, len(dataset))
#
#     new_df = pd.DataFrame(columns=dataset.columns)  # Empty DataFrame with the same columns as the original df
#
#     for _ in range(num_samples):
#         sampled_cluster = __sample_cluster(cluster_distribution)
#         b_dict = __get_b_dict(communities[sampled_cluster], frequency_table)
#         rep_data_point = __generate_representative_data_point(b_dict)
#         new_df = __create_new_dataset(new_df, dataset, rep_data_point)
#
#     return new_df


def sample_generator(frequency_table, communities, cluster_distribution):
    """
    This method is a generator function that yields a representative datapoint based on
    the frequency table of the frequency table of product's types and quantities by order, a dictionary of order clusters
    and the distribution of order per cluster. The frequency table can be obtained by calling:

    ```
    frequency_table = self.df.groupby(['Order', 'Product']).agg({'Quantity': 'sum'}).unstack(fill_value=0)
    ```

    The dictionary of cluster order can be obtained by calling the method `cosine_similarity_community_clustering`.
    The cluster_distribution can be obtained by calling `generate_cluster_distribution` method.

    :param frequency_table: The frequency table.
    :param communities: The dictionary of order clusters.
    :param cluster_distribution: The distribution of order per cluster.
    """
    while True:
        sampled_cluster = __sample_cluster(cluster_distribution)
        b_dict = __get_b_dict(communities[sampled_cluster], frequency_table)
        representative_data_point = __generate_representative_data_point(b_dict)
        yield representative_data_point
