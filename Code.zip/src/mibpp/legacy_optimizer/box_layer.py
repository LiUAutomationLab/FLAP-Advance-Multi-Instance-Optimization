import numpy as np
import copy
import math


class BoxLayer:

    def __init__(self, boxes, fill_rate, pallet_dims=(1200, 800, 1400)):
        self.__layer_name = boxes[0].name
        self.__layer_product_types = [[int(boxes[0].name), len(boxes)]]
        self.__boxes = boxes
        self.__layer_weight = 0
        self.__layer_height = boxes[0].height
        self.__layer_fill_rate = fill_rate
        self.__layer_base_height = 0
        self.__pallet_dims = pallet_dims
        self.__top_faces = []
        self.__com = [0, 0, 0]
        for box in self.__boxes:
            box_com = box.anchor_point[0] + box.poses[box.pose_index][2]
            self.__update_com(box.weight, box_com)
            self.__layer_weight += box.weight
            self.__top_faces.append(box.poses[box.pose_index])

    def get_layer_weight(self):
        return self.__layer_weight

    def get_layer_name(self):
        return self.__layer_name

    def get_layer_height(self):
        return self.__layer_height

    def get_layer_base_height(self):
        return self.__layer_base_height

    def get_layer_fill_rate(self):
        return self.__layer_fill_rate

    def get_layer_product_types(self):
        return self.__layer_product_types

    def get_layer_pallet_dims(self):
        return self.__pallet_dims

    def get_copy_of_boxes(self):
        return copy.deepcopy(self.__boxes)


    def get_true_copy_of_boxes(self):
        return self.__boxes

    def get_total_num_of_boxes(self):
        return len(self.__boxes)

    def get_layer_aps(self):
        aps = []
        for box in self.__boxes:
            for point in box.compute_top_face():
                np_point = point
                aps.extend([np_point.tolist()])
            for point in box.compute_bottom_face():
                np_point = point
                aps.extend([np_point.tolist()])
                # aps.extend([point])
        # return [point for point in aps]
        return aps

    def get_layer_eps(self):
        eps = []
        for box in self.__boxes:
            eps.extend(box.compute_extreme_points())
        return eps

    def get_layer_com(self):
        return self.__com

    def __update_com(self, weight, com):
        self.__com[0] = math.ceil((self.__com[0] * self.__layer_weight + com[0] * weight) / (self.__layer_weight + weight))
        self.__com[1] = math.ceil((self.__com[1] * self.__layer_weight + com[1] * weight) / (self.__layer_weight + weight))
        self.__com[2] = math.ceil((self.__com[2] * self.__layer_weight + com[2] * weight) / (self.__layer_weight + weight))

    def offset_layer(self, offset=[0, 0, 0]):
        self.__layer_base_height = offset[2]
        for box in self.__boxes:
            box.anchor_point += np.array(offset)
        """Adjust com for offset_layer here"""
        self.__com[0] = math.ceil(self.__com[0] + offset[0])
        self.__com[1] = math.ceil(self.__com[1] + offset[1])
        self.__com[2] = math.ceil(self.__com[2] + offset[2])

    def flip_layer_horizontal(self):
        centerline = int(self.__pallet_dims[0] / 2)
        for box in self.__boxes:
            distance = box.anchor_point[0][0] - centerline
            box.anchor_point[0][0] -= 2 * distance
            box.anchor_point[0][0] -= box.poses[box.pose_index][1][0]
        """Adjust com for horizontal flip here"""
        distance = self.__com[0] - centerline
        self.__com[0] -= 2 * distance


    def flip_layer_vertical(self):
        centerline = int(self.__pallet_dims[1] / 2)
        for box in self.__boxes:
            distance = box.anchor_point[0][1] - centerline
            box.anchor_point[0][1] -= 2 * distance
            box.anchor_point[0][1] -= box.poses[box.pose_index][1][1]
        """Adjust com for vertical flip here"""
        distance = self.__com[1] - centerline
        self.__com[1] -= 2 * distance

    def get_layer_anchor_points(self):
        anchor_points = []
        for box in self.__boxes:
            anchor_points.append(copy.deepcopy(box.anchor_point[0].tolist()))
        return anchor_points

    def add_boxes(self, boxes):
        for box in boxes:
            """Adjusting layer COM after adding a list of boxes"""
            box_com = box.anchor_point[0] + box.poses[box.pose_index][2]
            self.__update_com(box.weight, box_com)
            self.__layer_weight += box.weight
            self.__boxes.append(box)

    def merge(self, layer):
        if self.__pallet_dims == layer.get_layer_pallet_dims() and self.__layer_height == layer.get_layer_height():
            to_merge_layer = copy.deepcopy(layer)
            lowest_value = int(min(self.__pallet_dims))
            index_of_lowest_value = self.__pallet_dims.index(lowest_value)
            offset = [0, 0, 0]
            offset[index_of_lowest_value] = lowest_value
            to_merge_layer.offset_layer(offset)
            boxes = to_merge_layer.get_copy_of_boxes()
            """The COM of the layer is being updated inside the self.add_boxes() function"""
            self.add_boxes(boxes)
            self.__layer_name += '_M_' + layer.get_layer_name()
            self.__layer_product_types.append([int(boxes[0].name), len(boxes)])
            prel_layer_fill_rate = ((self.__layer_fill_rate / 100) * self.__pallet_dims[0] * self.__pallet_dims[1] + (
                    layer.get_layer_fill_rate() / 100) * layer.get_layer_pallet_dims()[0] *
                                    layer.get_layer_pallet_dims()[1]) * 100
            self.__pallet_dims = tuple(x + y for x, y in zip(self.__pallet_dims, offset))
            self.__layer_fill_rate = prel_layer_fill_rate / (self.__pallet_dims[0] * self.__pallet_dims[1])
            return self
        return None

    def is_supported(self, layer, min_supported_area_percent=0.75, min_contained_points=2):

        if layer is None:
            return False

        copied = copy.deepcopy(self)
        h_offset = layer.get_layer_base_height() + layer.get_layer_height()
        copied.offset_layer(offset=[0, 0, h_offset])

        for own_box in copied.get_copy_of_boxes():
            supported, cumulative_support_percent, cumulative_support, contained_points = own_box.is_supported_by_boxes_variable_criteria(
                layer.get_copy_of_boxes())
            if not supported:
                return False

        return True
