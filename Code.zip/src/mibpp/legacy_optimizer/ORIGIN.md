# Original FLAP optimizer

These modules are adapted from the user-provided `flap_optimizer_Jan_17_24.zip`
(17 January 2024). They contain the genuine homogeneous layer construction,
layer stacking into blocks, physical feasibility checks, and NSGA-II residual
packing logic used in the original study.

Compatibility changes are deliberately limited to package-relative imports,
optional legacy dependencies, deterministic serial evaluation, configurable GA
settings, and a lightweight replacement for the small subset of DEAP utilities
used by the archived code. The optimization/evaluation logic itself is retained.
