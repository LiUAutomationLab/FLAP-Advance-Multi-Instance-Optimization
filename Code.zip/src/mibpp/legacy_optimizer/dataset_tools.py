import sys
import pandas as pd


class Product:

    def __init__(self, product_id, length, width, height, weight, vol, quantity):
        self.product_id = product_id
        self.length = length
        self.width = width
        self.height = height
        self.weight = weight
        self.vol = vol
        self.quantity = quantity


class Order:

    def __init__(self, order_id, products):
        self.order_id = order_id
        self.products = products


def __create_order(row, orders):
    if not row[0] in orders:
        vol = int(row[3]) * int(row[4]) * int(row[5])
        orders.update({row[0]: {row[1]: Product(row[1], row[3], row[4], row[5], row[6], vol, row[2])}})
    elif row[1] in orders[row[0]]:
        orders[row[0]][row[1]].quantity += row[2]
    else:
        vol = int(row[3]) * int(row[4]) * int(row[5])
        orders[row[0]].update({row[1]: Product(row[1], row[3], row[4], row[5], row[6], vol, row[2])})


def get_order(order_id, df):  # order number example 310002224498
    df = df[(df['Order'] == order_id)]
    orders =__get_orders(df)
    return orders[0]


def get_orders(dataset, min_size=0, max_size=sys.maxsize, min_variety=0, max_variety=sys.maxsize):
    df_quantity = pd.DataFrame(dataset.groupby(['Order'])['Quantity'].sum())
    df_quantity.reset_index(inplace=True)

    df_quantity = df_quantity[
        (df_quantity['Quantity'] >= min_size) & (df_quantity['Quantity'] <= max_size)]

    df_variety = pd.DataFrame(dataset.groupby(['Order'])['Product'].nunique())
    df_variety.reset_index(inplace=True)

    df_variety.rename(columns={'Product': 'VarietyCount'}, inplace=True)
    df_variety = df_variety[
        (df_variety['VarietyCount'] >= min_variety) & (df_variety['VarietyCount'] <= max_variety)]

    df_quantity = df_quantity.assign(in_variety=df_quantity.Order.isin(df_variety.Order))

    df1 = pd.merge(df_quantity.loc[df_quantity['in_variety'] == True], dataset, left_on='Order',
                   right_on='Order')

    df1.rename(columns={'Quantity_y': 'Quantity'}, inplace=True)
    return __get_orders(df1)


def __get_orders(df):
    orders = {}

    [__create_order(row, orders) for row in zip(df['Order'], df['Product'],
                                                df['Quantity'], df['Length'], df['Width'], df['Height'], df['Weight'])]

    orders_x = [Order(key, list(value.values())) for key, value in orders.items()]
    return orders_x
