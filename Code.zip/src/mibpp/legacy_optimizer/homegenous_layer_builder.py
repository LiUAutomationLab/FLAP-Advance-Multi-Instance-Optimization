from .dataset_tools import Product
from .box import Box
from typing import List
from collections import Counter
from .box_layer import BoxLayer
import copy
import math


def _offset_distance(product_length, product_width, n_length, n_length_right, n_length_upper, n_width,
                     n_width_right, n_width_upper, pallet_size=(1200, 800, 1400)):
    """
    This function computes the residual distances that remain after computing a palletization pattern. Residual distances
    are computed in length and width.
    :param product_length: the length of the products in the palletization pattern.
    :param product_width: the width of the products in the palletization pattern.
    :param n_length: total number of products that fit in their native orientation in length.
    :param n_length_right: the total number of rotated products that would fit in width in the right remainder space.
    :param n_length_upper: the total number of rotated products that would fit in width in the upper remainder space.
    :param n_width: total number of products that fit in their native orientation in width.
    :param n_width_right: the total number of rotated products that would fit in length in the right remainder space.
    :param n_width_upper: the total number of rotated products that would fit in length in the upper remainder space.
    :param pallet_size: a tuple in the form of (pallet length, pallet width, pallet height)
    :return: two tuples, the first tuple contain the two residual distances to the right of palletization pattern,
    the second tuple contains the same but for the residual distances to the upper part of the pallet. The last value in
    each of the tuple is always bigger or equal to the first. Equal values means that the product palletizes
    the remainder space entirely on that dimension.
    """
    residual_length_right = pallet_size[0] - (n_length * product_length + n_length_right * product_width)
    residual_length_upper = pallet_size[0] - (
            n_length_upper * product_width) if n_width_upper >= 1 and n_length_upper >= 1 else 0

    residual_width_upper = pallet_size[1] - (n_width * product_width + n_width_upper * product_length)

    residual_width_right = pallet_size[1] - (
            n_width_right * product_length) if n_length_right >= 1 and n_width_right >= 1 else 0

    return (residual_length_right, residual_length_upper), (residual_width_upper, residual_width_right)


def _create_adjusted_boxes_main(product, n_length, n_width, default_orientation, lenght_offset, width_offset,
                                pallet_size=(1200, 800, 1400)):
    boxes = []
    for nl in range(math.floor(n_length)):
        for nw in range(math.floor(n_width)):
            box = Box(product.product_id, product.length, product.width, product.height, product.weight,
                      int(not default_orientation))

            if default_orientation:
                if n_width == 1 and product.width >= pallet_size[1] / 2:
                    if (nl + 1) * product.length > pallet_size[0] / 2 and n_length * product.length < pallet_size[0]:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length == pallet_size[0] and n_width * product.width < pallet_size[
                    1] and n_width > 1:
                    if (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width == pallet_size[
                    1] and n_width > 1:
                    if (nl + 1) * product.length > pallet_size[0] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 1]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length == pallet_size[0] and n_width * product.width == pallet_size[
                    1] and n_width > 1:
                    box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width < pallet_size[
                    1] and n_width > 1:
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]
                    if (nl + 1) * product.length >= pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    if (nl + 1) * product.length > pallet_size[0] / 2 and (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset,
                                                  nw * product.width + width_offset, 0]

                if product.length >= pallet_size[0] / 2 and nl == 0 and n_width > 1:
                    if (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

            else:
                if n_width == 1 and product.length >= pallet_size[1] / 2:
                    if (nl + 1) * product.width > pallet_size[0] / 2 and n_length * product.width < pallet_size[0]:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width == pallet_size[0] and n_width * product.length < pallet_size[
                    1] and n_width > 1:
                    if (nl + 1) * product.length > pallet_size[1] / 2 and nw != 0:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]
                if n_length * product.width < pallet_size[0] and n_width * product.length == pallet_size[
                    1] and n_width > 1:
                    if (nl + 1) * product.width > pallet_size[0] / 2 and nw != 0:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width == pallet_size[0] and n_width * product.length == pallet_size[
                    1] and n_width > 1:
                    box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width < pallet_size[0] and n_width * product.length < pallet_size[
                    1] and n_width > 1:

                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]
                    if (nl + 1) * product.width >= pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    if (nl + 1) * product.width > pallet_size[0] / 2 and (nw + 1) * product.length > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]

                if product.width >= pallet_size[0] / 2 and nl == 0 and n_width > 1 and nw != 0:
                    if (nl + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

            boxes.append(box)
    return boxes


def _create_adjusted_boxes_right(product, n_length, n_width, default_orientation, lenght_offset, width_offset,
                                 pallet_size=(1200, 800, 1400)):
    boxes = []
    for nl in range(math.floor(n_length)):
        for nw in range(math.floor(n_width)):
            box = Box(product.product_id, product.length, product.width, product.height, product.weight,
                      int(not default_orientation))

            if default_orientation:
                if n_length * product.length == pallet_size[0] and n_width * product.width < pallet_size[1]:
                    if (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width == pallet_size[1]:
                    if (nl + 1) * product.length > pallet_size[0] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length == pallet_size[0] and n_width * product.width == pallet_size[1]:
                    box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width < pallet_size[1]:
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    if (nl + 1) * product.length >= pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset,
                                                  nw * product.width + width_offset, 0]
                    if (nl + 1) * product.length > pallet_size[0] / 2 and (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset,
                                                  nw * product.width + width_offset, 0]
            else:
                if n_length * product.width == pallet_size[0] and n_width * product.length < pallet_size[1]:
                    if (nw + 1) * product.length > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width < pallet_size[0] and n_width * product.length == pallet_size[1]:
                    if (nl + 1) * product.width > pallet_size[0] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width == pallet_size[0] and n_width * product.length == pallet_size[1]:
                    box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width < pallet_size[0] / 2 and n_width * product.length < pallet_size[1]:

                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    if (nl + 1) * product.width >= pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]
                    if (nl + 1) * product.width > pallet_size[0] / 2 and (nw + 1) * product.length > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]
            boxes.append(box)
    return boxes


def _create_adjusted_boxes_upper(product, n_length, n_width, default_orientation, lenght_offset, width_offset,
                                 pallet_size=(1200, 800, 1400)):
    boxes = []
    for nl in range(math.floor(n_length)):
        for nw in range(math.floor(n_width)):
            box = Box(product.product_id, product.length, product.width, product.height, product.weight,
                      int(not default_orientation))

            if default_orientation:
                if n_length * product.length == pallet_size[0] and n_width * product.width < pallet_size[1]:
                    if (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width == pallet_size[1]:
                    if (nl + 1) * product.length > pallet_size[0] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset, nw * product.width, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length == pallet_size[0] and n_width * product.width == pallet_size[1]:
                    box.anchor_point[0, :] = [nl * product.length, nw * product.width, 0]

                if n_length * product.length < pallet_size[0] and n_width * product.width < pallet_size[1]:
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    if (nl + 1) * product.length >= pallet_size[0] / 2 and (nw + 1) * product.width < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset,
                                                  nw * product.width + width_offset, 0]
                    if (nl + 1) * product.length < pallet_size[0] / 2 and (nw + 1) * product.width >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.length, nw * product.width + width_offset, 0]
                    if (nl + 1) * product.length > pallet_size[0] / 2 and (nw + 1) * product.width > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.length + lenght_offset,
                                                  nw * product.width + width_offset, 0]
            else:
                if n_length * product.width == pallet_size[0] and n_width * product.length < pallet_size[1]:
                    if (nw + 1) * product.length > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]

                if n_length * product.width < pallet_size[0] and n_width * product.length == pallet_size[1]:
                    if (nl + 1) * product.width > pallet_size[0] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset, nw * product.length, 0]
                    else:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width == pallet_size[0] and n_width * product.length == pallet_size[1]:
                    box.anchor_point[0, :] = [nl * product.width, nw * product.length, 0]

                if n_length * product.width < pallet_size[0] and n_width * product.length < pallet_size[1]:

                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    if (nl + 1) * product.width >= pallet_size[0] / 2 and (nw + 1) * product.length < pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]
                    if (nl + 1) * product.width < pallet_size[0] / 2 and (nw + 1) * product.length >= pallet_size[
                        1] / 2:
                        box.anchor_point[0, :] = [nl * product.width, nw * product.length + width_offset, 0]
                    if (nl + 1) * product.width > pallet_size[0] / 2 and (nw + 1) * product.length > pallet_size[1] / 2:
                        box.anchor_point[0, :] = [nl * product.width + lenght_offset,
                                                  nw * product.length + width_offset, 0]
            boxes.append(box)
    return boxes


def _create_adjusted_layer_with_conditions(n_length, n_width, right, n_length_right, n_width_right, upper,
                                           n_length_upper, n_width_upper, default_oriented,
                                           product, length_offset, width_offset, pallet_size):
    """
    This function creates a layer of products of the same kind by spacing the products in the area of the pallet so that
    any potential residual gaps are moved to the middle of the layer.

    :param right: the total number of rotated products that would fit in length the right remainder space.
    :param upper: the total number of rotated products that would fit in width the in the upper remainder space.
    :param n_length: total number of products that fit in their native orientation in length.
    :param n_length_right: the total number of rotated products that would fit in width in the right remainder space.
    :param n_length_upper: the total number of rotated products that would fit in width in the upper remainder space.
    :param n_width: total number of products that fit in their native orientation in width.
    :param n_width_right: the total number of rotated products that would fit in length in the right remainder space.
    :param n_width_upper: the total number of rotated products that would fit in length in the upper remainder space.
    :param pallet_size: a tuple in the form of (pallet length, pallet width, pallet height)
    :param default_oriented: can take the values True or False, True denotes the default orientation of the product, and False denotes
    the rotated orientation of the product.
    :param product: the product to be adjusted in the layer.
    :param length_offset: the residual length when creating a layer of the product
    :param width_offset: the residual width when creating a layer of the product

    :return:
    """
    boxes = []

    boxes.extend(
        _create_adjusted_boxes_main(product, n_length, n_width, default_oriented, length_offset[0], width_offset[0],
                                    pallet_size))
    if default_oriented:
        product_length = product.length
        product_width = product.width
    else:
        product_length = product.width
        product_width = product.length

    if right > 0:
        boxes.extend(
            _create_adjusted_boxes_right(product, n_length_right, n_width_right, not default_oriented,
                                         product_length * n_length + length_offset[0], width_offset[1], pallet_size))
    if upper > 0:
        boxes.extend(
            _create_adjusted_boxes_upper(product, n_length_upper, n_width_upper, not default_oriented, length_offset[1],
                                         product_width * n_width + width_offset[0], pallet_size))
    return boxes


def _create_layer_palletizing_pattern(product_length, product_width, pallet_size=(1200, 800, 1400)):
    """
       This function computes how many products of a specific length and width can fit in the area of the pallet without any regard
       for the height of the pallet, answering the question: how many products of one kind can be fit in one layer?
       The function will return the total number of products that can be fit in their native orientation and how many
       products will fit in an orthogonal orientation in the space that is left after boxes are fit in their native orientation.
       It is important to notice that after the main body of products is fit in their native orientation there will be a
       space remainder to the top and to the right of the pallet area. The function will return how many products would fill
       such spaces assuming that if rotated products will be filling the top remainder space they will not fill the right
       remainder space and vice versa. In the function output the total number of boxes that can be fit is therefore either:
       n_length * n_width + n_right or n_length * n_width + n_upper.
       :param product_length: the length of the one product.
       :param product_width: the width of the one product.
       :param pallet_size: a tuple in the form of (pallet length, pallet width, pallet height)
       :return: a dictionary with the following key/value pairs:
       {main: the total number of products in their native orientation,
       right: the total number of rotated products that would fit in length the right remainder space,
       upper: the total number of rotated products that would fit in width the in the upper remainder space,
       n_length: total number of products that fit in their native orientation in length,
       n_width: total number of products that fit in their native orientation in width,
       n_length_right: the total number of rotated products that would fit in width in the right remainder space,
       n_width_right: the total number of rotated products that would fit in length in the right remainder space,
       n_length_upper: the total number of rotated products that would fit in width in the upper remainder space
       n_width_upper: the total number of rotated products that would fit in length in the upper remainder space}
       """
    n_length = pallet_size[0] // product_length
    n_width = pallet_size[1] // product_width

    residual_length = pallet_size[0] - n_length * product_length
    residual_width = pallet_size[1] - n_width * product_width

    # Computing right area fitting for second orientation
    n_length_right = residual_length // product_width
    n_width_right = pallet_size[1] // product_length

    n_right = n_length_right * n_width_right if n_length_right >= 1 and n_width_right >= 1 else 0

    # Computing upper area fitting for second orientation
    n_length_upper = pallet_size[0] // product_width
    n_width_upper = residual_width // product_length

    n_upper = n_length_upper * n_width_upper if n_width_upper >= 1 and n_length_upper >= 1 else 0

    return {'main': n_length * n_width, 'right': n_right, 'upper': n_upper, 'n_length': n_length, 'n_width': n_width,
            'n_length_right': n_length_right, 'n_width_right': n_width_right, 'n_length_upper': n_length_upper,
            'n_width_upper': n_width_upper}


# def equal_height(product_list):
#     heights = list(map(lambda product: product.height, product_list))
#     counter = Counter(heights)
#
#     unique_heights = list(counter.items())
#
#     repeating_heights = list(map(lambda item: item[0], filter(lambda item: item[1] > 1, unique_heights)))
#     filtered_products = list(filter(lambda product: product.height in repeating_heights, product_list))
#
#     pallet_area = 1200 * 800
#     equal_height_products = []
#     for height in repeating_heights:
#
#         area = 0
#         temp_list = []
#         for product in filtered_products:
#             if product.height == height:
#                 product_area = product.quantity * product.width * product.length
#                 temp_list.append([product.product_id, product.quantity, round((product_area * 100) / pallet_area, 2)])
#                 area += product_area
#
#         equal_height_products.append([temp_list, (area * 100) / pallet_area])
#
#     print(equal_height_products)
#     return equal_height_products


def create_optimal_layer_palletizing_pattern(product: Product, pallet_size=(1200, 800, 1400)) -> List[Box]:
    """
    This function creates a single layer using a single product type. It also converts product into box object and
    generates a layer using the optimum palletizing pattern. The function will return a list of boxes and the total
    number boxes in that one single layer.
    :param product: the product to be palletized into a layer.
    :param pallet_size: the size of the pallet where the product is to be palletized.
    :return: a tuple with the list of boxes to be put in a layer and the total number of boxes packed.
    """
    result_native_orientation = _create_layer_palletizing_pattern(product.length, product.width, pallet_size)
    result_alternative_orientation = _create_layer_palletizing_pattern(product.width, product.length, pallet_size)

    res_nat_orientation_to_offset = copy.deepcopy(result_native_orientation)
    del res_nat_orientation_to_offset['main']
    del res_nat_orientation_to_offset['right']
    del res_nat_orientation_to_offset['upper']
    res_nat_alt_orientation_to_offset = copy.deepcopy(result_alternative_orientation)
    del res_nat_alt_orientation_to_offset['main']
    del res_nat_alt_orientation_to_offset['right']
    del res_nat_alt_orientation_to_offset['upper']

    res_len, res_wid = _offset_distance(product_length=product.length, product_width=product.width,
                                        pallet_size=pallet_size, **res_nat_orientation_to_offset)

    res_len_rot, res_wid_rot = _offset_distance(product_length=product.width, product_width=product.length,
                                                pallet_size=pallet_size, **res_nat_alt_orientation_to_offset)

    total_box_per_layer_native = result_native_orientation['main'] + result_native_orientation['right'] + \
                                 result_native_orientation['upper']
    total_box_per_layer_alternative = result_alternative_orientation['main'] + result_alternative_orientation['right'] + \
                                      result_alternative_orientation['upper']

    if total_box_per_layer_native >= total_box_per_layer_alternative:

        res_nat_orientation_to_adjust_layer = copy.deepcopy(result_native_orientation)
        del res_nat_orientation_to_adjust_layer['main']

        boxes = _create_adjusted_layer_with_conditions(default_oriented=True, product=product, length_offset=res_len,
                                                       width_offset=res_wid, pallet_size=pallet_size,
                                                       **res_nat_orientation_to_adjust_layer)
        total_box_per_layer = total_box_per_layer_native
    else:

        res_nat_alt_orientation_to_adjust_layer = copy.deepcopy(result_alternative_orientation)
        del res_nat_alt_orientation_to_adjust_layer['main']

        boxes = _create_adjusted_layer_with_conditions(default_oriented=False, product=product,
                                                       length_offset=res_len_rot,
                                                       width_offset=res_wid_rot, pallet_size=pallet_size,
                                                       **res_nat_alt_orientation_to_adjust_layer)
        total_box_per_layer = total_box_per_layer_alternative

    return boxes, total_box_per_layer


def build_layers(products_on_order, pallet_size=(1200, 800, 1400), fill_rate=90):
    """
    This function creates all the possible layers of products in an order that would fit a pallet with the specified
    dimension and desired fill rate.
    :param products_on_order: A list of products in an order to be sorted together as layers for palletizing.
    :param pallet_size: a tuple in the form of (pallet length, pallet width, pallet height).
    :param fill_rate: a integer from (1..100) that defines the minimum area pallet area to be covered for a layer to be
    considered valid.
    :return: a tuple consisting of a list of BoxLayers and a list of products that could not be made into layers according to the fill rate constraint.
    """

    residual_product_list = []
    layers = []

    for product in products_on_order:
        list_of_boxes, quantity = create_optimal_layer_palletizing_pattern(product, pallet_size)

        left_to_pack = product.quantity

        calculated_fill_rate = (quantity * product.width * product.length * 100) / (pallet_size[0] * pallet_size[1])

        if calculated_fill_rate >= fill_rate and product.quantity >= quantity:
            while left_to_pack >= quantity:
                layers.append(BoxLayer(copy.deepcopy(list_of_boxes), calculated_fill_rate, pallet_size))
                left_to_pack -= quantity

            if left_to_pack > 0:
                residual_product = Product(product.product_id, product.length, product.width, product.height,
                                           product.weight, product.vol, left_to_pack)
                residual_product_list.append(residual_product)

        else:
            residual_product = Product(product.product_id, product.length, product.width, product.height,
                                       product.weight, product.vol, left_to_pack)
            residual_product_list.append(residual_product)

    return layers, residual_product_list


def generate_homogeneous_layers_variable_fill(order, pallet_dimension=(1200, 800, 1400)):
    layers = []
    """Full layer"""

    best_layer = None
    best_residuals = None
    best_layer_size = 0

    # for fill_rate in range(100, 75, -5):
    full_layers, residual_1 = build_layers(order.products, pallet_dimension, fill_rate=85)
    if len(full_layers) > best_layer_size:
        best_layer_size = len(full_layers)
        best_layer = full_layers

    best_residuals = residual_1

    layers.extend(full_layers)

    """Half Layer"""
    best_half_layer = None
    best_half_residuals = None
    best_half_layer_size = 0
    if best_residuals:
        for fill_rate in range(100, 90, -5):
            half_layers, residual_2 = build_layers(best_residuals, pallet_size=(pallet_dimension[0]/2, pallet_dimension[1], pallet_dimension[2]), fill_rate=fill_rate)
            if len(half_layers) > best_half_layer_size:
                best_half_layer_size = len(half_layers)
                best_half_layer = half_layers
            best_half_residuals = residual_2

        layers.extend(half_layers)

    """Quarter Layer"""
    best_quarter_layer = None
    best_quarter_residuals = None
    best_quarter_layer_size = 0

    if best_half_residuals:
        for fill_rate in range(100, 90, -5):
            quarter_layers, residual_3 = build_layers(best_half_residuals, pallet_size=(pallet_dimension[0]/2, pallet_dimension[1]/2, pallet_dimension[2]),
                                                      fill_rate=fill_rate)
            if len(quarter_layers) > best_quarter_layer_size:
                best_quarter_layer_size = len(quarter_layers)
                best_quarter_layer = quarter_layers
            best_quarter_residuals = residual_3

        layers.extend(quarter_layers)

    if best_quarter_residuals is None:
        best_quarter_residuals = []

    return layers, best_quarter_residuals, best_layer, best_half_layer, best_quarter_layer
