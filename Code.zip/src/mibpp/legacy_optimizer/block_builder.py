import copy
from builtins import list

from . import homegenous_layer_builder as hlb
import numpy as np
from . import box_layer as bl
from . import box as bx
from . import residual_packing as rp
import math


def create_load_carrier(pallet_dims=(1200, 800, 1400)):
    load_carrier = bl.BoxLayer([bx.Box('load_carrier', pallet_dims[0], pallet_dims[1], 10, 5)], 100)
    return load_carrier


def create_layer_dict(layers):
    return {obj.get_layer_height(): [layer for layer in layers if layer.get_layer_height() == obj.get_layer_height()]
            for obj in layers}


def merge_layers(layers_dict):
    left_overs = []
    new_layers_dict = dict()
    for layer_name, layers in layers_dict.items():
        if len(layers) % 2 == 1:
            left_overs.append(layers.pop())

        if len(layers) > 0:
            merged = [l1.merge(l2) for l1, l2 in zip(layers[::2], layers[1::2])]
            new_layers_dict[layer_name] = merged

    return new_layers_dict, left_overs


def pre_process_layers(order, pallet_dimension=(1200, 800, 1400)):
    all_layers, box_residuals, full_layers, half_layers, quarter_layers = hlb.generate_homogeneous_layers_variable_fill(
        order, pallet_dimension=pallet_dimension)

    # if not len(quarter_layers) == 0:
    new_half_layers = None
    half_layers_dict = None
    new_full_layers = None
    half_layer_residuals = None
    quarter_layer_residuals = None
    half_layers_dict = {}
    if not full_layers:
        full_layers = []

    if quarter_layers:
        quarter_layers_dict = create_layer_dict(quarter_layers)

        new_half_layers, quarter_layer_residuals = merge_layers(quarter_layers_dict)

    if half_layers:
        half_layers_dict = create_layer_dict(half_layers)

    if new_half_layers:
        for layer_height, layers in new_half_layers.items():
            if layer_height in half_layers_dict:
                half_layers_dict[layer_height].extend(layers)
            else:
                half_layers_dict[layer_height] = layers

    if half_layers_dict:
        new_full_layers, half_layer_residuals = merge_layers(half_layers_dict)

    if new_full_layers:
        for layers in new_full_layers.values():
            full_layers.extend(layers)

    return full_layers, half_layer_residuals, quarter_layer_residuals, box_residuals


def euclidean_distance(point1, point2):
    return np.sqrt(np.sum((np.array(point1) - np.array(point2)) ** 2))


def hausdorff_distance(set1, set2):
    distances = []
    for point1 in set1:
        min_distance = np.inf
        for point2 in set2:
            distance = euclidean_distance(point1, point2)
            if distance < min_distance:
                min_distance = distance
        distances.append(min_distance)
    return max(distances)


class Block:

    def __init__(self, num_of_prod_type, pallet_dims=(1200, 800, 1400)):
        self.__loose_boxes = []
        self.__loose_boxes_aps = []
        self.__pallet_dims = pallet_dims
        self.__layers = []
        self.__last_full_layer_aps = []
        self.__last_full_layer_boxes = []
        self.__half_layers = [[], []]
        self.__last_half_layer_aps = [[], []]
        self.__last_half_layer_boxes = [[], []]
        self.__quadrant_layers = [[], [], [], []]
        self.__last_quadrant_layer_aps = [[], [], [], []]
        self.__last_quadrant_layer_boxes = [[], [], [], []]
        self.__total_num_of_boxes = 0
        self.__block_height = 0
        self.__half_heights = [0, 0]
        self.__quadrant_heights = [0, 0, 0, 0]
        self.__min_loose_block_height = 0
        self.__com = [0, 0, 0]
        self.__weight = 0
        self.__product_info_dict = {}
        self.__num_of_product_type = num_of_prod_type

    def get_all_layers_copy(self):
        all_layers = []
        all_layers.extend(self.__layers)
        all_layers.extend(self.__half_layers[0])
        all_layers.extend(self.__half_layers[1])
        all_layers.extend(self.__quadrant_layers[0])
        all_layers.extend(self.__quadrant_layers[1])
        all_layers.extend(self.__quadrant_layers[2])
        all_layers.extend(self.__quadrant_layers[3])

        # Printing layer information for a block
        # print("Num FL = ", len(self.__layers), "Num HL[0 1] = [", len(self.__half_layers[0]),
        #       len(self.__half_layers[1]), "]", "Num Quad [0 1 2 3] = [", len(self.__quadrant_layers[0]),
        #       len(self.__quadrant_layers[1]), len(self.__quadrant_layers[2]), len(self.__quadrant_layers[3]), "]")

        return copy.deepcopy(all_layers)

    def update_product_info_dict_with_layer(self, layer):
        product_info_in_layer = layer.get_layer_product_types()

        if len(product_info_in_layer) != 1:
            for item in product_info_in_layer:
                if item[0] in self.__product_info_dict:
                    self.__product_info_dict[item[0]] += item[1]
                else:
                    self.__product_info_dict[item[0]] = item[1]
        else:
            if product_info_in_layer[0][0] in self.__product_info_dict:
                self.__product_info_dict[product_info_in_layer[0][0]] += product_info_in_layer[0][1]
            else:
                self.__product_info_dict[product_info_in_layer[0][0]] = product_info_in_layer[0][1]

    def update_product_info_dict_with_box(self, box):
        if int(box.name) in self.__product_info_dict:
            self.__product_info_dict[int(box.name)] += 1
        else:
            self.__product_info_dict[int(box.name)] = 1

    def get_total_number_of_boxes(self):
        return self.__total_num_of_boxes

    def get_product_info_of_block(self):
        return self.__product_info_dict

    def get_total_number_of_product_type(self):
        return self.__num_of_product_type

    def remainder_height_to_layer(self):
        return self.__pallet_dims[2] - self.__block_height

    def remainder_height_to_half_layer(self):
        return self.__pallet_dims[2] - min(self.__half_heights)

    def remainder_height_to_quadrant_layer(self):
        return self.__pallet_dims[2] - min(self.__quadrant_heights)

    def remainder_envelope_height(self):
        envelope_height = max(self.__block_height, min(self.__half_heights), min(self.__quadrant_heights),
                              self.__min_loose_block_height)
        if envelope_height == 0:
            envelope_height = max(self.__block_height, max(self.__half_heights), min(self.__quadrant_heights),
                                  self.__min_loose_block_height)
        if envelope_height == 0:
            envelope_height = max(self.__block_height, min(self.__half_heights), max(self.__quadrant_heights),
                                  self.__min_loose_block_height)

        return self.__pallet_dims[2] - envelope_height

    def remainder_block_height(self):
        block_height = max(self.__block_height, max(self.__half_heights), max(self.__quadrant_heights))
        return self.__pallet_dims[2] - block_height

    def __layer_fits(self, layer):
        if layer.get_layer_height() > self.__pallet_dims[2] - self.__block_height:
            return False
        return True

    def __half_layer_fits(self, layer, half):
        if layer.get_layer_height() > self.__pallet_dims[2] - self.__half_heights[half]:
            return False
        return True

    def __quadrant_layer_fits(self, layer, quadrant):
        if layer.get_layer_height() > self.__pallet_dims[2] - self.__quadrant_heights[quadrant]:
            return False
        return True

    def __update_com(self, weight, com):
        self.__com[0] = math.ceil((self.__com[0] * self.__weight + com[0] * weight) / (self.__weight + weight))
        self.__com[1] = math.ceil((self.__com[1] * self.__weight + com[1] * weight) / (self.__weight + weight))
        self.__com[2] = math.ceil((self.__com[2] * self.__weight + com[2] * weight) / (self.__weight + weight))

    def get_block_weight(self):
        return self.__weight

    def get_block_com(self):
        return self.__com

    """__________________________Deprecated functions for calling all top aps____________________________"""

    # def __deprecated_check_top_layer_aps(self):
    #     if len(self.__layers) != 0:
    #         return self.__layers[-1].get_layer_aps()
    #     else:
    #         return [[0, 0, 0]]
    #
    # def __deprecated_check_top_half_aps(self, half_index):
    #     if len(self.__half_layers[half_index]) != 0:
    #         return self.__half_layers[half_index].get_layer_aps()
    #     else:
    #         return self.__deprecated_check_top_layer_aps()
    #
    # def __deprecated_check_top_quadrant_aps(self, quadrant_index):
    #     if len(self.__quadrant_layers[quadrant_index]) == 0:
    #         if quadrant_index == 2 or quadrant_index == 3:
    #             self.__deprecated_check_top_half_aps(1)
    #         else:
    #             self.__deprecated_check_top_half_aps(0)
    #     else:
    #         aps = self.__quadrant_layers[quadrant_index][0].get_layer_aps()
    #         return aps
    #
    # def __deprecated_check_top_aps(self):
    #     aps = []
    #     if self.__deprecated_check_top_quadrant_aps(0) is not None:
    #         aps.extend(self.__deprecated_check_top_quadrant_aps(0))
    #     aps.extend(self.__deprecated_check_top_quadrant_aps(1))
    #     aps.extend(self.__deprecated_check_top_quadrant_aps(2))
    #     aps.extend(self.__deprecated_check_top_quadrant_aps(3))
    #     return [x for x in aps]
    #
    # def deprecated_get_anchor_points(self):
    #     return self.__deprecated_check_top_aps()

    """__________________________________________________________________________________________________"""

    # def __deprecated_update_full_layer_aps_boxes(self, layer):
    #     list_of_aps = layer.get_layer_aps()
    #     list_of_boxes = layer.get_copy_of_boxes()
    #     if len(self.__last_full_layer_aps) == 0:
    #         self.__last_full_layer_aps.extend(list_of_aps)
    #         self.__last_full_layer_boxes.extend(list_of_boxes)
    #     else:
    #         self.__last_full_layer_aps.clear()
    #         self.__last_full_layer_boxes.clear()
    #         self.__last_full_layer_aps.extend(list_of_aps)
    #         self.__last_full_layer_boxes.extend(list_of_boxes)

    def __update_full_layer_eps_boxes(self, layer):
        list_of_eps = layer.get_layer_eps()
        list_of_boxes = layer.get_copy_of_boxes()
        if len(self.__last_full_layer_aps) == 0:
            self.__last_full_layer_aps.extend(list_of_eps)
            self.__last_full_layer_boxes.extend(list_of_boxes)
        else:
            self.__last_full_layer_aps.clear()
            self.__last_full_layer_boxes.clear()
            self.__last_full_layer_aps.extend(list_of_eps)
            self.__last_full_layer_boxes.extend(list_of_boxes)

    # def __deprecated_update_half_layer_aps_boxes(self, layer, half):
    #     list_of_aps = layer.get_layer_aps()
    #     list_of_boxes = layer.get_copy_of_boxes()
    #     if len(self.__last_half_layer_aps[half]) == 0:
    #         self.__last_half_layer_aps[half].extend(list_of_aps)
    #         self.__last_half_layer_boxes[half].extend(list_of_boxes)
    #     else:
    #         self.__last_half_layer_aps[half].clear()
    #         self.__last_half_layer_boxes[half].clear()
    #         self.__last_half_layer_aps[half].extend(list_of_aps)
    #         self.__last_half_layer_boxes[half].extend(list_of_boxes)

    def __update_half_layer_eps_boxes(self, layer, half):
        list_of_eps = layer.get_layer_eps()
        list_of_boxes = layer.get_copy_of_boxes()
        if len(self.__last_half_layer_aps[half]) == 0:
            self.__last_half_layer_aps[half].extend(list_of_eps)
            self.__last_half_layer_boxes[half].extend(list_of_boxes)
        else:
            self.__last_half_layer_aps[half].clear()
            self.__last_half_layer_boxes[half].clear()
            self.__last_half_layer_aps[half].extend(list_of_eps)
            self.__last_half_layer_boxes[half].extend(list_of_boxes)

    # def __deprecated_update_quad_layer_aps_boxes(self, layer, quadrant):
    #     list_of_aps = layer.get_layer_aps()
    #     list_of_boxes = layer.get_copy_of_boxes()
    #     if len(self.__last_quadrant_layer_aps[quadrant]) == 0:
    #         self.__last_quadrant_layer_aps[quadrant].extend(list_of_aps)
    #         self.__last_quadrant_layer_boxes[quadrant].extend(list_of_boxes)
    #     else:
    #         self.__last_quadrant_layer_aps[quadrant].clear()
    #         self.__last_quadrant_layer_boxes[quadrant].clear()
    #         self.__last_quadrant_layer_aps[quadrant].extend(list_of_aps)
    #         self.__last_quadrant_layer_boxes[quadrant].extend(list_of_boxes)

    def __update_quad_layer_eps_boxes(self, layer, quadrant):
        list_of_eps = layer.get_layer_eps()
        list_of_boxes = layer.get_copy_of_boxes()
        if len(self.__last_quadrant_layer_aps[quadrant]) == 0:
            self.__last_quadrant_layer_aps[quadrant].extend(list_of_eps)
            self.__last_quadrant_layer_boxes[quadrant].extend(list_of_boxes)
        else:
            self.__last_quadrant_layer_aps[quadrant].clear()
            self.__last_quadrant_layer_boxes[quadrant].clear()
            self.__last_quadrant_layer_aps[quadrant].extend(list_of_eps)
            self.__last_quadrant_layer_boxes[quadrant].extend(list_of_boxes)

    # def __deprecated_update_loose_boxes_aps(self, box):
    #     loose_aps = []
    #     for point in box.compute_top_face():
    #         np_point = point
    #         loose_aps.extend([np_point.tolist()])
    #     for point in box.compute_bottom_face():
    #         np_point = point
    #         loose_aps.extend([np_point.tolist()])
    #
    #     self.__loose_boxes_aps.extend(loose_aps)

    def __update_loose_boxes_eps(self, box):
        loose_eps = []
        loose_eps.extend(box.compute_extreme_points())
        self.__loose_boxes_aps.extend(loose_eps)

    def __check_top_full_aps(self):
        if len(self.__last_full_layer_aps) != 0:
            return self.__last_full_layer_aps
        else:
            return []

    def __check_top_half_aps(self, half):
        if len(self.__last_half_layer_aps[half]) != 0:
            return self.__last_half_layer_aps[half]
        else:
            return self.__check_top_full_aps()

    def __check_top_quadrant_aps(self, quadrant):
        if len(self.__last_quadrant_layer_aps[quadrant]) != 0:
            return self.__last_quadrant_layer_aps[quadrant]
        else:
            if quadrant == 2 or quadrant == 3:
                return self.__check_top_half_aps(1)
            else:
                return self.__check_top_half_aps(0)

    def __check_top_loose_boxes_aps(self):
        if self.__loose_boxes_aps:
            return self.__loose_boxes_aps
        else:
            return []

    def __check_top_aps(self):
        list_of_points = self.__check_top_quadrant_aps(0) + self.__check_top_quadrant_aps(
            1) + self.__check_top_quadrant_aps(2) + self.__check_top_quadrant_aps(
            3) + self.__check_top_loose_boxes_aps()
        return list_of_points

    def get_anchor_points(self):
        list_of_anchor_points = self.__check_top_aps()
        if len(list_of_anchor_points) == 0:
            return [[0, 0, 0]]
        else:
            # return list_of_anchor_points
            unique_set_of_points = set(map(tuple, list_of_anchor_points))
            unique_list_of_points = list(map(list, unique_set_of_points))
            return unique_list_of_points

    def __get_top_full_boxes(self):
        if len(self.__last_full_layer_boxes) != 0:
            return self.__last_full_layer_boxes
        else:
            pallet = bx.Box("pallet", self.__pallet_dims[0], self.__pallet_dims[1], 0, 0)
            return [pallet]
            # return []

    def get_top_loose_boxes(self):
        if len(self.__loose_boxes) != 0:
            return self.__loose_boxes
        else:
            return []

    def __get_top_half_boxes(self, half):
        if len(self.__last_half_layer_boxes[half]) != 0:
            return self.__last_half_layer_boxes[half]
        else:
            return self.__get_top_full_boxes()

    def __get_top_quad_boxes(self, quadrant):
        if len(self.__last_quadrant_layer_boxes[quadrant]) != 0:
            return self.__last_quadrant_layer_boxes[quadrant]
        else:
            if quadrant == 2 or quadrant == 3:
                return self.__get_top_half_boxes(1)
            else:
                return self.__get_top_half_boxes(0)

    def __get_boxes_from_block(self):
        list_of_boxes = []
        list_of_boxes = self.__get_top_quad_boxes(0) + self.__get_top_quad_boxes(1) + self.__get_top_quad_boxes(
            2) + self.__get_top_quad_boxes(3) + self.get_top_loose_boxes()
        return list_of_boxes

    def get_all_top_boxes_in_block(self):
        list_of_top_boxes = self.__get_boxes_from_block()
        top_boxes = list(set(list_of_top_boxes))

        return top_boxes

    def __add_pre_validated_box(self, box):
        self.__loose_boxes.append(box)
        self.__total_num_of_boxes += 1
        self.update_product_info_dict_with_box(box)
        self.__update_com(box.weight, box.poses[box.pose_index][2])
        self.__weight += box.weight
        # self.__update_loose_boxes_aps(box)
        self.__update_loose_boxes_eps(box)
        box_top_distance_from_block_base = box.calculate_top_point_distance_from_block_base()
        if self.__min_loose_block_height < box_top_distance_from_block_base:
            self.__min_loose_block_height = box_top_distance_from_block_base

    def __add_validated_full_layer(self, layer):
        layer.offset_layer([0, 0, self.__block_height])
        self.__block_height += layer.get_layer_height()
        self.__half_heights = [self.__block_height, self.__block_height]
        self.__quadrant_heights = [self.__block_height, self.__block_height, self.__block_height, self.__block_height]
        self.__layers.append(layer)
        self.__total_num_of_boxes += layer.get_total_num_of_boxes()
        self.update_product_info_dict_with_layer(layer)
        self.__update_com(layer.get_layer_weight(), layer.get_layer_com())
        self.__weight += layer.get_layer_weight()
        self.__update_full_layer_eps_boxes(layer)

    def __add_validated_half_layer(self, layer, half):
        if half == 0:
            layer.offset_layer([0, 0, self.__half_heights[half]])
            self.__quadrant_heights[0] += layer.get_layer_height()
            self.__quadrant_heights[1] += layer.get_layer_height()
        else:
            layer.offset_layer([self.__pallet_dims[0] // 2, 0, self.__half_heights[half]])
            self.__quadrant_heights[2] += layer.get_layer_height()
            self.__quadrant_heights[3] += layer.get_layer_height()

        self.__half_heights[half] += layer.get_layer_height()
        self.__half_layers[half].append(layer)
        self.__total_num_of_boxes += layer.get_total_num_of_boxes()
        self.update_product_info_dict_with_layer(layer)
        self.__update_com(layer.get_layer_weight(), layer.get_layer_com())
        self.__weight += layer.get_layer_weight()
        self.__update_half_layer_eps_boxes(layer, half)

    def __add_validated_quadrant_layer(self, layer, quadrant):
        if quadrant == 0:
            layer.offset_layer([0, 0, self.__quadrant_heights[quadrant]])
        elif quadrant == 1:
            layer.offset_layer([0, self.__pallet_dims[1] // 2, self.__quadrant_heights[quadrant]])
        elif quadrant == 2:
            layer.offset_layer(
                [self.__pallet_dims[0] // 2, self.__pallet_dims[1] // 2, self.__quadrant_heights[quadrant]])
        elif quadrant == 3:
            layer.offset_layer([self.__pallet_dims[0] // 2, 0, self.__quadrant_heights[quadrant]])

        self.__quadrant_heights[quadrant] += layer.get_layer_height()
        self.__quadrant_layers[quadrant].append(layer)
        self.__total_num_of_boxes += layer.get_total_num_of_boxes()
        self.update_product_info_dict_with_layer(layer)
        self.__update_com(layer.get_layer_weight(), layer.get_layer_com())
        self.__weight += layer.get_layer_weight()
        # self.__update_quad_layer_aps_boxes(layer, quadrant)
        self.__update_quad_layer_eps_boxes(layer, quadrant)

    def add_box_to_block(self, box, anchor_point, pose):
        box_to_be_added = copy.deepcopy(box)
        boxes_in_block = self.get_all_top_boxes_in_block()
        box_to_be_added.anchor_point[0, :] = anchor_point
        box_to_be_added.pose_index = pose

        # box_to_be_added_top_corner = box_to_be_added.anchor_point[0] + \
        #                              box_to_be_added.poses[box_to_be_added.pose_index][1]

        fit = True

        position = box_to_be_added.anchor_point[0] + box_to_be_added.poses[pose][1]

        if self.__pallet_dims[2] < position[2]:
            fit = False

        if self.__pallet_dims[1] < position[1]:
            fit = False

        if self.__pallet_dims[0] < position[0]:
            fit = False

        if fit:
            support, cumulative_support_percent, cumulative_support, contained_points = box_to_be_added.is_single_box_supported_by_boxes(boxes_in_block)
            if not support:
                fit = False

            if fit:
                if box_to_be_added.is_collided_by_boxes(boxes_in_block):
                    fit = False

        if fit:
            self.__add_pre_validated_box(box_to_be_added)
            return True
        else:
            return False

    def add_full_layer(self, layer):
        if not self.__layer_fits(layer):
            return False

        if self.__half_heights[0] != self.__block_height or self.__half_heights[1] != self.__block_height:
            return False

        if len(self.__layers) == 0:
            self.__add_validated_full_layer(layer)
            return True
        else:
            flipped_hor = copy.deepcopy(layer)
            flipped_hor.flip_layer_horizontal()
            flipped_ver = copy.deepcopy(layer)
            flipped_ver.flip_layer_vertical()
            flipped_hor_ver = copy.deepcopy(layer)
            flipped_hor_ver.flip_layer_horizontal()
            flipped_hor_ver.flip_layer_vertical()

            aps_own = self.__layers[-1].get_layer_anchor_points()

            aps_norm = layer.get_layer_anchor_points()
            aps_hor = flipped_hor.get_layer_anchor_points()
            aps_ver = flipped_ver.get_layer_anchor_points()
            aps_ver_hor = flipped_hor_ver.get_layer_anchor_points()

            distance = (hausdorff_distance(aps_own, aps_norm), hausdorff_distance(aps_own, aps_hor),
                        hausdorff_distance(aps_own, aps_ver), hausdorff_distance(aps_own, aps_ver_hor))

            indexes = sorted(range(len(distance)), key=lambda i: distance[i], reverse=True)

            for index in indexes:
                if index == 0 and layer.is_supported(self.__layers[-1]):
                    self.__add_validated_full_layer(layer)
                    return True
                elif index == 1 and flipped_hor.is_supported(self.__layers[-1]):
                    self.__add_validated_full_layer(flipped_hor)
                    return True
                elif index == 2 and flipped_ver.is_supported(self.__layers[-1]):
                    self.__add_validated_full_layer(flipped_ver)
                    return True
                elif index == 3 and flipped_hor_ver.is_supported(self.__layers[-1]):
                    self.__add_validated_full_layer(flipped_hor_ver)
                    return True

            return False

    def add_half_layer(self, layer):

        half = self.__half_heights.index(min(self.__half_heights))

        if not self.__half_layer_fits(layer, half):
            return False

        if self.__quadrant_heights[0] != self.__half_heights[0] or self.__quadrant_heights[1] != \
                self.__half_heights[0] \
                or self.__quadrant_heights[2] != self.__half_heights[1] or self.__quadrant_heights[3] != \
                self.__half_heights[1]:
            return False

        if len(self.__layers) == 0 and len(self.__half_layers[0]) == 0 and len(self.__half_layers[1]) == 0:
            self.__add_validated_half_layer(layer, half)
            return True
        else:
            flipped_hor = copy.deepcopy(layer)
            flipped_hor.flip_layer_horizontal()
            flipped_ver = copy.deepcopy(layer)
            flipped_ver.flip_layer_vertical()
            flipped_hor_ver = copy.deepcopy(layer)
            flipped_hor_ver.flip_layer_horizontal()
            flipped_hor_ver.flip_layer_vertical()

            if len(self.__half_layers[half]) != 0:
                aps_own = self.__half_layers[half][-1].get_layer_anchor_points()
            elif len(self.__layers) != 0:
                aps_own = self.__layers[-1].get_layer_anchor_points()
            else:
                # TODO I have added one additional test because there could be a case where we have an halflayer already but the other half is on the bottom of the pallet
                # TODO must recheck if this test makes any sense
                self.__add_validated_half_layer(layer, half)
                return True

            aps_norm = layer.get_layer_anchor_points()
            aps_hor = flipped_hor.get_layer_anchor_points()
            aps_ver = flipped_ver.get_layer_anchor_points()
            aps_ver_hor = flipped_hor_ver.get_layer_anchor_points()

            distance = (hausdorff_distance(aps_own, aps_norm), hausdorff_distance(aps_own, aps_hor),
                        hausdorff_distance(aps_own, aps_ver), hausdorff_distance(aps_own, aps_ver_hor))

            indexes = sorted(range(len(distance)), key=lambda i: distance[i], reverse=True)

            last_supporting_half_layer = None
            if len(self.__half_layers[half]) != 0:
                last_supporting_half_layer = self.__half_layers[half][-1]

            last_supporting_full_layer = None
            if len(self.__layers) != 0:
                last_supporting_full_layer = self.__layers[-1]

            for index in indexes:
                if index == 0 and (layer.is_supported(last_supporting_half_layer) or
                                   layer.is_supported(last_supporting_full_layer)):
                    self.__add_validated_half_layer(layer, half)
                    return True
                elif index == 1 and (
                        flipped_hor.is_supported(last_supporting_half_layer) or
                        flipped_hor.is_supported(last_supporting_full_layer)):
                    self.__add_validated_half_layer(flipped_hor, half)
                    return True
                elif index == 2 and (
                        flipped_ver.is_supported(last_supporting_half_layer) or
                        flipped_ver.is_supported(last_supporting_full_layer)):
                    self.__add_validated_half_layer(flipped_ver, half)
                    return True
                elif index == 3 and (flipped_hor_ver.is_supported(last_supporting_half_layer) or
                                     flipped_hor_ver.is_supported(last_supporting_full_layer)):
                    self.__add_validated_half_layer(flipped_hor_ver, half)
                    return True

            return False

    def add_quarter_layer(self, layer):
        quadrant = self.__quadrant_heights.index(min(self.__quadrant_heights))

        if not self.__quadrant_layer_fits(layer, quadrant):
            return False

        if len(self.__layers) == 0 and len(self.__half_layers[0]) == 0 and len(self.__half_layers[1]) == 0 and \
                len(self.__quadrant_layers[0]) == 0 and len(self.__quadrant_layers[1]) == 0 and \
                len(self.__quadrant_layers[2]) == 0 and len(self.__quadrant_layers[3]) == 0:

            self.__add_validated_quadrant_layer(layer, quadrant)
            return True
        else:
            flipped_hor = copy.deepcopy(layer)
            flipped_hor.flip_layer_horizontal()
            flipped_ver = copy.deepcopy(layer)
            flipped_ver.flip_layer_vertical()
            flipped_hor_ver = copy.deepcopy(layer)
            flipped_hor_ver.flip_layer_horizontal()
            flipped_hor_ver.flip_layer_vertical()

            if quadrant == 0 or quadrant == 1:
                half = 0
            else:
                half = 1

            if len(self.__quadrant_layers[quadrant]) != 0:
                aps_own = self.__quadrant_layers[quadrant][-1].get_layer_anchor_points()
            elif len(self.__half_layers[half]) != 0:
                aps_own = self.__half_layers[half][-1].get_layer_anchor_points()
            elif len(self.__layers) != 0:
                aps_own = self.__layers[-1].get_layer_anchor_points()
            else:
                self.__add_validated_quadrant_layer(layer, quadrant)
                return True

            aps_norm = layer.get_layer_anchor_points()
            aps_hor = flipped_hor.get_layer_anchor_points()
            aps_ver = flipped_ver.get_layer_anchor_points()
            aps_ver_hor = flipped_hor_ver.get_layer_anchor_points()

            distance = (hausdorff_distance(aps_own, aps_norm), hausdorff_distance(aps_own, aps_hor),
                        hausdorff_distance(aps_own, aps_ver), hausdorff_distance(aps_own, aps_ver_hor))

            indexes = sorted(range(len(distance)), key=lambda i: distance[i], reverse=True)

            last_supporting_quadrant_layer = None
            if len(self.__quadrant_layers[quadrant]) != 0:
                last_supporting_quadrant_layer = self.__quadrant_layers[quadrant][-1]

            last_supporting_half_layer = None
            if len(self.__half_layers[half]) != 0:
                last_supporting_half_layer = self.__half_layers[half][-1]

            last_supporting_full_layer = None
            if len(self.__layers) != 0:
                last_supporting_full_layer = self.__layers[-1]

            for index in indexes:
                if index == 0 and (
                        layer.is_supported(last_supporting_quadrant_layer) or
                        layer.is_supported(last_supporting_half_layer) or
                        layer.is_supported(last_supporting_full_layer)):

                    self.__add_validated_quadrant_layer(layer, quadrant)
                    return True
                elif index == 1 and (
                        flipped_hor.is_supported(last_supporting_quadrant_layer) or
                        flipped_hor.is_supported(last_supporting_half_layer) or
                        flipped_hor.is_supported(last_supporting_full_layer)):
                    self.__add_validated_quadrant_layer(flipped_hor, quadrant)
                    return True
                elif index == 2 and (
                        flipped_ver.is_supported(last_supporting_quadrant_layer) or
                        flipped_ver.is_supported(last_supporting_half_layer) or
                        flipped_ver.is_supported(last_supporting_full_layer)):

                    self.__add_validated_quadrant_layer(flipped_ver, quadrant)
                    return True
                elif index == 3 and (
                        flipped_hor_ver.is_supported(last_supporting_quadrant_layer) or
                        flipped_hor_ver.is_supported(last_supporting_half_layer) or
                        flipped_hor_ver.is_supported(last_supporting_full_layer)):

                    self.__add_validated_quadrant_layer(flipped_hor_ver, quadrant)
                    return True

            return False


LAYER_SORT_STRATEGIES = ("fill_first", "weight_first", "group_first")


def sort_full_layers(full_layers, strategy="fill_first"):
    """Return full layers in the bottom-to-top order used by the block builder."""
    if strategy not in LAYER_SORT_STRATEGIES:
        raise ValueError(
            f"Unknown full-layer sorting strategy {strategy!r}; "
            f"expected one of {LAYER_SORT_STRATEGIES}."
        )
    if strategy == "fill_first":
        # This is exactly the legacy ascending-sort + pop() priority.
        return sorted(full_layers or [], key=lambda layer: (
            float(layer.get_layer_fill_rate()), float(layer.get_layer_weight()),
            str(layer.get_layer_name())), reverse=True)
    elif strategy == "weight_first":
        return sorted(full_layers or [], key=lambda layer: (
            float(layer.get_layer_weight()), float(layer.get_layer_fill_rate()),
            str(layer.get_layer_name())), reverse=True)
    return sorted(full_layers or [], key=lambda layer: (
        str(layer.get_layer_name()), -float(layer.get_layer_fill_rate()),
        -float(layer.get_layer_weight())))


class BlockBuilder:

    def __init__(self, order, pallet_dims=(1200, 800, 1400), ga_config=None,
                 layer_sort_strategy="fill_first"):
        self.__pallet_dims = pallet_dims
        self.__blocks = []
        self.__order = order
        self.__total_product_type = len(order.products)
        self.__ga_config = dict(ga_config or {})
        if layer_sort_strategy not in LAYER_SORT_STRATEGIES:
            raise ValueError(f"Unsupported layer_sort_strategy: {layer_sort_strategy}")
        self.__layer_sort_strategy = layer_sort_strategy
        self.__last_pareto_solutions = []
        self.__initial_residual_boxes = 0
        self.__initial_residual_variety = 0

    def __palletize_full_layers(self, full_layers):
        if full_layers is not None:
            ordered_layers = sort_full_layers(full_layers, self.__layer_sort_strategy)

            current_block = Block(self.__total_product_type, self.__pallet_dims)
            self.__blocks.append(current_block)
            for layer in ordered_layers:
                if not current_block.add_full_layer(layer):
                    fit = False
                    for block in self.__blocks:
                        if block is current_block:
                            continue
                        current_block = block
                        if current_block.add_full_layer(layer):
                            fit = True
                            break

                    if not fit:
                        current_block = Block(self.__total_product_type, self.__pallet_dims)
                        if not current_block.add_full_layer(layer):
                            raise ValueError(
                                f"Full layer {layer.get_layer_name()} does not fit an empty pallet block."
                            )
                        self.__blocks.append(current_block)
                        self.__blocks.sort(key=lambda blk: blk.remainder_height_to_layer(), reverse=True)
            return True
        return False

    def __palletize_half_residual_layers(self, half_layer_residuals):
        self.__blocks.sort(key=lambda blk: blk.remainder_height_to_layer())

        if half_layer_residuals:
            while len(half_layer_residuals) > 0:
                layer = half_layer_residuals.pop()
                found = False
                for block in self.__blocks:
                    if block.add_half_layer(layer):
                        found = True
                        break

                if not found:
                    new_block = Block(self.__total_product_type, self.__pallet_dims)
                    new_block.add_half_layer(layer)
                    self.__blocks.append(new_block)
                    self.__blocks.sort(key=lambda blk: blk.remainder_height_to_half_layer(), reverse=True)

    def __palletize_quadrant_residual_layers(self, quarter_layer_residuals):
        self.__blocks.sort(key=lambda blk: blk.remainder_height_to_half_layer(), reverse=True)

        if quarter_layer_residuals:
            while len(quarter_layer_residuals) > 0:
                layer = quarter_layer_residuals.pop()
                found = False
                for block in self.__blocks:
                    if block.add_quarter_layer(layer):
                        found = True
                        break

                if not found:
                    new_block = Block(self.__total_product_type, self.__pallet_dims)
                    new_block.add_quarter_layer(layer)
                    self.__blocks.append(new_block)
                    self.__blocks.sort(key=lambda blk: blk.remainder_height_to_quadrant_layer(), reverse=True)

    def __palletize_residual_layers(self, half_layer_residuals, quarter_layer_residuals):
        self.__palletize_half_residual_layers(half_layer_residuals)
        self.__palletize_quadrant_residual_layers(quarter_layer_residuals)

    def __palletize_residual_boxes(self, box_residuals):
        cfg = {"pop_size": 100, "num_gen": 30, "mu": 15, "lambda_": 30,
               "cxpb": 0.5, "mutpb": 0.2, "max_stagnation": 5}
        cfg.update(self.__ga_config)
        pop_size = int(cfg.pop("pop_size"))
        residual_packing = rp.ResidualPacking(
            (copy.deepcopy(box_residuals), copy.deepcopy(self.__blocks)),
            pop_size,
            **cfg,
        )
        hof, pop, logbook = residual_packing.run()
        self.__last_pareto_solutions = [
            (tuple(ind.fitness.values), copy.deepcopy(ind.metadata[1]))
            for ind in hof
            if ind.metadata is not None and bool(ind.metadata[0])
        ]
        # TODO update blocks[] based on the hof
        # raise NotImplementedError(
        #     "__palletize_residual_boxes -> This function is not yet implemented, see comments on the code")

        best = hof[-1]
        vaild_solution, list_of_blocks = best.metadata
        return vaild_solution, list_of_blocks

    def get_last_pareto_solutions(self):
        """Return genuine feasible hall-of-fame residual-packing solutions."""
        return copy.deepcopy(self.__last_pareto_solutions)

    def get_initial_residual_counts(self):
        return self.__initial_residual_boxes, self.__initial_residual_variety

    def run(self):
        full_layers, half_layer_residuals, quarter_layer_residuals, box_residuals = pre_process_layers(self.__order, self.__pallet_dims)    # box_residuals => list of residual product_types
        self.__initial_residual_boxes = sum(int(product.quantity) for product in box_residuals)
        self.__initial_residual_variety = len(box_residuals)
        self.__palletize_full_layers(full_layers)
        self.__palletize_residual_layers(half_layer_residuals, quarter_layer_residuals)

        if len(box_residuals) > 1:
            total_vol_of_box_residual = 0
            for product in box_residuals:
                total_vol_of_box_residual += product.quantity * product.vol

            total_usable_vol_all_blocks = 0

            for block in self.__blocks:
                remaining_height_in_block = block.remainder_block_height()
                fit = False
                for product in box_residuals:
                    product_height = product.height
                    if product_height <= remaining_height_in_block:
                        fit = True
                        break

                if fit:
                    total_usable_vol_all_blocks += remaining_height_in_block * self.__pallet_dims[0] * self.__pallet_dims[1]

            if total_vol_of_box_residual < total_usable_vol_all_blocks:
                solution, list_of_blocks = self.__palletize_residual_boxes(box_residuals)
                valid_solution = solution
            else:
                new_block = Block(self.__total_product_type, self.__pallet_dims)
                self.__blocks.extend([new_block])
                solution, list_of_blocks = self.__palletize_residual_boxes(box_residuals)
                valid_solution = solution

            # print(list_of_blocks)
            num_of_ga = 1
            while not valid_solution:
                new_block = Block(self.__total_product_type, self.__pallet_dims)
                self.__blocks.extend([new_block])
                solution, list_of_blocks = self.__palletize_residual_boxes(box_residuals)
                valid_solution = solution
                num_of_ga += 1
        elif len(box_residuals) == 1:
            fitness, result = rp.run_evaluation(self.__blocks, box_residuals)
            valid_solution = result[0]
            if valid_solution:
                list_of_blocks = result[1]
                num_of_ga = 0
            else:
                while not valid_solution:
                    new_block = Block(self.__total_product_type, self.__pallet_dims)
                    self.__blocks.extend([new_block])
                    fitness, result = rp.run_evaluation(self.__blocks, box_residuals)
                    list_of_blocks = result[1]
                    num_of_ga = 0
                    valid_solution = result[0]
        else:
            list_of_blocks = self.__blocks
            num_of_ga = 0

        # return self.__blocks, box_residuals  # TODO delete the return of box_residuals when everything is done
        # return self.__blocks
        return list_of_blocks, box_residuals, num_of_ga
