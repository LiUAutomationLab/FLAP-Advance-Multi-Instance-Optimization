from . import algorithms
# import math
import random
import numpy as np
from .deap_compat import tools
import copy
import math
from . import box as bx
import sys


def print_progress_bar(current_value, total_value):
    import os
    if os.environ.get("MIBPP_LEGACY_PROGRESS") != "1":
        return
    percentage = (current_value / total_value) * 100
    completed = int(percentage)
    incomplete = 100 - completed

    # Generate the progress bar with '|' for completed and ' ' (space) for incomplete
    progress_bar = "|" * completed + " " * incomplete + "|| 100 %"

    print(f"Completion: [{progress_bar}] {percentage:.2f}%")


def is_pareto_efficient(costs, return_mask=True):
    """
    Find the pareto-efficient points
    :param costs: An (n_points, n_costs) array
    :param return_mask: True to return a mask
    :return: An array of indices of pareto-efficient points.
        If return_mask is True, this will be an (n_points, ) boolean array
        Otherwise it will be a (n_efficient_points, ) integer array of indices.
    """
    is_efficient = np.arange(costs.shape[0])
    n_points = costs.shape[0]
    next_point_index = 0  # Next index in the is_efficient array to search for
    while next_point_index < len(costs):
        nondominated_point_mask = np.any(costs < costs[next_point_index], axis=1)
        nondominated_point_mask[next_point_index] = True
        is_efficient = is_efficient[nondominated_point_mask]  # Remove dominated points
        costs = costs[nondominated_point_mask]
        next_point_index = np.sum(nondominated_point_mask[:next_point_index]) + 1
    if return_mask:
        is_efficient_mask = np.zeros(n_points, dtype=bool)
        is_efficient_mask[is_efficient] = True
        return is_efficient_mask
    else:
        return is_efficient


def calculate_distance(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    return distance


class ResidualPacking:

    def __init__(self, problem_context, pop_size, num_gen=200, mu=20, lambda_=40, cxpb=0.5, mutpb=0.2,
                 max_stagnation=40):
        self.problem_context = problem_context
        self.pop_size = pop_size
        self.num_gen = num_gen
        self.mu = mu
        self.lambda_ = lambda_
        self.cxpb = cxpb
        self.mutpb = mutpb
        self.max_stagnation = max_stagnation

    def run(self):
        population = initialize_population(self.pop_size, self.problem_context)
        hof = tools.ParetoFront()
        stats = tools.Statistics(lambda ind: ind.fitness.values)
        stats.register("min", min)
        stats.register("max", max)

        population, logbook = algorithms.eaMuPlusLambdaWithEarlyStopping(population, evaluate, mate, mutate,
                                                                         ngen=self.num_gen, stats=stats, halloffame=hof,
                                                                         mu=self.mu,
                                                                         lambda_=self.lambda_,
                                                                         cxpb=self.cxpb, mutpb=self.mutpb,
                                                                         max_stagnation=self.max_stagnation)
        return hof, population, logbook


def representation(products):
    product_ids = [int(product.product_id) for product in products]
    random.shuffle(product_ids)
    # print(product_ids)
    return product_ids


def initialize_population(pop_size, problem_context):
    pop = []

    if pop_size > 10:
        for n in range(pop_size - 10):
            problem_context_deepcopy = copy.deepcopy(problem_context)
            indiv = algorithms.Individual(weights=(-1.0, 1.0))
            indiv.extend(representation(problem_context_deepcopy[0]))
            indiv.problem_context = problem_context_deepcopy
            pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.weight, reverse=True)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.weight, reverse=False)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.quantity, reverse=False)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.quantity, reverse=True)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.length * product.width, reverse=True)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.length * product.width, reverse=False)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.vol, reverse=False)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.vol, reverse=True)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.vol * product.quantity, reverse=True)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    problem_context_deepcopy1 = copy.deepcopy(problem_context)
    products1 = sorted(problem_context_deepcopy1[0], key=lambda product: product.vol * product.quantity, reverse=False)
    indiv = algorithms.Individual(weights=(-1.0, 1.0))
    indiv.extend(representation(products1))
    indiv.problem_context = problem_context_deepcopy1
    pop.append(indiv)

    return pop


def mutate(individual):
    # print(individual)
    positions_changed = random.sample(range(len(individual)), 2)
    individual[positions_changed[0]], individual[positions_changed[1]] = individual[positions_changed[1]], individual[
        positions_changed[0]]
    return individual


def mate(parent1, parent2):
    cut_point = random.randint(1, len(parent1) - 1)
    child1 = []
    child2 = []
    child1.extend(parent1[:cut_point])
    child2.extend(parent2[:cut_point])

    for value in parent2[cut_point:]:
        if value not in child1:
            child1.append(value)
        else:
            child1.extend([x for x in parent2 if x not in child1])

    for value in parent1[cut_point:]:
        if value not in child2:
            child2.append(value)
        else:
            child2.extend([x for x in parent1 if x not in child2])

    parent1.clear()
    parent1.extend(child1)
    parent2.clear()
    parent2.extend(child2)

    return parent1, parent2


def create_sorted_list_of_product_types_for_current_individual(product_id, list_of_products):
    """Create a dictionary to map product IDs to their positions in list of product_id"""
    id_to_position = {id: index for index, id in enumerate(product_id)}
    """Define a custom sorting key function based on the position in list A"""

    def custom_sort_key(product_obj):
        return id_to_position.get(int(product_obj.product_id), len(product_id))

    sorted_list_of_product_types = sorted(list_of_products, key=custom_sort_key)
    return sorted_list_of_product_types


def product_fits_to_block(product, block):
    height = product.height

    if height > block.remainder_height_to_layer():
        return False
    return True


def calculate_block_min_envelop_score(product_type, total_volume_of_product, block, pallet_size=(1200, 800, 1400)):
    block_min_envelop = block.remainder_height_to_layer() * pallet_size[0] * pallet_size[1]

    if block_min_envelop > total_volume_of_product:
        """This prioritizes empty blocks over full blocks"""
        # envelop_score = 1 - (total_volume_of_product / block_min_envelop)
        """This prioritizes full blocks over empty blocks"""
        envelop_score = (total_volume_of_product / block_min_envelop)
    else:
        num_box_fit_on_block = math.floor(block_min_envelop / total_volume_of_product)
        raw_score = num_box_fit_on_block / product_type.quantity
        rank_range_min = 0
        rank_range_max = 0.25
        envelop_score = rank_range_min + raw_score * (rank_range_max - rank_range_min)

    return envelop_score


def rank_all_blocks_against_product_types(residual_product_type, block_list):
    total_volume_of_product = residual_product_type.vol * residual_product_type.quantity
    ranks_of_blocks_per_product = []

    for block in block_list:
        homogeneity_score = 0
        min_envelop_score = 0
        penalty = 0
        total_score_of_block = 0

        if block.remainder_envelope_height() < residual_product_type.height:
            penalty = -100
        else:
            block_product_info = block.get_product_info_of_block()
            if int(residual_product_type.product_id) in block_product_info:
                homogeneity_score = (block_product_info[
                    int(residual_product_type.product_id)]) / block.get_total_number_of_boxes()
                min_envelop_score = calculate_block_min_envelop_score(residual_product_type, total_volume_of_product,
                                                                      block)
            else:
                homogeneity_score = 0
                min_envelop_score = calculate_block_min_envelop_score(residual_product_type, total_volume_of_product,
                                                                      block)

        total_score_of_block = homogeneity_score + min_envelop_score + penalty

        ranks_of_blocks_per_product.append([block, total_score_of_block])

    sorted_list_of_ranked_blocks = sorted(ranks_of_blocks_per_product, key=lambda x: x[1], reverse=True)

    return sorted_list_of_ranked_blocks


def create_box_from_product_type(product_type):
    box = bx.Box(product_type.product_id, product_type.length, product_type.width, product_type.height,
                 product_type.weight)
    return box


def new_com_after_box_placement(box_com, box_mass, block_com, block_mass):
    total_mass = box_mass + block_mass

    new_com = [0, 0, 0]

    new_com[0] = (box_com[0] * box_mass + block_com[0] * block_mass) / total_mass
    new_com[1] = (box_com[1] * box_mass + block_com[1] * block_mass) / total_mass
    new_com[2] = (box_com[2] * box_mass + block_com[2] * block_mass) / total_mass

    return new_com


def calculate_stability_score(center_of_mass, pallet_dims=(1200, 800, 1400)):
    # Calculating vertical_stability_factor
    if center_of_mass[2] <= pallet_dims[2] / 2:
        vertical_stability_factor = center_of_mass[2] / (pallet_dims[2] / 2)
        # Invert the stability factor to get a higher rank for lower stability
        inverted_stability = 1 - vertical_stability_factor
        # Scale the inverted stability factor to the desired rank range (e.g., 0 to 100)
        rank_range_min = 0
        rank_range_max = 100
        vertical_stability_score = rank_range_min + inverted_stability * (rank_range_max - rank_range_min)
    else:
        vertical_stability_score = - 10000

    # Calculating horizontal_stability_factor
    max_horizontal_distance = calculate_distance((0, 0), (pallet_dims[0] / 2, pallet_dims[1] / 2))
    com_horizontal_distance = calculate_distance((center_of_mass[0], center_of_mass[1]),
                                                 (pallet_dims[0] / 2, pallet_dims[1] / 2))

    if com_horizontal_distance <= max_horizontal_distance:
        horizontal_stability_factor = com_horizontal_distance / max_horizontal_distance
        inverted_stability = 1 - horizontal_stability_factor
        rank_range_min = 0
        rank_range_max = 50
        horizontal_stability_score = rank_range_min + inverted_stability * (rank_range_max - rank_range_min)
    else:
        horizontal_stability_score = - 10000

    # total_score = vertical_stability_score + horizontal_stability_score
    total_score = vertical_stability_score

    return total_score


def deprecated_calculate_compactness_score(box, pose, anchor_point, top_boxes_from_block):
    box_to_be_added = copy.deepcopy(box)
    box_to_be_added.anchor_point[0, :] = anchor_point
    box_to_be_added.pose_index = pose

    compactness_score = 0

    # support, cumulative_support_percent, cumulative_support, contained_points = box_to_be_added.is_supported_by_boxes(
    #     top_boxes_from_block)
    contact_area_percent, contact_area = box.is_contacted_by_boxes(top_boxes_from_block)
    # compactness = 1 - contact_area_percent
    compactness = contact_area_percent
    rank_range_min = 0
    rank_range_max = 100
    compactness_score += rank_range_min + compactness * (rank_range_max - rank_range_min)
    # compactness_score += compactness
    # if support:
    #     # compactness_score -= 0
    #     contact_area_percent, contact_area = box.is_contacted_by_boxes(top_boxes_from_block)
    #     compactness = 1 - contact_area_percent
    #     rank_range_min = 0
    #     rank_range_max = 100
    #     compactness_score += rank_range_min + compactness * (rank_range_max - rank_range_min)
    # else:
    #     compactness_score = 10000

    return compactness_score


def evaluate_compactness(box, top_boxes_from_block):
    # compactness_score = 0
    contact_area_percent = box.is_contacted_by_boxes(top_boxes_from_block)
    # compactness = 1 - contact_area_percent
    compactness_score = contact_area_percent
    # compactness_score += rank_range_min + compactness * (rank_range_max - rank_range_min)
    # compactness_score = compactness

    return compactness_score
    # return compactness_score


def calculate_ranks_for_points(box_placement_points, box, pose, current_block):
    box_dimensions = box.poses[pose][1]
    box_original_com = box.poses[pose][2]
    top_boxes_from_block = current_block.get_all_top_boxes_in_block()
    list_of_point_and_pose = []
    list_of_scores = []

    for anchor_point in box_placement_points:
        box.anchor_point[0, :] = anchor_point
        box_com_at_anchor_point = anchor_point + box_original_com
        new_block_com = new_com_after_box_placement(box_com_at_anchor_point, box.weight, current_block.get_block_com(),
                                                    current_block.get_block_weight())
        stability_score = calculate_stability_score(new_block_com)
        # TODO check if compactness_score actually has any effect on the algo

        compactness_score = deprecated_calculate_compactness_score(box, pose, anchor_point, top_boxes_from_block)
        list_of_point_and_pose.append(anchor_point)
        # list_of_scores.append([stability_score, compactness_score])

        final_score = stability_score + compactness_score
        # final_score = stability_score

        list_of_scores.append([final_score])

    return list_of_point_and_pose, list_of_scores


def filter_points(list_of_points, pose, score):
    # np_scores = np.array(score)
    # np_list_of_points = np.array(list_of_points)
    # efficient_mask = is_pareto_efficient(np_scores)

    """Line 307 is using the pareto efficient mask. In order to run the evaluate function without pareto_efficient mask
    comment line 307 and 312, WHILE UNCOMMENTING line 307 and 313"""
    # efficient_points_np_array = np_list_of_points[efficient_mask]
    # efficient_points_np_array = np_list_of_points

    # efficient_points_list = efficient_points_np_array.tolist()

    # scores_np_array = np_scores[efficient_mask]
    # scores_np_array = np_scores
    # scores_list = scores_np_array.tolist()

    # combined_list = [[a, pose, b[0], b[1]] for a, b in zip(efficient_points_list, scores_list)]
    # combined_list = [[a, pose, b[0]] for a, b in zip(efficient_points_list, scores_list)]
    combined_list = [[a, pose, b[0]] for a, b in zip(list_of_points, score)]

    return combined_list


def find_all_pareto_efficient_points(box, current_block):
    # TODO check for COM and compactness and rank all the points: THEN select the best point
    # box_length = box.length
    # box_width = box.width
    box_height = box.height
    box_weight = box.weight
    box_com_pose_1 = box.poses[0][2]  # pose_index = 0 gives us original pose
    box_com_pose_2 = box.poses[1][2]  # pose_index = 1 gives us alternate pose with 90deg rotation along xy-plane

    block_com = current_block.get_block_com()

    box_placement_points = current_block.get_anchor_points()

    list_of_points_pose_0, list_of_scores_pose_0 = calculate_ranks_for_points(box_placement_points, box, 0,
                                                                              current_block)
    list_of_points_pose_1, list_of_scores_pose_1 = calculate_ranks_for_points(box_placement_points, box, 1,
                                                                              current_block)

    combined_list_pose_0 = filter_points(list_of_points_pose_0, 0, list_of_scores_pose_0)
    combined_list_pose_1 = filter_points(list_of_points_pose_1, 1, list_of_scores_pose_1)

    selected_points = combined_list_pose_0 + combined_list_pose_1
    sorted_list_of_selected_points = sorted(selected_points, key=lambda x: x[2], reverse=True)

    return sorted_list_of_selected_points


def calculate_heterogeneity_of_blocks(list_of_blocks):
    number_of_product_types = list_of_blocks[0].get_total_number_of_product_type()
    overall_heterogeneity = 0
    for block in list_of_blocks:
        # total_num_box = block.get_total_number_of_boxes()
        dict = block.get_product_info_of_block()
        heterogeneity = len(dict) / number_of_product_types
        # print("avg = ", avg_heterogeneity)
        overall_heterogeneity += heterogeneity
        # print("overall = ", overall_heterogeneity)

    avg_heterogeneity = overall_heterogeneity / len(list_of_blocks)

    return avg_heterogeneity


def calculate_compactness_of_blocks(list_of_blocks):
    total_compactness_score_all_boxes = 0
    num_of_total_boxes = 0
    # total_compactness_score_all_blocks = 0
    for block in list_of_blocks:
        # average_compactness_one_block = 0
        loose_boxes = block.get_top_loose_boxes()
        top_boxes_from_block = block.get_all_top_boxes_in_block()
        for box in loose_boxes:
            total_compactness_score_all_boxes += evaluate_compactness(box, top_boxes_from_block)
            num_of_total_boxes += 1

    if num_of_total_boxes != 0:
        average_compactness_all_blocks = total_compactness_score_all_boxes / num_of_total_boxes
    else:
        average_compactness_all_blocks = 0

    # if len(loose_boxes) != 0:
    #     average_compactness_one_block = total_compactness_score_one_block / len(loose_boxes)
    # print("Block ", id(block), " : ", average_compactness_one_block)
    # total_compactness_score_all_blocks += average_compactness_one_block

    # average_compactness_all_blocks = total_compactness_score_all_blocks / len(list_of_blocks)

    return average_compactness_all_blocks


def calculate_envelop_score_of_blocks(list_of_blocks, pallet_dims=(1200, 800, 1400)):
    overall_envelop_score = 0
    envelop_height = 0
    for block in list_of_blocks:
        block_vol = 0
        layers = block[0].get_all_layers_copy()
        for layer in layers:
            for box in layer.get_copy_of_boxes():
                block_vol += box.vol

        for box in block[0].get_top_loose_boxes():
            block_vol += box.vol

        block_envelop_height = block_vol / (pallet_dims[0] * pallet_dims[1])
        envelop_height += (pallet_dims[2] - block_envelop_height)

    overall_envelop_score = envelop_height / len(list_of_blocks)
    return overall_envelop_score


def calculate_fitness_of_individual(list_of_blocks):
    # TODO need to implement. This function takes input a list of blocks.
    #  By analyzing the average homogeneity and envelop output fitness1 => homogeneity || fitness2 => envelope

    fitness1 = calculate_heterogeneity_of_blocks(list_of_blocks)
    fitness2 = calculate_compactness_of_blocks(list_of_blocks)
    # fitness2 = calculate_envelop_score_of_blocks(list_of_blocks)

    return fitness1, fitness2


def custom_sort_key(x):
    # Sort first by x[2], then by x[1], and finally by x[0]
    return (x[2], x[1] + x[0])


def update_list_of_points(current_box, anchor_point, box_pose, current_block, points_with_block_id):
    current_box.anchor_point[0, :] = anchor_point
    current_box.pose_index = box_pose
    list_of_eps = []
    list_of_eps.extend(current_box.compute_extreme_points())
    for new_point in list_of_eps:
        new_point.extend([id(current_block)])
        points_with_block_id.append(new_point)

    return points_with_block_id


def deprecated_evaluate(products, blocks, list_of_product_ids, total_num_of_residual):
    # TODO about individuals, constraints and scores
    # NOTE you will be evaluating the individual alone. An individual is a list of product ids .
    # if the individual does not violate any hard constraint (not all the boxes can be placed) it should get a score
    # that evaluates the quality of the individual.
    # we have two scores: heterogeneity and envelope (fitness1 and fitness2 below)

    # IF an individual violates a constraint, for example not all the boxes can be placed is should get the worst possible score
    # the same is to say fitness1 = sys.maxsize and fitness2 = sys.maxsize

    # TODO about the input data
    # NOTE and individual is a list of ids. the quantities, types and dimensions of the boxes can be obtain in context = individual.problem_context.
    # context = individual.problem_context, context is a tuple where context[0] is a list of product, and context[1] is the list of available blocks

    # products = individual.context[0]
    # blocks = individual.context[1]

    products = products
    blocks = blocks

    # TODO about the algorithm
    # NOTE the algorithm is designed to find "optimal positions" for all the residual boxes
    # 1 -> From the list of products create all the boxes that will need to be placed

    # 2 -> Considering the product order on the individual (which product type goes where)
    #   2.1 -> rank all the available pallets based on the quantity of product type of the kind to be placed already in that pallet.

    # 3 -> For each product type in the individual
    #   3.0 -> The evaluation here will include two parameters, this means that you have to calculate a pareto front and pick a point on the front.
    #   You have functions for callculating pareto fronts (is_pareto_efficient) in deprecated_ga_utils
    #   3.1 -> try to place on box of that type in the best pallet, if not possible move to the next best, etc,
    #   if the box cannot be placed in any pallet return the worst possible score, terminate the process
    #       3.1.1 -> the best position for a box on a pallet is the position that results in best COM and in best compactness
    #           #3.1.1.0 -> when a box is placed successfully inside a pallet recalculate all top aps, rank all aps and then try to put the next box of the same product type
    #           #3.1.1.1 -> compactness is evaluated on the amount of side area in a given position. This still needs to be implemented as a function.
    #           As an inspiration you can use the code in box from the function compute_overlapping_area_xy_plane
    #       3.1.2 -> the box needs to be supported and cannot collide with any other box

    """create_sorted_list_of_product_types_for_current_individual() function is basically creating a list of product object based on the sequence of product_ids from current individual"""
    # sorted_products_list = create_sorted_list_of_product_types_for_current_individual(individual, products)
    sorted_products_list = create_sorted_list_of_product_types_for_current_individual(list_of_product_ids, products)

    fitness1 = 0
    fitness2 = 0

    total_residual = total_num_of_residual  # Variable used only for printing progress bar
    packed_residual = 0  # Variable used only for printing progress bar

    ranked_list_of_blocks = blocks

    used_point_per_block_dict = {}
    for product in sorted_products_list:
        box = create_box_from_product_type(product)
        ranked_list_of_blocks = rank_all_blocks_against_product_types(product, blocks)
        valid_solution = True
        list_of_invalid_block = []
        invalid_point_per_product_per_block_dict = {}
        while product.quantity > 0:
            fit = False
            current_box = copy.deepcopy(box)
            for block_info in blocks:
                current_block = block_info[0]
                if current_block.remainder_height_to_layer() < product.height:
                    continue
                if len(list_of_invalid_block) > 0:
                    if id(current_block) in list_of_invalid_block:
                        continue

                # TODO fix rank_and_select_point() function
                ranked_points_for_box_placement = find_all_pareto_efficient_points(current_box, current_block)

                for point in ranked_points_for_box_placement:
                    anchor_point = point[0]
                    box_pose = point[1]
                    if id(current_block) in used_point_per_block_dict:
                        if anchor_point in used_point_per_block_dict[id(current_block)]:
                            continue
                    if id(current_block) in invalid_point_per_product_per_block_dict:
                        if point in invalid_point_per_product_per_block_dict[id(current_block)]:
                            continue
                    if current_block.add_box_to_block(box, anchor_point, box_pose):
                        fit = True
                        if id(current_block) not in used_point_per_block_dict:
                            used_point_per_block_dict[id(current_block)] = []
                        used_point_per_block_dict[id(current_block)].append(anchor_point)
                        break
                    else:
                        if id(current_block) not in invalid_point_per_product_per_block_dict:
                            invalid_point_per_product_per_block_dict[id(current_block)] = []
                        invalid_point_per_product_per_block_dict[id(current_block)].append(point)

                if fit:
                    product.quantity -= 1
                    packed_residual = packed_residual + 1
                    print_progress_bar(packed_residual, total_residual)
                    break
                else:
                    list_of_invalid_block.append(id(current_block))

            if not fit:
                valid_solution = False
                break

        if not valid_solution:
            fitness1 = sys.maxsize
            fitness2 = sys.maxsize
            break

    if fitness1 == 0 and fitness2 == 0:
        fitness1, fitness2 = calculate_fitness_of_individual(ranked_list_of_blocks)

    # 4 -> Evaluate the fitness of the individual. If the process has not stopped until here, meaning that the individual does not violate a constraint
    # we compute the overall fitness of the individual and we had the individual to the solution, the solution will be metadata
    #   4.1 -> we have two fitnesses: avg heterogeneity and avg envelope:
    #       4.1.1 -> heterogeneity is the number of different products in each pallet, we take the average of all pallets, do an weighted calculation for every pallet.
    #       4.1.2 -> envelope is the volume considering the out most dimensions of all pallets, but because in our case we always take
    #       the entire space of the base then it is just the height. We average the height of the highest point in all pallets
    #       4.1.3 -> you most likely need to write additional function for these metrics
    #   4.2 -> fitnesses need to be normalized, ask bot gpt about the normalization function.

    # TODO about the metadata
    # the function should always return metadata, metadata is our "internal" solution for the problem, I mean the exact placing of the boxes.
    # the idea here is that you will receive a copy of the context, remember that context[1] is a list of blocks, when you test a placement and it is ok,
    # you can directly add the box to that block. In the end you will always return the updated context[1]

    # raise NotImplementedError(
    #     "evaluate -> This function is not yet implemented, see comments on the code")

    return (fitness1, fitness2), blocks


def run_evaluation(blocks, sorted_products_list):
    # TODO about the algorithm
    # NOTE the algorithm is designed to find "optimal positions" for all the residual boxes
    # 1 -> From the list of products create all the boxes that will need to be placed

    # 2 -> Considering the product order on the individual (which product type goes where)
    #   2.1 -> rank all the available pallets based on the quantity of product type of the kind to be placed already in that pallet.

    # 3 -> For each product type in the individual
    #   3.0 -> The evaluation here will include two parameters, this means that you have to calculate a pareto front and pick a point on the front.
    #   You have functions for callculating pareto fronts (is_pareto_efficient) in deprecated_ga_utils
    #   3.1 -> try to place on box of that type in the best pallet, if not possible move to the next best, etc,
    #   if the box cannot be placed in any pallet return the worst possible score, terminate the process
    #       3.1.1 -> the best position for a box on a pallet is the position that results in best COM and in best compactness
    #           #3.1.1.0 -> when a box is placed successfully inside a pallet recalculate all top aps, rank all aps and then try to put the next box of the same product type
    #           #3.1.1.1 -> compactness is evaluated on the amount of side area in a given position. This still needs to be implemented as a function.
    #           As an inspiration you can use the code in box from the function compute_overlapping_area_xy_plane
    #       3.1.2 -> the box needs to be supported and cannot collide with any other box

    passed = True
    type_of_residual_products = len(sorted_products_list)
    # sorted_products_list = create_sorted_list_of_product_types_for_current_individual(list_of_product_ids, products)

    fitness1 = 0
    fitness2 = 0

    # total_residual = total_num_of_residual  # Variable used only for printing progress bar
    # packed_residual = 0  # Variable used only for printing progress bar

    points_with_block_id = []
    block_dict = {}
    for block in blocks:
        block_dict[id(block)] = block
        points = block.get_anchor_points()
        for point in points:
            point.extend([id(block)])
            points_with_block_id.append(point)

    used_point_per_block_dict = {}
    for product in sorted_products_list:
        box = create_box_from_product_type(product)

        valid_solution = True
        list_of_invalid_block = []
        invalid_point_per_product_per_block_dict = {}

        while product.quantity > 0:
            sorted_points_with_block_id = sorted(points_with_block_id, key=custom_sort_key)
            fit = False
            current_box = copy.deepcopy(box)

            for point in sorted_points_with_block_id:
                block_id = point[3]
                current_block = block_dict[block_id]
                anchor_point = [point[0], point[1], point[2]]

                if len(list_of_invalid_block) > 0:
                    if block_id in list_of_invalid_block:
                        continue
                if current_block.remainder_height_to_layer() < product.height:
                    list_of_invalid_block.append(block_id)
                    continue
                if block_id in invalid_point_per_product_per_block_dict:
                    if point in invalid_point_per_product_per_block_dict[block_id]:
                        continue

                if current_block.add_box_to_block(box, anchor_point, 0):
                    fit = True
                    points_with_block_id.remove(point)
                    points_with_block_id = update_list_of_points(current_box, anchor_point, 0, current_block,
                                                                 points_with_block_id)
                    break
                elif current_block.add_box_to_block(box, anchor_point, 1):
                    fit = True
                    points_with_block_id.remove(point)
                    points_with_block_id = update_list_of_points(current_box, anchor_point, 1, current_block,
                                                                 points_with_block_id)
                    break
                else:
                    if block_id not in invalid_point_per_product_per_block_dict:
                        invalid_point_per_product_per_block_dict[block_id] = []
                    invalid_point_per_product_per_block_dict[block_id].append(point)

            if fit:
                product.quantity -= 1
                # packed_residual = packed_residual + 1
                # print_progress_bar(packed_residual, total_residual)
            else:
                # print("Unsuccessful packing! Failed Product ID = ", product.product_id, "Number of items = ", product.quantity)
                valid_solution = False
                break

        """Early Stoppage conditions"""
        if not valid_solution:
            fitness1 = sys.maxsize
            fitness2 = 0
            passed = False
            break

    # TODO fix the fitness functions
    if fitness1 == 0 and fitness2 == 0:
        fitness1, fitness2 = calculate_fitness_of_individual(blocks)

    # 4 -> Evaluate the fitness of the individual. If the process has not stopped until here, meaning that the individual does not violate a constraint
    # we compute the overall fitness of the individual and we had the individual to the solution, the solution will be metadata
    #   4.1 -> we have two fitnesses: avg heterogeneity and avg envelope:
    #       4.1.1 -> heterogeneity is the number of different products in each pallet, we take the average of all pallets, do an weighted calculation for every pallet.
    #       4.1.2 -> envelope is the volume considering the out most dimensions of all pallets, but because in our case we always take
    #       the entire space of the base then it is just the height. We average the height of the highest point in all pallets
    #       4.1.3 -> you most likely need to write additional function for these metrics
    #   4.2 -> fitnesses need to be normalized, ask bot gpt about the normalization function.

    # TODO about the metadata
    # the function should always return metadata, metadata is our "internal" solution for the problem, I mean the exact placing of the boxes.
    # the idea here is that you will receive a copy of the context, remember that problem_context[1] is a list of blocks, when you test a placement and it is ok,
    # you can directly add the box to that block. In the end you will always return the updated problem_context[1]

    # raise NotImplementedError(
    #     "evaluate -> This function is not yet implemented, see comments on the code")

    return (fitness1, fitness2), (passed, blocks)


def evaluate(individual):
    # TODO about individuals, constraints and scores
    # NOTE you will be evaluating the individual alone. An individual is a list of product ids .
    # if the individual does not violate any hard constraint (not all the boxes can be placed) it should get a score
    # that evaluates the quality of the individual.
    # we have two scores: heterogeneity and envelope (fitness1 and fitness2 below)

    # IF an individual violates a constraint, for example not all the boxes can be placed is should get the worst possible score
    # the same is to say fitness1 = sys.maxsize and fitness2 = sys.maxsize

    # TODO about the input data
    # NOTE and individual is a list of ids. the quantities, types and dimensions of the boxes can be obtain in context = individual.problem_context.
    # context = individual.problem_context, context is a tuple where context[0] is a list of product, and context[1] is the list of available blocks


    products = individual.problem_context[0]
    blocks = individual.problem_context[1]

    type_of_residual_products = len(individual)

    # products = products
    # blocks = blocks
    """create_sorted_list_of_product_types_for_current_individual() function is basically creating a list of product object based on the sequence of product_ids from current individual"""
    sorted_products_list = create_sorted_list_of_product_types_for_current_individual(individual, products)

    fitness_tuple, result_tuple = run_evaluation(blocks, sorted_products_list)

    return fitness_tuple, result_tuple
