import copy
import random
from .deap_compat import tools
from . import utils
import multiprocessing


class MyFitness(utils.Fitness):

    def __init__(self, weights):
        self.weights = weights


class Individual(list):

    def __init__(self, weights):
        super().__init__()
        self.fitness = MyFitness(weights)
        self.metadata = None
        self.problem_context = None

    def __str__(self):
        return f"Individual: {super().__str__()}, Fitness Weights: {self.fitness.weights}, Fitness: {self.fitness.values}," \
               f" Meta: {self.metadata}"


def varOr(population, mate, mutate, lambda_, cxpb, mutpb):
    r"""Part of an evolutionary algorithm applying only the variation part
    (crossover, mutation **or** reproduction). The modified individuals have
    their fitness invalidated. The individuals are cloned so returned
    population is independent of the input population.

    :param population: A list of individuals to vary.
    :param lambda\_: The number of children to produce
    :param cxpb: The probability of mating two individuals.
    :param mutpb: The probability of mutating an individual.
    :returns: The final population.

    The variation goes as follow. On each of the *lambda_* iteration, it
    selects one of the three operations; crossover, mutation or reproduction.
    In the case of a crossover, two individuals are selected at random from
    the parental population :math:`P_\mathrm{p}`, those individuals are cloned
    using the :meth:`toolbox.clone` method and then mated using the
    :meth:`toolbox.mate` method. Only the first child is appended to the
    offspring population :math:`P_\mathrm{o}`, the second child is discarded.
    In the case of a mutation, one individual is selected at random from
    :math:`P_\mathrm{p}`, it is cloned and then mutated using using the
    :meth:`toolbox.mutate` method. The resulting mutant is appended to
    :math:`P_\mathrm{o}`. In the case of a reproduction, one individual is
    selected at random from :math:`P_\mathrm{p}`, cloned and appended to
    :math:`P_\mathrm{o}`.

    This variation is named *Or* because an offspring will never result from
    both operations crossover and mutation. The sum of both probabilities
    shall be in :math:`[0, 1]`, the reproduction probability is
    1 - *cxpb* - *mutpb*.
    """
    assert (cxpb + mutpb) <= 1.0, (
        "The sum of the crossover and mutation probabilities must be smaller "
        "or equal to 1.0.")

    offspring = []
    for _ in range(lambda_):
        op_choice = random.random()
        if op_choice < cxpb:  # Apply crossover
            ind1, ind2 = [copy.deepcopy(i) for i in random.sample(population, 2)]
            ind1, ind2 = mate(ind1, ind2)
            del ind1.fitness.values
            offspring.append(ind1)
        elif op_choice < cxpb + mutpb:  # Apply mutation
            ind = copy.deepcopy(random.choice(population))
            ind = mutate(ind)
            del ind.fitness.values
            offspring.append(ind)
        else:  # Apply reproduction
            offspring.append(random.choice(population))

    return offspring


def eaMuPlusLambda(population, evaluate, mate, mutate, mu, lambda_, cxpb, mutpb, ngen,
                   stats=None, halloffame=None, verbose=__debug__):
    r"""This is the :math:`(\mu + \lambda)` evolutionary algorithm.

    :param population: A list of individuals.
    :param mu: The number of individuals to select for the next generation.
    :param lambda\_: The number of children to produce at each generation.
    :param cxpb: The probability that an offspring is produced by crossover.
    :param mutpb: The probability that an offspring is produced by mutation.
    :param ngen: The number of generation.
    :param stats: A :class:`~deap.tools.Statistics` object that is updated
                  inplace, optional.
    :param halloffame: A :class:`~deap.tools.HallOfFame` object that will
                       contain the best individuals, optional.
    :param verbose: Whether or not to log the statistics.
    :returns: The final population
    :returns: A class:`~deap.tools.Logbook` with the statistics of the
              evolution.

    The algorithm takes in a population and evolves it in place using the
    :func:`varOr` function. It returns the optimized population and a
    :class:`~deap.tools.Logbook` with the statistics of the evolution. The
    logbook will contain the generation number, the number of evaluations for
    each generation and the statistics if a :class:`~deap.tools.Statistics` is
    given as argument. The *cxpb* and *mutpb* arguments are passed to the
    :func:`varOr` function. The pseudocode goes as follow ::

        evaluate(population)
        for g in range(ngen):
            offspring = varOr(population, toolbox, lambda_, cxpb, mutpb)
            evaluate(offspring)
            population = select(population + offspring, mu)

    First, the individuals having an invalid fitness are evaluated. Second,
    the evolutionary loop begins by producing *lambda_* offspring from the
    population, the offspring are generated by the :func:`varOr` function. The
    offspring are then evaluated and the next generation population is
    selected from both the offspring **and** the population. Finally, when
    *ngen* generations are done, the algorithm returns a tuple with the final
    population and a :class:`~deap.tools.Logbook` of the evolution.

    This function expects :meth:`toolbox.mate`, :meth:`toolbox.mutate`,
    :meth:`toolbox.select` and :meth:`toolbox.evaluate` aliases to be
    registered in the toolbox. This algorithm uses the :func:`varOr`
    variation.
    """
    num_processes = multiprocessing.cpu_count()  # Get the number of available CPU cores
    pool = multiprocessing.Pool(processes=num_processes)

    logbook = tools.Logbook()
    logbook.header = ['gen', 'nevals'] + (stats.fields if stats else [])

    # Evaluate the individuals with an invalid fitness
    invalid_ind = [ind for ind in population if not ind.fitness.valid]
    #results = list(map(evaluate, invalid_ind))
    results = pool.map(evaluate, invalid_ind)
    fitnesses = [result[0] for result in results]  # List of fitness tuples
    metadata = [result[1] for result in results]  # List of individual values
    for ind, fit, metadata in zip(invalid_ind, fitnesses, metadata):
        ind.fitness.values = fit
        ind.metadata = metadata

    if halloffame is not None:
        halloffame.update(population)

    record = stats.compile(population) if stats is not None else {}
    logbook.record(gen=0, nevals=len(invalid_ind), **record)
    if verbose:
        print(logbook.stream)

    # Begin the generational process
    for gen in range(1, ngen + 1):
        # Vary the population
        offspring = varOr(population, mate, mutate, lambda_, cxpb, mutpb)

        # Evaluate the individuals with an invalid fitness
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        #results = list(map(evaluate, invalid_ind))
        results = pool.map(evaluate, invalid_ind)
        fitnesses = [result[0] for result in results]  # List of fitness tuples
        metadata = [result[1] for result in results]  # List of individual values
        for ind, fit, metadata in zip(invalid_ind, fitnesses, metadata):
            ind.fitness.values = fit
            ind.metadata = metadata

        # Update the hall of fame with the generated individuals
        if halloffame is not None:
            halloffame.update(offspring)

        # Select the next generation population
        population[:] = tools.selNSGA2(population + offspring, mu)

        # Update the statistics with the new population
        record = stats.compile(population) if stats is not None else {}
        logbook.record(gen=gen, nevals=len(invalid_ind), **record)
        if verbose:
            print(logbook.stream)

    return population, logbook


def eaMuPlusLambdaWithEarlyStopping(population, evaluate, mate, mutate, mu, lambda_, cxpb, mutpb, ngen,
                                    stats=None, halloffame=None, verbose=__debug__, max_stagnation = 10):
    num_processes = multiprocessing.cpu_count()  # Get the number of available CPU cores
    pool = multiprocessing.Pool(processes=num_processes)

    logbook = tools.Logbook()
    logbook.header = ['gen', 'nevals'] + (stats.fields if stats else [])

    invalid_ind = [ind for ind in population if not ind.fitness.valid]
    # results = list(map(evaluate, invalid_ind))
    results = pool.map(evaluate, invalid_ind)
    fitnesses = [result[0] for result in results]  # List of fitness tuples
    metadata = [result[1] for result in results]  # List of individual values
    for ind, fit, metadata in zip(invalid_ind, fitnesses, metadata):
        ind.fitness.values = fit
        ind.metadata = metadata

    if halloffame is not None:
        halloffame.update(population)

    record = stats.compile(population) if stats is not None else {}
    logbook.record(gen=0, nevals=len(invalid_ind), **record)
    if verbose:
        print(logbook.stream)

    best_fitness = float("inf")
    stagnation_count = 0

    for gen in range(1, ngen + 1):
        offspring = varOr(population, mate, mutate, lambda_, cxpb, mutpb)

        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        # results = list(map(evaluate, invalid_ind))
        results = pool.map(evaluate, invalid_ind)
        fitnesses = [result[0] for result in results]  # List of fitness tuples
        metadata = [result[1] for result in results]  # List of individual values
        for ind, fit, metadata in zip(invalid_ind, fitnesses, metadata):
            ind.fitness.values = fit
            ind.metadata = metadata

        if halloffame is not None:
            halloffame.update(offspring)

        population[:] = tools.selNSGA2(population + offspring, mu)

        record = stats.compile(population) if stats is not None else {}
        logbook.record(gen=gen, nevals=len(invalid_ind), **record)
        if verbose:
            print(logbook.stream)

        # Check for early stopping
        if gen > 1 and record["min"] >= best_fitness:
            stagnation_count += 1
            if stagnation_count >= max_stagnation:
                print("Early stopping triggered after", max_stagnation, "generations of stagnation.")
                break
        else:
            stagnation_count = 0
            best_fitness = record["min"]

    return population, logbook
