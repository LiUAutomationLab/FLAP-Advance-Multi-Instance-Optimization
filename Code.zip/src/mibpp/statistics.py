from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, ttest_1samp, wilcoxon

from .dataio import read_table, result_dirs, write_table


def paired_bootstrap(differences, resamples=5000, confidence=0.95, seed=1042):
    values = np.asarray(differences, float)
    values = values[np.isfinite(values)]
    if not len(values):
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    samples = rng.choice(values, size=(int(resamples), len(values)), replace=True).mean(axis=1)
    alpha = 1 - confidence
    return tuple(np.quantile(samples, [alpha / 2, 1 - alpha / 2]))


def rank_biserial(differences):
    values = np.asarray(differences, float)
    values = values[values != 0]
    return float((np.sum(values > 0) - np.sum(values < 0)) / len(values)) if len(values) else 0.0


def holm_adjust(pvalues):
    p = np.asarray(pvalues, float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, idx in enumerate(order):
        running = max(running, (m - rank) * p[idx])
        adjusted[idx] = min(1.0, running)
    return adjusted


def compute_selector_disagreement(config: dict, decisions=None) -> pd.DataFrame:
    """Compare selected candidate IDs on the same station/order decision."""
    dirs = result_dirs(config)
    decisions = decisions if decisions is not None else read_table(dirs["raw"] / "decisions")
    chosen = decisions[decisions.chosen].copy()
    keys = [c for c in ["scenario", "replicate", "order_set_id", "station", "order_id"] if c in chosen]
    pivot = chosen.pivot_table(index=keys, columns="method", values="candidate_id", aggfunc="first")
    rows = []
    for comparison in ["GREEDY", "GC-P90", "ORACLE"]:
        if "Q2Q-P90" not in pivot or comparison not in pivot:
            continue
        valid = pivot[["Q2Q-P90", comparison]].dropna()
        disagreements = valid["Q2Q-P90"] != valid[comparison]
        rows.append({
            "method_a": "Q2Q-P90", "method_b": comparison,
            "paired_decisions": int(len(valid)),
            "disagreement_count": int(disagreements.sum()),
            "disagreement_rate": float(disagreements.mean()) if len(valid) else np.nan,
        })
    frame = pd.DataFrame(rows)
    write_table(frame, dirs["statistics"] / "selector_disagreement")
    return frame


def compute_statistics(config: dict, episodes=None) -> dict[str, pd.DataFrame]:
    dirs = result_dirs(config)
    episodes = episodes if episodes is not None else read_table(dirs["raw"] / "episodes")
    baseline = config["statistics"]["primary_baseline"]
    confidence = float(config["statistics"]["confidence_level"])
    resamples = int(config["statistics"]["bootstrap_resamples"])
    metrics = ["total_retrievals", "makespan", "idle_time", "coordination_runtime"]
    diagnostic_metrics = [
        "throughput_orders_per_hour", "repeated_retrievals", "conflicts_detected",
        "conflicts_committed", "fallbacks", "replans", "prediction_overruns",
        "coordination_deadline_met",
    ]
    summary = episodes.groupby(["scenario", "method"])[
        metrics + diagnostic_metrics
    ].agg(["mean", "median", "std", "count"]).reset_index()
    summary.columns = ["_".join(filter(None, map(str, col))).rstrip("_") for col in summary.columns]
    paired_rows = []
    unit_column = "order_set_id" if "order_set_id" in episodes else "replicate"
    for scenario, scenario_frame in episodes.groupby("scenario"):
        unit_frame = scenario_frame.groupby([unit_column, "method"], as_index=False)[metrics].mean()
        base = unit_frame[unit_frame.method == baseline][[unit_column] + metrics]
        for method, method_frame in scenario_frame.groupby("method"):
            if method == baseline:
                continue
            method_units = unit_frame[unit_frame.method == method][[unit_column] + metrics]
            merged = base.merge(method_units, on=unit_column, suffixes=("_baseline", "_method"))
            for metric in metrics:
                diff = merged[f"{metric}_method"] - merged[f"{metric}_baseline"]
                base_values = merged[f"{metric}_baseline"].to_numpy(float)
                ci_low, ci_high = paired_bootstrap(diff, resamples, confidence, int(config["seed"]))
                try:
                    p = float(wilcoxon(diff).pvalue) if np.any(diff != 0) else 1.0
                except ValueError:
                    p = 1.0
                paired_rows.append({
                    "scenario": scenario, "baseline": baseline, "method": method, "metric": metric,
                    "experimental_unit": "independent_order_set",
                    "n_pairs": len(merged), "mean_difference": float(np.mean(diff)) if len(diff) else np.nan,
                    "median_difference": float(np.median(diff)) if len(diff) else np.nan,
                    "relative_change_pct": float(100 * np.mean(diff) / np.mean(base_values)) if np.mean(base_values) else np.nan,
                    "ci_low": ci_low, "ci_high": ci_high, "wilcoxon_p": p,
                    "rank_biserial": rank_biserial(diff),
                    "fraction_improved": float(np.mean(diff < 0)) if len(diff) else np.nan,
                })
    paired = pd.DataFrame(paired_rows)
    if len(paired):
        paired["holm_adjusted_p"] = holm_adjust(paired.wilcoxon_p)

    friedman_rows = []
    for scenario, frame in episodes.groupby("scenario"):
        for metric in metrics[:2]:
            pivot = frame.pivot_table(
                index=unit_column, columns="method", values=metric, aggfunc="mean"
            ).dropna()
            if pivot.shape[0] >= 2 and pivot.shape[1] >= 3:
                stat, p = friedmanchisquare(*[pivot[col] for col in pivot.columns])
                friedman_rows.append({
                    "scenario": scenario, "metric": metric, "statistic": stat, "p_value": p,
                    "n_blocks": len(pivot), "methods": "|".join(pivot.columns),
                })
    friedman = pd.DataFrame(friedman_rows)
    write_table(summary, dirs["statistics"] / "episode_summary")
    write_table(paired, dirs["statistics"] / "paired_comparisons")
    write_table(friedman, dirs["statistics"] / "friedman_tests")
    disagreement = compute_selector_disagreement(config)
    return {"summary": summary, "paired": paired, "friedman": friedman,
            "selector_disagreement": disagreement}


def packing_equivalence(config: dict, order_results=None, pool=None) -> pd.DataFrame:
    dirs = result_dirs(config)
    order_results = order_results if order_results is not None else read_table(dirs["raw"] / "orders")
    pool = pool if pool is not None else read_table(dirs["raw"] / "packing_candidates")
    baseline = pool.sort_values(["order_id", "candidate_id"]).groupby("order_id").first().reset_index()
    selected = order_results[order_results.method == "Q2Q-P90"].copy()
    selected = selected.groupby("order_id")[
        ["compactness", "homogeneity", "pallet_volume_utilization_pct"]
    ].mean().reset_index()
    all_orders = pd.DataFrame({"order_id": sorted(pool.order_id.unique())})
    pair_audit = all_orders.merge(
        baseline[["order_id", "candidate_id"]], on="order_id", how="left"
    ).rename(columns={"candidate_id": "baseline_candidate_id"})
    selected_ids = order_results[order_results.method == "Q2Q-P90"].groupby("order_id")[
        "selected_candidate"
    ].agg(lambda values: "|".join(sorted(set(map(str, values))))).reset_index()
    pair_audit = pair_audit.merge(selected_ids, on="order_id", how="left")
    pair_audit["pair_status"] = np.where(
        pair_audit.selected_candidate.notna(), "paired", "not_selected_in_q2q_episodes"
    )
    write_table(pair_audit, dirs["statistics"] / "packing_pair_audit")
    merged = baseline.merge(selected, on="order_id", suffixes=("_baseline", "_proposed"))
    metric_margins = {
        "pallet_volume_utilization_pct": config["statistics"]["equivalence_margins"]["pallet_volume_utilization_pct"],
        "compactness": config["statistics"]["equivalence_margins"]["compactness"],
        "homogeneity": config["statistics"]["equivalence_margins"]["homogeneity"],
    }
    rows = []
    for metric, margin in metric_margins.items():
        diff = merged[f"{metric}_proposed"] - merged[f"{metric}_baseline"]
        diff = diff[np.isfinite(diff)]
        identical = bool(len(diff) and np.allclose(diff, 0.0, atol=1e-12, rtol=0.0))
        low, high = paired_bootstrap(
            diff, config["statistics"]["bootstrap_resamples"],
            config["statistics"]["confidence_level"], config["seed"]
        )
        p_lower = np.nan if identical else (
            float(ttest_1samp(diff, -margin, alternative="greater").pvalue) if len(diff) > 1 else np.nan
        )
        p_upper = np.nan if identical else (
            float(ttest_1samp(diff, margin, alternative="less").pvalue) if len(diff) > 1 else np.nan
        )
        rows.append({
            "metric": metric, "n_pairs": len(diff),
            "baseline_mean": float(merged[f"{metric}_baseline"].mean()),
            "proposed_mean": float(merged[f"{metric}_proposed"].mean()),
            "mean_difference": float(diff.mean()), "ci_low": low, "ci_high": high,
            "equivalence_margin": margin, "tost_p_lower": p_lower, "tost_p_upper": p_upper,
            "equivalent": bool(low > -margin and high < margin),
            "comparison_type": "identical_outcomes" if identical else "equivalence_test",
            "unpaired_pool_orders": int((pair_audit.pair_status != "paired").sum()),
            "candidate_source": "original_flap_optimizer_2024",
        })
    frame = pd.DataFrame(rows)
    write_table(frame, dirs["statistics"] / "packing_equivalence")
    return frame
