from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml


def load_config(path: str | Path, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    path = Path(path).resolve()
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    config["_config_path"] = str(path)
    config["_project_root"] = str(path.parent.parent)
    if overrides:
        for dotted, value in overrides.items():
            node = config
            parts = dotted.split(".")
            for key in parts[:-1]:
                node = node.setdefault(key, {})
            node[parts[-1]] = value
    resolve_paths(config)
    validate_config(config)
    return config


def resolve_paths(config: dict[str, Any]) -> None:
    root = Path(config["_project_root"])
    for key in ("dataset", "legacy_results", "results_dir"):
        value = Path(config["paths"][key])
        config["paths"][key] = str(value if value.is_absolute() else (root / value).resolve())


def validate_config(config: dict[str, Any]) -> None:
    required = {
        "simulation": [
            "buffer_capacity", "amrs", "high_bay_servers", "equivalent_pallets_per_product",
            "high_bay_retrieval_seconds", "amr_transport_seconds", "station_transfer_seconds",
            "robot_seconds_per_item", "block_handling_seconds", "execution_noise_cv", "coordination_deadline_seconds",
        ],
        "experiment": ["num_orders", "num_stations", "replicates", "methods"],
        "candidate_pool": [
            "mode", "candidates_per_order", "pallet_dimensions_mm", "ga",
            "max_optimizer_runtime_minutes", "max_total_optimizer_runtime_minutes",
            "replacement_orders_per_overlap", "pool_orders_per_overlap",
            "layer_sort_strategies", "continue_on_error",
        ],
    }
    missing = [f"{section}.{key}" for section, keys in required.items() for key in keys if key not in config.get(section, {})]
    if missing:
        raise ValueError("Missing publication-critical configuration: " + ", ".join(missing))
    if config["candidate_pool"]["mode"] != "full_packing":
        raise ValueError("This project is configured for Mode B ('full_packing') only.")
    if int(config["experiment"]["num_stations"]) < 1 or int(config["experiment"]["num_orders"]) < 1:
        raise ValueError("num_stations and num_orders must be positive")
    if float(config["candidate_pool"]["max_optimizer_runtime_minutes"]) <= 0:
        raise ValueError("candidate_pool.max_optimizer_runtime_minutes must be positive")
    total_budget = config["candidate_pool"]["max_total_optimizer_runtime_minutes"]
    if total_budget is not None and float(total_budget) <= 0:
        raise ValueError("candidate_pool.max_total_optimizer_runtime_minutes must be positive or null")
    if int(config["candidate_pool"]["replacement_orders_per_overlap"]) < 0:
        raise ValueError("candidate_pool.replacement_orders_per_overlap cannot be negative")
    strategies = list(config["candidate_pool"]["layer_sort_strategies"])
    expected = ["fill_first", "weight_first", "group_first"]
    if int(config["candidate_pool"]["candidates_per_order"]) != 3 or strategies != expected:
        raise ValueError(
            "candidate_pool must define exactly three candidates in this order: " + str(expected)
        )
    if int(config["candidate_pool"]["pool_orders_per_overlap"]) < int(config["experiment"]["num_orders"]):
        raise ValueError("pool_orders_per_overlap must be at least experiment.num_orders")
    order_sets = int(config["experiment"].get("order_set_replicates", 1))
    if order_sets < 1 or order_sets > int(config["experiment"]["replicates"]):
        raise ValueError("experiment.order_set_replicates must be between 1 and replicates")


def config_hash(config: dict[str, Any]) -> str:
    clean = {k: v for k, v in config.items() if not k.startswith("_")}
    return hashlib.sha256(json.dumps(clean, sort_keys=True).encode()).hexdigest()


def dump_resolved_config(config: dict[str, Any], path: Path) -> None:
    clean = {k: v for k, v in config.items() if not k.startswith("_")}
    path.write_text(yaml.safe_dump(clean, sort_keys=False), encoding="utf-8")
