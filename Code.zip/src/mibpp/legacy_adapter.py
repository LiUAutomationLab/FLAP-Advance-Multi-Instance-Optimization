from __future__ import annotations

import contextlib
import io
import json
import multiprocessing as mp
import random
import time
import datetime
import traceback
from dataclasses import dataclass

import numpy as np
import pandas as pd

from .legacy_optimizer import block_builder as bb
from .legacy_optimizer import dataset_tools as dt
from .legacy_optimizer import residual_packing as rp


@dataclass(frozen=True)
class PackingCandidate:
    order_id: int
    candidate_id: str
    seed: int
    layer_sort_strategy: str
    optimizer_runtime_seconds: float
    num_blocks: int
    residual_boxes: int
    residual_variety: int
    num_ga_runs: int
    heterogeneity: float
    homogeneity: float
    compactness: float
    envelope_volume_utilization_pct: float
    pallet_volume_utilization_pct: float
    required_products_json: str
    required_quantities_json: str
    block_sequence_json: str
    execution_sequence_json: str
    source: str = "original_flap_optimizer_2024"


class OptimizerTimeoutError(TimeoutError):
    """Raised after a timed-out optimizer subprocess has been terminated."""


class OptimizerProcessError(RuntimeError):
    """Raised when the optimizer fails inside its isolated subprocess."""


def order_from_frame(order_id: int, group: pd.DataFrame) -> dt.Order:
    products = []
    for row in group.itertuples(index=False):
        volume = int(row.Length) * int(row.Width) * int(row.Height)
        products.append(dt.Product(str(int(row.Product)), int(row.Length), int(row.Width), int(row.Height),
                                   float(row.Weight), volume, int(row.Quantity)))
    return dt.Order(str(int(order_id)), products)


def _packing_metrics(blocks, products, pallet_dims):
    pallet_volume = float(np.prod(pallet_dims))
    total_volume = 0.0
    envelope_values = []
    block_sequence = []
    execution_sequence = []
    for block_index, block in enumerate(blocks):
        block_volume = 0.0
        for layer in block.get_all_layers_copy():
            for box in layer.get_copy_of_boxes():
                block_volume += float(box.vol)
        for box in block.get_top_loose_boxes():
            block_volume += float(box.vol)
        total_volume += block_volume
        used_height = float(pallet_dims[2] - block.remainder_envelope_height())
        envelope_volume = used_height * pallet_dims[0] * pallet_dims[1]
        envelope_values.append(100 * block_volume / envelope_volume if envelope_volume > 0 else 0.0)
        composition = {str(int(k)): int(v) for k, v in block.get_product_info_of_block().items()}
        block_sequence.append({"block": block_index, "products": composition, "used_height_mm": used_height})
        for product_id, quantity in composition.items():
            execution_sequence.extend([int(product_id)] * int(quantity))
    heterogeneity, compactness = rp.calculate_fitness_of_individual(blocks)
    required = {int(p.product_id): int(p.quantity) for p in products}
    return {
        "heterogeneity": float(heterogeneity),
        "homogeneity": float(1.0 - heterogeneity),
        "compactness": float(compactness),
        "envelope_volume_utilization_pct": float(np.mean(envelope_values) if envelope_values else 0),
        "pallet_volume_utilization_pct": float(100 * total_volume / (pallet_volume * len(blocks)) if blocks else 0),
        "required_products_json": json.dumps(sorted(required)),
        "required_quantities_json": json.dumps(required, sort_keys=True),
        "block_sequence_json": json.dumps(block_sequence, sort_keys=True),
        "execution_sequence_json": json.dumps(execution_sequence),
    }


def run_original_optimizer(order_id: int, group: pd.DataFrame, candidate_index: int, seed: int,
                           pallet_dims=(1200, 800, 1400), ga_config=None,
                           layer_sort_strategy="fill_first") -> PackingCandidate:
    """Run the uploaded layer/block/GA optimizer and export one genuine complete solution."""
    random.seed(seed)
    np.random.seed(seed)
    order = order_from_frame(order_id, group)
    builder = bb.BlockBuilder(
        order, tuple(pallet_dims), ga_config=ga_config,
        layer_sort_strategy=layer_sort_strategy,
    )
    started = time.perf_counter()
    started_print = datetime.datetime.now()
    print("GA start time: ", started_print)
    # The archived optimizer is very verbose; logs remain available by setting MIBPP_LEGACY_PROGRESS=1.
    with contextlib.redirect_stdout(io.StringIO()):
        blocks, residual_products, ga_runs = builder.run()
    runtime = time.perf_counter() - started
    runtime_print = datetime.datetime.now() - started_print
    print("Total Run Time: ", runtime_print)
    residual_boxes, residual_variety = builder.get_initial_residual_counts()
    pareto_solutions = builder.get_last_pareto_solutions()
    if pareto_solutions:
        _, blocks = pareto_solutions[candidate_index % len(pareto_solutions)]
    metrics = _packing_metrics(blocks, order.products, tuple(pallet_dims))
    return PackingCandidate(
        order_id=int(order_id), candidate_id=f"O{int(order_id)}-C{candidate_index:03d}", seed=int(seed),
        layer_sort_strategy=str(layer_sort_strategy),
        optimizer_runtime_seconds=float(runtime), num_blocks=int(len(blocks)),
        residual_boxes=int(residual_boxes), residual_variety=int(residual_variety),
        num_ga_runs=int(ga_runs), **metrics,
        source="original_flap_optimizer_2024_pareto_hof" if pareto_solutions else "original_flap_optimizer_2024",
    )


def _optimizer_process_entry(connection, order_id, group, candidate_index, seed, pallet_dims, ga_config,
                             layer_sort_strategy):
    """Child-process entry point; it must remain at module scope for Windows spawn."""
    try:
        candidate = run_original_optimizer(
            order_id, group, candidate_index, seed, pallet_dims, ga_config, layer_sort_strategy
        )
        connection.send(("success", candidate, None))
    except BaseException as exc:  # Preserve failures from the archived optimizer.
        connection.send((
            "failed",
            f"{type(exc).__name__}: {exc}",
            traceback.format_exc(),
        ))
    finally:
        connection.close()


def _terminate_process(process: mp.Process) -> None:
    if not process.is_alive():
        process.join(timeout=1.0)
        return
    process.terminate()
    process.join(timeout=5.0)
    if process.is_alive() and hasattr(process, "kill"):
        process.kill()
        process.join(timeout=5.0)


def run_original_optimizer_with_timeout(
    order_id: int,
    group: pd.DataFrame,
    candidate_index: int,
    seed: int,
    pallet_dims=(1200, 800, 1400),
    ga_config=None,
    timeout_seconds: float = 1800.0,
    layer_sort_strategy: str = "fill_first",
) -> PackingCandidate:
    """Run one optimizer attempt in an isolated process with a hard time limit.

    A process, rather than a thread, is required because the archived optimizer is
    CPU-bound and a timed-out thread cannot be stopped safely. ``spawn`` is used
    explicitly so the behavior is consistent on Windows and Linux.
    """
    timeout_seconds = float(timeout_seconds)
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")

    context = mp.get_context("spawn")
    parent_connection, child_connection = context.Pipe(duplex=False)
    process = context.Process(
        target=_optimizer_process_entry,
        args=(
            child_connection,
            int(order_id),
            group,
            int(candidate_index),
            int(seed),
            tuple(pallet_dims),
            ga_config,
            str(layer_sort_strategy),
        ),
        name=f"mibpp-optimizer-order-{int(order_id)}-candidate-{int(candidate_index)}",
    )
    process.start()
    child_connection.close()
    try:
        if not parent_connection.poll(timeout_seconds):
            _terminate_process(process)
            raise OptimizerTimeoutError(
                f"Optimizer exceeded {timeout_seconds / 60:.2f} minutes for "
                f"order {order_id}, candidate {candidate_index}."
            )
        try:
            status, payload, remote_traceback = parent_connection.recv()
        except EOFError as exc:
            process.join(timeout=1.0)
            raise OptimizerProcessError(
                f"Optimizer process exited without returning a result for order {order_id}, "
                f"candidate {candidate_index}; exit code={process.exitcode}."
            ) from exc
        process.join(timeout=5.0)
        if process.is_alive():
            _terminate_process(process)
        if status == "success":
            return payload
        raise OptimizerProcessError(
            f"Optimizer failed for order {order_id}, candidate {candidate_index}: {payload}\n"
            f"Remote traceback:\n{remote_traceback}"
        )
    finally:
        parent_connection.close()
        if process.is_alive():
            _terminate_process(process)
