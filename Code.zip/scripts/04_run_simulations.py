from _common import configured
from mibpp.simulation import run_prediction_robustness, run_simulations

if __name__ == "__main__":
    config = configured("Run dynamic warehouse simulations")
    run_simulations(config)
    run_prediction_robustness(config)
