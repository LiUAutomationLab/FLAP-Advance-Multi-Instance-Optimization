from _common import configured
from mibpp.features import validate_data

if __name__ == "__main__":
    validate_data(configured("Validate and audit input datasets"))
