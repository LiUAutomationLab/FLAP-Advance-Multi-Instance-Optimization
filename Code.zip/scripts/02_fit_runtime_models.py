from _common import configured
from mibpp.runtime import fit_runtime_models

if __name__ == "__main__":
    fit_runtime_models(configured("Fit out-of-fold runtime predictors"))
