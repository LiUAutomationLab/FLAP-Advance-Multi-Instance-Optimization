from _common import configured
from mibpp.statistics import compute_statistics, packing_equivalence

if __name__ == "__main__":
    config = configured("Compute paired statistics and packing equivalence")
    compute_statistics(config)
    packing_equivalence(config)
