from _common import configured
from mibpp.features import prepare_features

if __name__ == "__main__":
    prepare_features(configured("Prepare canonical empirical features"))
