from _common import configured
from mibpp.reporting import make_tables

if __name__ == "__main__":
    make_tables(configured("Generate manuscript tables"))
