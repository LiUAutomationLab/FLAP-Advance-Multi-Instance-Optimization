"""MAIN SCRIPT 2: compute statistics and produce all manuscript figures/tables."""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from src.mibpp.config import load_config
from src.mibpp.pipeline import run_reporting

# ----------------------------- USER VARIABLES -----------------------------
CONFIG_FILE = PROJECT_ROOT / "configs" / "paper.yaml"
RESULTS_DIR = PROJECT_ROOT / "outputs" / "paper_2026_revision"
# FIGURES_AND_TABLES_DIR = PROJECT_ROOT / "outputs" / "paper_2026_revision" / "manuscript_outputs"
FIGURES_AND_TABLES_DIR = Path(r"C:\Users\anaan01\Downloads\3dbpp_revised_manuscript_output")
# --------------------------------------------------------------------------


def produce_figures_and_tables(
    config_file=CONFIG_FILE,
    results_dir=RESULTS_DIR,
    output_dir=FIGURES_AND_TABLES_DIR,
):
    config = load_config(config_file, {"paths.results_dir": str(Path(results_dir).resolve())})
    run_reporting(config, Path(output_dir).resolve())


if __name__ == "__main__":
    produce_figures_and_tables()
