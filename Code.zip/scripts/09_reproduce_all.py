from _common import configured
from src.mibpp.pipeline import run_raw_experiments, run_reporting

if __name__ == "__main__":
    config = configured("Reproduce all raw results, statistics, figures and tables")
    run_raw_experiments(config)
    run_reporting(config)
