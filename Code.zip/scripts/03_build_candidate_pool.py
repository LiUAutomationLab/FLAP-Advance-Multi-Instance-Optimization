from _common import configured
from mibpp.candidates import build_candidate_pool

if __name__ == "__main__":
    build_candidate_pool(configured("Build genuine Mode-B packing candidates"))
