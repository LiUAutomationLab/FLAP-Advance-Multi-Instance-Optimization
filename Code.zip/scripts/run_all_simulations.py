"""MAIN SCRIPT 1: run all empirical preparation and simulations; save raw results."""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from src.mibpp.config import load_config
from src.mibpp.pipeline import run_raw_experiments, run_scalability_only

# ----------------------------- USER VARIABLES -----------------------------
CONFIG_FILE = PROJECT_ROOT / "configs" / "paper.yaml"
RESULTS_DIR = PROJECT_ROOT / "outputs" / "paper_2026_revision"
NUM_ORDERS = 70
NUM_STATIONS = 10
ORDER_POOL_SIZE_PER_OVERLAP = 80
ORDER_SET_REPLICATES = 20
SCALABILITY_STATIONS = [2, 4, 6, 8, 10]
# --------------------------------------------------------------------------


def run_all_simulations(
    config_file=CONFIG_FILE,
    results_dir=RESULTS_DIR,
    num_orders=NUM_ORDERS,
    num_stations=NUM_STATIONS,
    order_pool_size_per_overlap=ORDER_POOL_SIZE_PER_OVERLAP,
    order_set_replicates=ORDER_SET_REPLICATES,
):
    config = load_config(config_file, {
        "paths.results_dir": str(Path(results_dir).resolve()),
        "experiment.num_orders": int(num_orders),
        "experiment.num_stations": int(num_stations),
        "experiment.order_set_replicates": int(order_set_replicates),
        "candidate_pool.pool_orders_per_overlap": int(order_pool_size_per_overlap),
    })
    # Scalability is run separately below, so do not benchmark selectors twice.
    return run_raw_experiments(config, include_selector_benchmarks=False)


def run_scalability_analysis(
    station_counts=SCALABILITY_STATIONS,
    config_file=CONFIG_FILE,
    results_dir=RESULTS_DIR,
):
    config = load_config(config_file, {"paths.results_dir": str(Path(results_dir).resolve())})
    return run_scalability_only(config, station_counts)


if __name__ == "__main__":
    run_all_simulations()
    run_scalability_analysis()
