from pathlib import Path
import argparse
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from mibpp.config import load_config


def configured(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs" / "quick.yaml"))
    parser.add_argument("--results-dir")
    args = parser.parse_args()
    overrides = {"paths.results_dir": str(Path(args.results_dir).resolve())} if args.results_dir else None
    return load_config(args.config, overrides)
