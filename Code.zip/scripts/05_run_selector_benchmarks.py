from _common import configured
from mibpp.benchmarks import run_selector_benchmarks

if __name__ == "__main__":
    run_selector_benchmarks(configured("Run selector and scalability benchmarks"))
