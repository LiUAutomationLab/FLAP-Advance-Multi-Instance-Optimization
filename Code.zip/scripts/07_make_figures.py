from _common import configured
from mibpp.reporting import make_figures

if __name__ == "__main__":
    make_figures(configured("Generate manuscript figures"))
